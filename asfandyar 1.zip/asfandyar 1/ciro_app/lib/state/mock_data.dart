// mock_data.dart — Rich fallback data used when backend is unreachable

// ── FLOODING SCENARIO ─────────────────────────────────────────────────────

final Map<String, dynamic> mockCrisisFlooding = {
  'crisis_type': 'urban_flooding',
  'type': 'Urban Flooding',
  'location': 'G-10, Islamabad',
  'severity': 'CRITICAL',
  'confidence': 0.94,
  'reasoning':
      'Multiple signals confirm flash flooding at G-10. Weather indicates 85mm rainfall. Traffic data shows 87% congestion spike. Social media reports vehicles stranded and water depth exceeding safe levels. Immediate emergency response required.',
  'supporting_evidence': [
    'Social Signal: G-10 mein pani bhar gaya hai, gaariyan phans gayi hain',
    'Weather Alert: 85mm rainfall in Islamabad-West — RED alert active',
    'Traffic Spike: G-10 speed 5kmh, congestion 87% (normal: 12kmh, 30%)',
  ],
};

final Map<String, dynamic> mockPlanFlooding = {
  'priority_level': 'critical',
  'actions': [
    {
      'type': 'traffic_reroute',
      'priority': 1,
      'description':
          'Immediately reroute all vehicles away from G-10 via G-11 expressway and Kashmir Highway. Deploy 4 traffic officers at Margalla Interchange.',
      'target_location': 'G-11 Markaz / Kashmir Highway',
      'estimated_time_minutes': 8,
    },
    {
      'type': 'emergency_dispatch',
      'priority': 2,
      'description':
          'Dispatch 3 Rescue 1122 boats and 2 fire brigade water pumps to G-10 sector 4. Deploy 12 rescue personnel with life vests.',
      'target_location': 'G-10 Sector 4',
      'estimated_time_minutes': 12,
    },
    {
      'type': 'public_alert',
      'priority': 3,
      'description':
          'Broadcast emergency SMS to 1,240 residents in G-10 radius: "CIRO Alert: Flash flooding reported. Evacuate ground floor immediately. Helpline: 1122"',
      'target_location': '1.2km radius G-10',
      'estimated_time_minutes': 2,
    },
    {
      'type': 'resource_allocation',
      'priority': 4,
      'description':
          'Pre-position 50 emergency food packets, 200L clean water, and 30 emergency blankets at G-10 Markaz relief point.',
      'target_location': 'G-10 Markaz Community Center',
      'estimated_time_minutes': 25,
    },
  ],
};

final Map<String, dynamic> mockSimulationFlooding = {
  'status': 'completed',
  'markers': [
    {'id': 'crisis', 'lat': 33.6844, 'lng': 73.0479, 'type': 'crisis', 'label': '⚠️ Flood Zone — G-10'},
    {'id': 'rescue', 'lat': 33.6870, 'lng': 73.0420, 'type': 'resource', 'label': '🚣 Rescue Boats Deployed'},
    {'id': 'relief', 'lat': 33.6810, 'lng': 73.0500, 'type': 'resource', 'label': '📦 Relief Point Active'},
    {'id': 'divert', 'lat': 33.6919, 'lng': 73.0291, 'type': 'reroute', 'label': '↪️ Traffic Diverted via G-11'},
  ],
  'polylines': [
    {
      'id': 'reroute',
      'color': 'green',
      'points': [
        {'lat': 33.6844, 'lng': 73.0479},
        {'lat': 33.6880, 'lng': 73.0390},
        {'lat': 33.6919, 'lng': 73.0291},
      ],
    },
    {
      'id': 'blocked',
      'color': 'red',
      'points': [
        {'lat': 33.6844, 'lng': 73.0479},
        {'lat': 33.6820, 'lng': 73.0520},
      ],
    },
  ],
  'alerts': ['SMS sent to 1,240 residents', 'Rescue 1122 alerted', 'Fire brigade en route'],
  'metrics': {
    'congestion_before_pct': 87,
    'congestion_after_pct': 34,
    'congestion_delta_pct': 53,
    'response_time_before_min': 22,
    'response_time_after_min': 8,
    'response_time_delta_min': 14,
    'vehicles_rerouted': 312,
    'alerts_sent_count': 1240,
  },
  'emergency_tickets': [
    {'id': 'TKT-001', 'type': 'Flood Rescue', 'status': 'ACTIVE', 'location': 'G-10 Sector 4'},
    {'id': 'TKT-002', 'type': 'Medical Standby', 'status': 'ACTIVE', 'location': 'G-10 Markaz'},
  ],
};

final List<dynamic> mockLogsFlooding = [
  {
    'agent': 'Ingestion Agent',
    'action': 'process_signal',
    'input_summary': 'Raw Urdu social media text: G-10 flooding report',
    'reasoning': 'Detected Roman Urdu with flood keywords. Mapped G-10 coordinates.',
    'duration_ms': 1240,
    'antigravity_trace_id': 'AG-INS-001-FLOOD',
  },
  {
    'agent': 'Detection Agent',
    'action': 'detect_crisis',
    'input_summary': '3 signals: social media + weather + traffic',
    'reasoning': 'Cross-correlated flood signal with 85mm rainfall and 87% congestion. Confidence: 94%',
    'duration_ms': 2100,
    'antigravity_trace_id': 'AG-DET-002-FLOOD',
  },
  {
    'agent': 'Planning Agent',
    'action': 'generate_response_plan',
    'input_summary': 'Crisis: Urban Flooding, Severity: CRITICAL',
    'reasoning': 'Generated 4-action coordinated response with traffic rerouting and emergency dispatch.',
    'duration_ms': 3450,
    'antigravity_trace_id': 'AG-PLN-003-FLOOD',
  },
  {
    'agent': 'Simulation Agent',
    'action': 'simulate_plan',
    'input_summary': '4 actions from Planning Agent',
    'reasoning': 'Simulated execution: congestion reduced from 87% to 34%. Response time cut by 14 minutes.',
    'duration_ms': 1800,
    'antigravity_trace_id': 'AG-SIM-004-FLOOD',
  },
];

// ── ACCIDENT SCENARIO ─────────────────────────────────────────────────────

final Map<String, dynamic> mockCrisisAccident = {
  'crisis_type': 'road_accident',
  'type': 'Road Accident',
  'location': 'Murree Road, Islamabad',
  'severity': 'HIGH',
  'confidence': 0.91,
  'reasoning':
      'Multiple reports confirm major road accident on Murree Road near Faizabad. Traffic at standstill. Casualties likely based on signal urgency. Immediate medical and traffic response required.',
  'supporting_evidence': [
    'Social Signal: Murree Road par badha accident hua hai, ambulance chahiye!',
    'Traffic Spike: Murree Road speed 2kmh, congestion 93%',
    'Emergency call logged: Multiple vehicle collision near Faizabad flyover',
  ],
};

final Map<String, dynamic> mockPlanAccident = {
  'priority_level': 'high',
  'actions': [
    {
      'type': 'emergency_dispatch',
      'priority': 1,
      'description':
          'Dispatch 2 ambulances from PIMS Hospital and 1 rescue team. Estimated arrival 6 minutes via Margalla Road alternate.',
      'target_location': 'Murree Road near Faizabad Flyover',
      'estimated_time_minutes': 6,
    },
    {
      'type': 'traffic_reroute',
      'priority': 2,
      'description':
          'Divert Murree Road traffic via 7th Avenue and IJP Road. Close 2km stretch for emergency access.',
      'target_location': '7th Avenue / IJP Road',
      'estimated_time_minutes': 5,
    },
    {
      'type': 'public_alert',
      'priority': 3,
      'description':
          'Alert 850 commuters on Murree Road via CIRO broadcast: "Major accident ahead. Use alternate routes."',
      'target_location': 'Murree Road corridor',
      'estimated_time_minutes': 1,
    },
  ],
};

final Map<String, dynamic> mockSimulationAccident = {
  'status': 'completed',
  'markers': [
    {'id': 'crisis', 'lat': 33.6650, 'lng': 73.0820, 'type': 'crisis', 'label': '🚨 Accident — Murree Road'},
    {'id': 'ambulance', 'lat': 33.6700, 'lng': 73.0700, 'type': 'resource', 'label': '🚑 Ambulance En Route'},
    {'id': 'divert', 'lat': 33.6600, 'lng': 73.0600, 'type': 'reroute', 'label': '↪️ Traffic Diverted'},
  ],
  'polylines': [
    {
      'id': 'reroute',
      'color': 'green',
      'points': [
        {'lat': 33.6650, 'lng': 73.0820},
        {'lat': 33.6600, 'lng': 73.0700},
        {'lat': 33.6600, 'lng': 73.0600},
      ],
    },
  ],
  'alerts': ['SMS sent to 850 commuters', 'PIMS ambulance dispatched', 'Traffic cleared in 18 min'],
  'metrics': {
    'congestion_before_pct': 93,
    'congestion_after_pct': 45,
    'congestion_delta_pct': 48,
    'response_time_before_min': 18,
    'response_time_after_min': 6,
    'response_time_delta_min': 12,
    'vehicles_rerouted': 214,
    'alerts_sent_count': 850,
  },
  'emergency_tickets': [
    {'id': 'TKT-003', 'type': 'Road Accident', 'status': 'ACTIVE', 'location': 'Murree Road'},
    {'id': 'TKT-004', 'type': 'Medical Response', 'status': 'EN ROUTE', 'location': 'PIMS → Murree Road'},
  ],
};

final List<dynamic> mockLogsAccident = [
  {
    'agent': 'Ingestion Agent',
    'action': 'process_signal',
    'input_summary': 'Roman Urdu accident report — Murree Road',
    'reasoning': 'Detected accident keywords with high urgency. Location: Murree Road / Faizabad.',
    'duration_ms': 980,
    'antigravity_trace_id': 'AG-INS-005-ACC',
  },
  {
    'agent': 'Detection Agent',
    'action': 'detect_crisis',
    'input_summary': '2 signals: social + traffic',
    'reasoning': 'Road accident confirmed. 93% congestion spike. Confidence: 91%.',
    'duration_ms': 1750,
    'antigravity_trace_id': 'AG-DET-006-ACC',
  },
  {
    'agent': 'Planning Agent',
    'action': 'generate_response_plan',
    'input_summary': 'Crisis: Road Accident, Severity: HIGH',
    'reasoning': 'Generated 3-action plan: ambulance dispatch + traffic reroute + public alert.',
    'duration_ms': 2890,
    'antigravity_trace_id': 'AG-PLN-007-ACC',
  },
  {
    'agent': 'Simulation Agent',
    'action': 'simulate_plan',
    'input_summary': '3 actions executed',
    'reasoning': 'Congestion reduced 93%→45%. Emergency response time cut from 18 to 6 minutes.',
    'duration_ms': 1420,
    'antigravity_trace_id': 'AG-SIM-008-ACC',
  },
];
