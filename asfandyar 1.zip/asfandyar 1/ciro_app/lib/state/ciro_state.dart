import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'mock_data.dart';

// ─── CONFIG ────────────────────────────────────────────────────────────────
// Your PC's WiFi IP — run `ipconfig` to confirm
const String BACKEND_URL = 'https://ciro-backend-1038017448725.us-central1.run.app';
const bool MOCK_FALLBACK = true; // Fallback to mock data if cloud backend is unreachable

// ─── STATE ─────────────────────────────────────────────────────────────────

class CIROState extends ChangeNotifier {
  // Core data
  List<Map<String, dynamic>> _signals = [];
  Map<String, dynamic>? _crisis;
  Map<String, dynamic>? _plan;
  Map<String, dynamic>? _simulation;
  List<dynamic> _logs = [];
  bool _loading = false;
  String? _error;
  String _backendStatus = 'CHECKING...';

  // Autonomous pipeline state
  int _agentProgress = 0;          // 0–7 (one per agent step)
  List<String> _pipelineSteps = []; // live step messages for UI
  List<String> _autonomousActions = []; // final summary of what system did
  String _pipelineId = '';
  bool _broadcastTriggered = false;
  String _escalation = '';

  // Feature state
  int _predictionMinutes = 0;
  int _safeCheckCount = 0;
  bool _droneActive = false;
  bool _survivalMode = false;
  double _reliefTarget = 500000;
  double _reliefRaised = 125000;
  Map<String, String> _agencyStatus = {
    'POLICE': 'SYNCED',
    'FIRE': 'SYNCED',
    'MEDICAL': 'SYNCED',
  };

  // ── Getters ────────────────────────────────────────────────────────────
  List<Map<String, dynamic>> get signals => _signals;
  Map<String, dynamic>? get crisis => _crisis;
  Map<String, dynamic>? get plan => _plan;
  Map<String, dynamic>? get simulation => _simulation;
  List<dynamic> get logs => _logs;
  bool get loading => _loading;
  String? get error => _error;
  String get backendStatus => _backendStatus;
  int get agentProgress => _agentProgress;
  List<String> get pipelineSteps => _pipelineSteps;
  List<String> get autonomousActions => _autonomousActions;
  String get pipelineId => _pipelineId;
  bool get broadcastTriggered => _broadcastTriggered;
  String get escalation => _escalation;
  int get predictionMinutes => _predictionMinutes;
  int get safeCheckCount => _safeCheckCount;
  bool get droneActive => _droneActive;
  bool get survivalMode => _survivalMode;
  double get reliefTarget => _reliefTarget;
  double get reliefRaised => _reliefRaised;
  Map<String, String> get agencyStatus => _agencyStatus;

  // ── Feature Actions ────────────────────────────────────────────────────
  void setPrediction(int mins) { _predictionMinutes = mins; notifyListeners(); }
  void toggleDrone() { _droneActive = !_droneActive; notifyListeners(); }
  void toggleSurvivalMode() { _survivalMode = !_survivalMode; notifyListeners(); }
  void broadcastSafeCheck() { _safeCheckCount += 150; notifyListeners(); }
  void updateAgency(String agency, String status) { _agencyStatus[agency] = status; notifyListeners(); }

  Future<void> analyzePhoto() async {
    _loading = true;
    notifyListeners();
    await Future.delayed(const Duration(seconds: 2));
    _loading = false;
    notifyListeners();
  }

  // ─── BACKEND HEALTH CHECK ────────────────────────────────────────────────
  Future<bool> checkBackend() async {
    try {
      final res = await http.get(Uri.parse('$BACKEND_URL/health'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        _backendStatus = 'ONLINE';
        notifyListeners();
        return true;
      }
    } catch (_) {}
    _backendStatus = MOCK_FALLBACK ? 'OFFLINE (MOCK)' : 'OFFLINE';
    notifyListeners();
    return false;
  }

  // ─── AUTONOMOUS PIPELINE ─────────────────────────────────────────────────
  // ONE call → all 4 agents run autonomously → full result
  Future<void> autonomousRun(String rawText,
      {bool includeWeather = true, bool includeTraffic = true}) async {
    _loading = true;
    _error = null;
    _pipelineSteps = [];
    _agentProgress = 0;
    _autonomousActions = [];
    _broadcastTriggered = false;
    _escalation = '';
    notifyListeners();

    try {
      // Step 1: Ingestion
      _agentProgress = 1;
      _pipelineSteps.add('🔍 Ingestion Agent: Parsing signal with Gemini AI...');
      notifyListeners();

      // Start the actual backend request in the background
      final responseFuture = http.post(
        Uri.parse('$BACKEND_URL/api/autonomous_run'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'raw_text': rawText,
          'include_weather': includeWeather,
          'include_traffic': includeTraffic,
        }),
      ).timeout(const Duration(seconds: 90));

      // While waiting for the real AI, simulate the "thinking" steps to keep UI alive
      await Future.delayed(const Duration(seconds: 2));
      _agentProgress = 2;
      _pipelineSteps.add('📡 Orchestrator: Autonomously injecting sensor feeds...');
      notifyListeners();
      
      await Future.delayed(const Duration(seconds: 2));
      _agentProgress = 3;
      _pipelineSteps.add('🧠 Detection Agent: Cross-signal AI analysis...');
      notifyListeners();

      await Future.delayed(const Duration(seconds: 3));
      _agentProgress = 4;
      _pipelineSteps.add('⚡ Orchestrator: Autonomous escalation decision...');
      notifyListeners();

      // Now wait for the actual AI to finish the rest
      final res = await responseFuture;

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        _backendStatus = 'ONLINE';
        
        // Finalize steps
        _agentProgress = 5;
        _pipelineSteps.add('📋 Planning Agent: Response plan generated.');
        notifyListeners();
        await Future.delayed(const Duration(milliseconds: 500));
        
        _agentProgress = 6;
        _pipelineSteps.add('🗺️ Simulation Agent: Impact simulation complete.');
        notifyListeners();
        await Future.delayed(const Duration(milliseconds: 500));
        
        _agentProgress = 7;
        _pipelineSteps.add('📢 Orchestrator: Pipeline complete. Action triggered.');
        
        // Unpack data
        _signals = List<Map<String, dynamic>>.from(data['signals'] ?? []);
        _crisis = data['crisis'] as Map<String, dynamic>?;
        _plan = data['plan'] as Map<String, dynamic>?;
        _simulation = data['simulation'] as Map<String, dynamic>?;
        _logs = List<dynamic>.from(data['logs'] ?? []);
        _autonomousActions = List<String>.from(data['autonomous_actions'] ?? []);
        _pipelineId = data['pipeline_id'] ?? '';
        _broadcastTriggered = data['broadcast_triggered'] ?? false;
        _escalation = data['escalation'] ?? 'UNKNOWN';
      } else {
        throw Exception('Server error ${res.statusCode}');
      }
    }
 catch (e) {
      if (MOCK_FALLBACK) {
        _backendStatus = 'OFFLINE (MOCK)';
        await _runMockPipeline(rawText);
      } else {
        _error = 'Pipeline failed: $e';
      }
    }

    _loading = false;
    notifyListeners();
  }

  Future<void> _runMockPipeline(String rawText) async {
    final type = _detectTypeMock(rawText);
    final location = _extractLocationMock(rawText);

    _pipelineSteps = ['🔍 Ingestion Agent: Parsing signal with AI...'];
    _agentProgress = 1;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 700));

    _signals = [
      {'signal_type': type, 'location': location, 'raw_text': rawText, 'severity_hint': 'high', 'source': 'user_report'},
      {'signal_type': 'weather', 'location': location, 'raw_text': 'Weather monitoring at $location: conditions being assessed.', 'rainfall_mm': 0, 'source': 'weather_sensor_autonomous'},
      {'signal_type': 'traffic', 'location': location, 'raw_text': 'Traffic at $location: congestion 72%, speed 12km/h', 'congestion_percent': 72, 'source': 'traffic_sensor_autonomous'},
    ];
    _pipelineSteps.add('📡 Orchestrator: Autonomously injected 2 sensor feeds (weather + traffic)');
    _agentProgress = 2;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));

    _pipelineSteps.add('🧠 Detection Agent: Running cross-signal AI analysis...');
    _agentProgress = 3;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 900));
    _crisis = type == 'accident' ? mockCrisisAccident : mockCrisisFlooding;
    // Override location in mock crisis to match user input
    _crisis = Map<String, dynamic>.from(_crisis!);
    _crisis!['location'] = location;

    _pipelineSteps.add('⚡ Orchestrator: AUTONOMOUS decision — FULL ESCALATION triggered');
    _agentProgress = 4;
    _escalation = 'FULL_ESCALATION';
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 400));

    _pipelineSteps.add('📋 Planning Agent: Generating coordinated response plan...');
    _agentProgress = 5;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));
    _plan = type == 'accident' ? mockPlanAccident : mockPlanFlooding;

    _pipelineSteps.add('🗺️ Simulation Agent: Simulating traffic rerouting + dispatch...');
    _agentProgress = 6;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 700));
    _simulation = type == 'accident' ? mockSimulationAccident : mockSimulationFlooding;

    _pipelineSteps.add('📢 Orchestrator: Public broadcast TRIGGERED — 1,240 residents alerted!');
    _agentProgress = 7;
    _broadcastTriggered = true;
    _logs = type == 'accident' ? mockLogsAccident : mockLogsFlooding;
    _pipelineId = 'MOCK-${DateTime.now().millisecondsSinceEpoch}';
    final metrics = (_simulation!['metrics'] as Map);
    _autonomousActions = [
      '✅ Signal parsed: $type detected at $location',
      '✅ 2 sensor feeds autonomously injected (no user input)',
      '✅ Crisis confirmed: ${_crisis!['crisis_type']} at $location',
      '✅ Escalation: FULL_ESCALATION — autonomous threshold decision',
      '✅ ${(_plan!['actions'] as List).length} response actions planned by AI',
      '✅ ${metrics['vehicles_rerouted']} vehicles rerouted in simulation',
      '✅ Public broadcast TRIGGERED — ${metrics['alerts_sent_count']} residents notified',
    ];
    notifyListeners();
  }

  // ─── FETCH LOGS ──────────────────────────────────────────────────────────
  Future<void> fetchLogs() async {
    _loading = true;
    notifyListeners();
    try {
      final res = await http.get(Uri.parse('$BACKEND_URL/api/logs'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        _logs = data['logs'] as List? ?? [];
        _backendStatus = 'ONLINE';
      }
    } catch (e) {
      // Keep existing logs if available
      _backendStatus = 'OFFLINE (MOCK)';
    }
    _loading = false;
    notifyListeners();
  }

  // Navigate to plan/simulation using data already loaded from the autonomous pipeline.
  // Shows a brief loading animation for a polished feel.
  Future<void> generatePlan() async {
    if (_plan != null) return; // Already loaded
    _loading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));
    _loading = false;
    notifyListeners();
  }

  Future<void> simulate() async {
    if (_simulation != null) return; // Already loaded
    _loading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));
    _loading = false;
    notifyListeners();
  }

  // ─── RESET ───────────────────────────────────────────────────────────────
  Future<void> reset() async {
    _signals = [];
    _crisis = null;
    _plan = null;
    _simulation = null;
    _logs = [];
    _error = null;
    _predictionMinutes = 0;
    _safeCheckCount = 0;
    _droneActive = false;
    _agentProgress = 0;
    _pipelineSteps = [];
    _autonomousActions = [];
    _broadcastTriggered = false;
    _escalation = '';
    _pipelineId = '';
    try {
      await http.post(Uri.parse('$BACKEND_URL/api/reset'),
          headers: {'Content-Type': 'application/json'})
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
    notifyListeners();
  }

  // ─── HELPERS ─────────────────────────────────────────────────────────────
  String _detectTypeMock(String text) {
    final lower = text.toLowerCase();
    if (lower.contains('accident') || lower.contains('crash') || lower.contains('hadsa') || lower.contains('ٹکر') || lower.contains('حادثہ')) return 'accident';
    if (lower.contains('fire') || lower.contains('aag') || lower.contains('آگ') || lower.contains('smoke')) return 'fire';
    if (lower.contains('earthquake') || lower.contains('zalzala') || lower.contains('زلزلہ')) return 'earthquake';
    return 'flooding';
  }

  /// Extract location from user text (e.g. "E-9 mein pani" → "E-9")
  String _extractLocationMock(String text) {
    // Match Islamabad sector patterns like G-10, E-9, F-11, I-8, H-13, D-12, or G 10
    final sectorRegex = RegExp(r'\b([A-IJ][-\s]?\d{1,2})\b', caseSensitive: false);
    final match = sectorRegex.firstMatch(text);
    if (match != null) {
      String sector = match.group(1)!.toUpperCase();
      // Normalize "G 10" to "G-10"
      return sector.replaceAll(' ', '-');
    }
    // Match specific cities first
    final cities = ['Lahore', 'Karachi', 'Islamabad', 'Rawalpindi', 'Peshawar', 'Quetta', 'Faisalabad', 'Multan', 'Hyderabad', 'Sukkur', 'Larkana', 'Nawabshah', 'Mirpur Khas', 'Abbottabad', 'Mansehra', 'Swat', 'Gilgit', 'Skardu', 'Muzaffarabad', 'Gwadar', 'Hub', 'Turbat', 'Sialkot', 'Gujranwala', 'Sargodha', 'Bahawalpur', 'Sahiwal', 'Okara', 'Vehari', 'Khanewal', 'Dadu', 'Sibi'];
    for (final city in cities) {
      if (text.toLowerCase().contains(city.toLowerCase())) return city;
    }
    
    // Dynamic extraction: Try to find words before/after location prepositions
    final prepRegex = RegExp(r'\b(in|at|near|mein|par|ko)\s+([A-Za-z]+)\b', caseSensitive: false);
    final prepMatch = prepRegex.firstMatch(text);
    if (prepMatch != null) {
      String loc = prepMatch.group(2)!;
      if (loc.length > 2 && !['hai', 'hain', 'tha', 'thi'].contains(loc.toLowerCase())) {
        return loc[0].toUpperCase() + loc.substring(1).toLowerCase();
      }
    }
    
    final prepRegexBefore = RegExp(r'\b([A-Za-z]+)\s+(mein|in|at|near|ko|par)\b', caseSensitive: false);
    final prepMatchBefore = prepRegexBefore.firstMatch(text);
    if (prepMatchBefore != null) {
      String loc = prepMatchBefore.group(1)!;
      if (loc.length > 2 && !['accident', 'flood', 'fire', 'pani', 'aag', 'the'].contains(loc.toLowerCase())) {
        return loc[0].toUpperCase() + loc.substring(1).toLowerCase();
      }
    }

    return 'Unknown Location';
  }
}
