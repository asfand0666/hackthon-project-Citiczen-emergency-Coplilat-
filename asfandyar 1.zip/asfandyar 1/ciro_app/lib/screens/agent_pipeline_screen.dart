import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math' as math;
import '../state/ciro_state.dart';
import 'crisis_screen.dart';

/// Shown while the autonomous pipeline is running.
/// Displays each agent step as it completes — demonstrating real agentic behavior.
class AgentPipelineScreen extends StatefulWidget {
  final String rawText;
  const AgentPipelineScreen({super.key, required this.rawText});

  @override
  State<AgentPipelineScreen> createState() => _AgentPipelineScreenState();
}

class _AgentPipelineScreenState extends State<AgentPipelineScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  bool _navigated = false;

  final List<_AgentInfo> _agents = [
    _AgentInfo('Ingestion Agent', '🔍', Colors.blue, 'Parsing signal with Gemini AI'),
    _AgentInfo('Orchestrator', '📡', Colors.teal, 'Autonomously injecting sensor feeds'),
    _AgentInfo('Detection Agent', '🧠', Colors.orange, 'Cross-signal crisis analysis'),
    _AgentInfo('Orchestrator', '⚡', Colors.red, 'Autonomous escalation decision'),
    _AgentInfo('Planning Agent', '📋', Colors.purple, 'Generating response plan'),
    _AgentInfo('Simulation Agent', '🗺️', Colors.green, 'Simulating execution'),
    _AgentInfo('Orchestrator', '📢', Colors.deepOrange, 'Public broadcast decision'),
  ];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    // Start the autonomous pipeline
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CIROState>().autonomousRun(widget.rawText);
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();
    final progress = state.agentProgress;
    final isDone = !state.loading && progress >= 7;

    // Navigate when done
    if (isDone && !_navigated && state.crisis != null) {
      _navigated = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const CrisisScreen()),
        );
      });
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D1B2A),
        elevation: 0,
        title: const Text('Autonomous Agent Pipeline',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        leading: isDone
            ? IconButton(
                icon: const Icon(Icons.close, color: Colors.white70),
                onPressed: () => Navigator.pop(context),
              )
            : const SizedBox(),
      ),
      body: Column(
        children: [
          // ── Header ──────────────────────────────────────────────────────
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08))),
            ),
            child: Column(children: [
              // Pipeline ID
              Text(state.pipelineId.isEmpty ? 'Initializing pipeline...' : '🔗 ${state.pipelineId}',
                  style: const TextStyle(fontFamily: 'monospace', color: Colors.white38, fontSize: 11)),
              const SizedBox(height: 16),

              // Overall progress bar
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progress / 7.0,
                  backgroundColor: Colors.white12,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    isDone ? Colors.greenAccent : Colors.blue.shade300,
                  ),
                  minHeight: 8,
                ),
              ),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${(progress / 7.0 * 100).toInt()}% complete',
                    style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                Text('$progress / 7 agents',
                    style: const TextStyle(color: Colors.white38, fontSize: 11)),
              ]),
            ]),
          ),

          // ── Horizontal AI Node Pipeline (Data Flow) ──────────────────────
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20),
            color: Colors.black12,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildFlowIndicator('Ingest', progress >= 1, isActive: progress == 1),
                _buildFlowConnector(progress > 1),
                _buildFlowIndicator('Detect', progress >= 3, isActive: progress == 3),
                _buildFlowConnector(progress > 3),
                _buildFlowIndicator('Plan', progress >= 5, isActive: progress == 5),
                _buildFlowConnector(progress > 5),
                _buildFlowIndicator('Simulate', progress >= 6, isActive: progress == 6),
              ],
            ),
          ),

          // ── Agent Steps ──────────────────────────────────────────────────
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _agents.length,
              itemBuilder: (context, i) {
                final agent = _agents[i];
                final stepNum = i + 1;
                final isComplete = progress > stepNum;
                final isActive = progress == stepNum && state.loading;
                final isPending = progress < stepNum;

                return _AgentStepCard(
                  agent: agent,
                  stepNum: stepNum,
                  isComplete: isComplete,
                  isActive: isActive,
                  isPending: isPending,
                  pulseController: _pulseController,
                  liveMessage: state.pipelineSteps.length >= stepNum
                      ? state.pipelineSteps[stepNum - 1]
                      : null,
                );
              },
            ),
          ),

          // ── Final Autonomous Actions Summary ─────────────────────────────
          if (isDone && state.autonomousActions.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.greenAccent.withOpacity(0.08),
                border: Border(top: BorderSide(color: Colors.greenAccent.withOpacity(0.2))),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.auto_awesome, color: Colors.greenAccent, size: 16),
                    SizedBox(width: 8),
                    Text('Autonomous Actions Taken',
                        style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold, fontSize: 13)),
                  ]),
                  const SizedBox(height: 8),
                  ...state.autonomousActions.take(4).map((action) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(action,
                        style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  )),
                ],
              ),
            ),

          // ── Bottom Status ─────────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.black26,
            child: isDone
                ? Container(
                    height: 48,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(colors: [Colors.red.shade700, Colors.red.shade500]),
                    ),
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.warning_rounded, color: Colors.white),
                      label: const Text('VIEW CRISIS REPORT | بحران دیکھیں',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => Navigator.pushReplacement(
                          context, MaterialPageRoute(builder: (_) => const CrisisScreen())),
                    ),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (_, __) => CustomPaint(
                            painter: _SiriWavePainter(_pulseController.value),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text('CIRO AI ORCHESTRATOR THINKING...',
                          style: TextStyle(color: Colors.blueAccent, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildFlowIndicator(String label, bool isComplete, {bool isActive = false}) {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (_, __) => Container(
            width: 24, height: 24,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive 
                ? Colors.blueAccent.withOpacity(0.4 + 0.6 * _pulseController.value)
                : isComplete ? Colors.greenAccent : Colors.white12,
              boxShadow: isActive ? [BoxShadow(color: Colors.blueAccent.withOpacity(0.5), blurRadius: 10)] : null,
              border: Border.all(color: isActive ? Colors.white : (isComplete ? Colors.green : Colors.transparent)),
            ),
            child: isComplete && !isActive 
              ? const Icon(Icons.check, size: 14, color: Colors.black)
              : null,
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(color: isActive ? Colors.white : Colors.white54, fontSize: 10, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildFlowConnector(bool isComplete) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.only(bottom: 20, left: 8, right: 8),
        color: isComplete ? Colors.greenAccent : Colors.white12,
      ),
    );
  }
}

class _AgentInfo {
  final String name;
  final String emoji;
  final Color color;
  final String task;
  const _AgentInfo(this.name, this.emoji, this.color, this.task);
}

class _AgentStepCard extends StatelessWidget {
  final _AgentInfo agent;
  final int stepNum;
  final bool isComplete;
  final bool isActive;
  final bool isPending;
  final AnimationController pulseController;
  final String? liveMessage;

  const _AgentStepCard({
    required this.agent,
    required this.stepNum,
    required this.isComplete,
    required this.isActive,
    required this.isPending,
    required this.pulseController,
    this.liveMessage,
  });

  @override
  Widget build(BuildContext context) {
    final color = isPending ? Colors.white24 : agent.color;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isActive
            ? agent.color.withOpacity(0.12)
            : isComplete
                ? Colors.white.withOpacity(0.04)
                : Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isActive
              ? agent.color.withOpacity(0.4)
              : isComplete
                  ? Colors.white12
                  : Colors.white.withOpacity(0.06),
        ),
      ),
      child: Row(children: [
        // Step indicator
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isComplete
                ? Colors.greenAccent.withOpacity(0.15)
                : isActive
                    ? agent.color.withOpacity(0.2)
                    : Colors.white.withOpacity(0.05),
            border: Border.all(
              color: isComplete ? Colors.greenAccent.withOpacity(0.5) : color.withOpacity(0.4),
            ),
          ),
          child: isActive
              ? Padding(
                  padding: const EdgeInsets.all(10),
                  child: CircularProgressIndicator(
                    strokeWidth: 2, color: agent.color,
                  ),
                )
              : Center(
                  child: isComplete
                      ? const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 22)
                      : Text(agent.emoji, style: const TextStyle(fontSize: 18)),
                ),
        ),
        const SizedBox(width: 14),

        // Content
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(agent.name,
                  style: TextStyle(
                    color: isPending ? Colors.white30 : Colors.white,
                    fontWeight: FontWeight.bold, fontSize: 13,
                  )),
              const SizedBox(width: 8),
              if (isActive)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: agent.color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text('RUNNING',
                      style: TextStyle(color: agent.color, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
                ),
              if (isComplete)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.greenAccent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('DONE',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
                ),
            ]),
            const SizedBox(height: 3),
            Text(
              liveMessage ?? agent.task,
              style: TextStyle(
                color: isPending ? Colors.white.withOpacity(0.2) : Colors.white54,
                fontSize: 11,
              ),
            ),
          ]),
        ),

        // Step number
        Text('#$stepNum',
            style: TextStyle(color: Colors.white.withOpacity(isPending ? 0.1 : 0.25),
                fontSize: 11, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

// ── Custom Waveform Painter ──────────────────────────────────────────

class _SiriWavePainter extends CustomPainter {
  final double animationValue;
  _SiriWavePainter(this.animationValue);

  @override
  void paint(Canvas canvas, Size size) {
    final paint1 = Paint()
      ..color = Colors.blueAccent.withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final paint2 = Paint()
      ..color = Colors.cyanAccent.withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
      
    final paint3 = Paint()
      ..color = Colors.purpleAccent.withOpacity(0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    final path1 = Path();
    final path2 = Path();
    final path3 = Path();

    final width = size.width;
    final height = size.height;
    final centerY = height / 2;

    for (double i = 0; i <= width; i++) {
      // Create tapering effect at the edges
      final taper = math.sin((i / width) * math.pi);
      
      final y1 = centerY + math.sin((i / width * math.pi * 4) + (animationValue * math.pi * 2)) * 15 * taper;
      final y2 = centerY + math.sin((i / width * math.pi * 3) - (animationValue * math.pi * 2)) * 20 * taper;
      final y3 = centerY + math.sin((i / width * math.pi * 5) + (animationValue * math.pi * 4)) * 10 * taper;

      if (i == 0) {
        path1.moveTo(i, y1);
        path2.moveTo(i, y2);
        path3.moveTo(i, y3);
      } else {
        path1.lineTo(i, y1);
        path2.lineTo(i, y2);
        path3.lineTo(i, y3);
      }
    }

    canvas.drawPath(path3, paint3);
    canvas.drawPath(path1, paint1);
    canvas.drawPath(path2, paint2);
  }

  @override
  bool shouldRepaint(covariant _SiriWavePainter oldDelegate) => oldDelegate.animationValue != animationValue;
}
