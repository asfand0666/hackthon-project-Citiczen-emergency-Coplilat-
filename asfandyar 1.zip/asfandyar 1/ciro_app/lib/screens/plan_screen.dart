import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/ciro_state.dart';
import 'simulation_map_screen.dart';

class PlanScreen extends StatelessWidget {
  const PlanScreen({super.key});

  // Returns icon and colour for each action type
  Map<String, dynamic> _actionStyle(String type) {
    switch (type) {
      case 'traffic_reroute':
        return {
          'icon': Icons.alt_route,
          'color': Colors.blue[700]!,
          'label': 'Traffic Reroute'
        };
      case 'emergency_dispatch':
        return {
          'icon': Icons.local_hospital,
          'color': Colors.red[700]!,
          'label': 'Emergency Dispatch'
        };
      case 'public_alert':
        return {
          'icon': Icons.campaign,
          'color': Colors.orange[700]!,
          'label': 'Public Alert'
        };
      case 'resource_allocation':
        return {
          'icon': Icons.inventory_2,
          'color': Colors.green[700]!,
          'label': 'Resource Allocation'
        };
      default:
        return {
          'icon': Icons.task_alt,
          'color': Colors.grey[700]!,
          'label': type
        };
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();
    final plan = state.plan;
    final actions = plan?['actions'] as List? ?? [];

    return Scaffold(
      backgroundColor: const Color(0xFFF9FBFF),
      appBar: AppBar(
        title: const Text('Response Plan | جوابی منصوبہ',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: const Color(0xFFC55A11),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFC55A11), Color(0xFFE87E33)],
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // ── Plan Summary Header ───────────────────
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4)],
            ),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: Colors.orange.shade50, shape: BoxShape.circle),
                child: const Icon(Icons.info_outline, color: Colors.orange, size: 20),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${actions.length} ACTIONS PLANNED',
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.1, color: Colors.orange),
                  ),
                  const Text('منصوبہ بندی شدہ اقدامات', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10)),
                child: Text('PRIORITY: ${plan?['priority_level']?.toString().toUpperCase() ?? 'HIGH'} | ترجیح',
                    style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.red.shade700)),
              ),
            ]),
          ),

          // ── Action Cards List ─────────────────────
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: actions.length,
              itemBuilder: (context, index) {
                final action = actions[index] as Map;
                final type = action['type']?.toString() ?? 'unknown';
                final style = _actionStyle(type);
                final priority = action['priority'] ?? index + 1;
                final eta = action['estimated_time_minutes'] ?? '?';

                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4)),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: IntrinsicHeight(
                      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        // Left color strip
                        Container(width: 6, color: style['color'] as Color),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(children: [
                                  CircleAvatar(
                                    radius: 12,
                                    backgroundColor: (style['color'] as Color).withOpacity(0.1),
                                    child: Text('$priority',
                                        style: TextStyle(color: style['color'] as Color, fontWeight: FontWeight.bold, fontSize: 11)),
                                  ),
                                  const SizedBox(width: 10),
                                  Icon(style['icon'] as IconData, color: style['color'] as Color, size: 18),
                                  const SizedBox(width: 8),
                                  Text(style['label'] as String,
                                      style: TextStyle(fontWeight: FontWeight.bold, color: style['color'] as Color, fontSize: 15)),
                                  const Spacer(),
                                  Text('$eta min', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade600)),
                                ]),
                                const SizedBox(height: 12),
                                Text(action['description']?.toString() ?? '',
                                    style: TextStyle(fontSize: 13, height: 1.5, color: Colors.grey.shade800)),
                                if (action['target_location'] != null) ...[
                                  const SizedBox(height: 10),
                                  Row(children: [
                                    const Icon(Icons.location_pin, size: 14, color: Colors.grey),
                                    const SizedBox(width: 4),
                                    Text(action['target_location'].toString(),
                                        style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w500)),
                                  ]),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),

          // ── Run Simulation Button ─────────────────
          Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              height: 55,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [Color(0xFF1E7E34), Color(0xFF28A745)]),
                boxShadow: [BoxShadow(color: const Color(0xFF1E7E34).withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
              ),
              child: ElevatedButton.icon(
                icon: state.loading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.play_circle_fill, color: Colors.white),
                label: Text(
                  state.loading ? 'Loading Simulation...' : 'Run Simulation | نقشہ دیکھیں',
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: state.loading
                    ? null
                    : () {
                        if (state.simulation != null && context.mounted) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const SimulationMapScreen()));
                        }
                      },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
