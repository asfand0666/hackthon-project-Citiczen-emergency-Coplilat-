import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:flutter/services.dart';
import 'dart:math';
import 'dart:ui';
import '../state/ciro_state.dart';
import 'outcome_screen.dart';

class SimulationMapScreen extends StatefulWidget {
  const SimulationMapScreen({super.key});

  @override
  State<SimulationMapScreen> createState() => _SimulationMapScreenState();
}

class _SimulationMapScreenState extends State<SimulationMapScreen>
    with TickerProviderStateMixin {
  GoogleMapController? _mapController;
  final TextEditingController _originController = TextEditingController();
  final TextEditingController _destController = TextEditingController();
  bool _showUserRoute = false;
  bool _isFabOpen = false;


  /// Dynamically resolve crisis center from state — supports ALL Pakistan locations
  LatLng _getCrisisCenter(CIROState state) {
    final coords = state.crisis?['coordinates'] as List?;
    if (coords != null && coords.length >= 2) {
      return LatLng((coords[0] as num).toDouble(), (coords[1] as num).toDouble());
    }
    // Fallback: try signal coordinates
    for (final sig in state.signals) {
      final sc = sig['coordinates'] as List?;
      if (sc != null && sc.length >= 2) {
        return LatLng((sc[0] as num).toDouble(), (sc[1] as num).toDouble());
      }
    }
    return const LatLng(30.3753, 69.3451); // Pakistan center fallback
  }

  late AnimationController _scanController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scanController.dispose();
    _pulseController.dispose();
    _originController.dispose();
    _destController.dispose();
    super.dispose();

  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();
    final sim = state.simulation;

    final markers = (sim?['markers'] as List? ?? []).map((m) {
      return Marker(
        markerId: MarkerId(m['id'] ?? UniqueKey().toString()),
        position: LatLng(m['lat'], m['lng']),
        icon: BitmapDescriptor.defaultMarkerWithHue(
          m['type'] == 'crisis'
              ? BitmapDescriptor.hueRed
              : BitmapDescriptor.hueAzure,
        ),
        infoWindow: InfoWindow(title: m['label']),
      );
    }).toSet();

    final polylines = (sim?['polylines'] as List? ?? []).map((p) {
      return Polyline(
        polylineId: PolylineId(p['id'] ?? UniqueKey().toString()),
        points: (p['points'] as List)
            .map((pt) => LatLng(pt['lat'], pt['lng']))
            .toList(),
        color: p['color'] == 'green' ? Colors.green : Colors.red,
        width: 4,
      );
    }).toSet();

    if (_showUserRoute) {
      final crisis = _getCrisisCenter(state);
      // Generate a mock safe route avoiding the crisis center
      polylines.add(
        Polyline(
          polylineId: const PolylineId('user_safe_route'),
          points: [
            LatLng(crisis.latitude - 0.02, crisis.longitude - 0.02),
            LatLng(crisis.latitude - 0.02, crisis.longitude + 0.02),
            LatLng(crisis.latitude + 0.02, crisis.longitude + 0.02),
            LatLng(crisis.latitude + 0.02, crisis.longitude - 0.02),
          ],
          color: Colors.blueAccent,
          width: 5,
          patterns: [PatternItem.dash(20), PatternItem.gap(10)],
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        title: const Text('Simulation Map | نقشہ',
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
        backgroundColor: const Color(0xFF1E7E34),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xFF1E7E34), Color(0xFF28A745)]),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          if (state.droneActive)
            Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.redAccent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(children: [
                Icon(Icons.circle, color: Colors.white, size: 8),
                SizedBox(width: 4),
                Text('LIVE',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
              ]),
            )
        ],
      ),
      body: Stack(
        children: [
          // ── Google Map ─────────────────────────────
          GoogleMap(
            onMapCreated: (controller) => _mapController = controller,
            initialCameraPosition: CameraPosition(
              target: _getCrisisCenter(state),
              zoom: 13.5,
            ),
            markers: markers,
            polylines: polylines,
            myLocationButtonEnabled: false,
          ),

          // ── WEATHER PARTICLE OVERLAY ───────────────
          if (state.crisis?['crisis_type'] == 'urban_flooding')
            IgnorePointer(
              child: AnimatedBuilder(
                animation: _scanController,
                builder: (_, __) => CustomPaint(
                  painter: _WeatherParticlePainter(_scanController.value),
                  child: const SizedBox.expand(),
                ),
              ),
            ),

          // ── DRONE VISION OVERLAY ───────────────────
          if (state.droneActive) _buildDroneOverlay(state),

          // ── Top-Right Stats ────────────────────────
          if (!state.droneActive)
            Positioned(
              top: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _statChip(Icons.directions_car_rounded,
                      '${sim?['metrics']?['vehicles_rerouted'] ?? 0} rerouted',
                      Colors.green),
                  const SizedBox(height: 8),
                  if (state.safeCheckCount > 0)
                    _statChip(Icons.people_alt_rounded,
                        '${state.safeCheckCount} Safe-Checks', Colors.blue),
                  const SizedBox(height: 8),
                  _statChip(Icons.campaign_rounded,
                      '${sim?['alerts']?.length ?? 0} alerts', Colors.orange),
                ],
              ),
            ),

          // ── Safe Navigation Card (Glassmorphic) ────────────────────────
          if (!state.droneActive)
            Positioned(
              top: 16,
              left: 16,
              right: 180, // Leave room for stats
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.7),
                      border: Border.all(color: Colors.white.withOpacity(0.5)),
                    ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Safe Navigation', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1F3864))),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 35,
                      child: TextField(
                        controller: _originController,
                        decoration: InputDecoration(
                          hintText: 'From: (e.g. F-8)',
                          hintStyle: const TextStyle(fontSize: 12),
                          prefixIcon: const Icon(Icons.my_location, size: 16, color: Colors.blue),
                          contentPadding: EdgeInsets.zero,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 35,
                      child: TextField(
                        controller: _destController,
                        decoration: InputDecoration(
                          hintText: 'To: (e.g. Blue Area)',
                          hintStyle: const TextStyle(fontSize: 12),
                          prefixIcon: const Icon(Icons.location_on, size: 16, color: Colors.red),
                          contentPadding: EdgeInsets.zero,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1E7E34),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        onPressed: () {
                          if (_originController.text.isNotEmpty && _destController.text.isNotEmpty) {
                            setState(() => _showUserRoute = true);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Safe route generated avoiding affected area.')),
                            );
                          }
                        },
                        child: const Text('Find Safe Route', style: TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ),
                  ], // End of Column children
                ), // End of Column
              ), // End of Container
            ), // End of BackdropFilter
          ), // End of ClipRRect
        ), // End of Positioned

          // ── Time Travel Slider ────────────────────
          if (!state.droneActive)
            Positioned(
              bottom: 150,
              left: 16,
              right: 16,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10)
                  ],
                ),
                child: Column(children: [
                  Row(children: [
                    const Icon(Icons.access_time_filled_rounded,
                        size: 16, color: Color(0xFF1F3864)),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          state.predictionMinutes == 0
                              ? 'Current Situation (Real-time)'
                              : '⚠️  Crisis Forecast: T+${state.predictionMinutes} minutes',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              color: state.predictionMinutes == 0
                                  ? Colors.green
                                  : Colors.red),
                        ),
                        const Text('مصنوعی ذہانت کی پیشن گوئی', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ]),
                  Slider(
                    value: state.predictionMinutes.toDouble(),
                    min: 0,
                    max: 120,
                    divisions: 4,
                    activeColor: state.predictionMinutes == 0
                        ? Colors.green
                        : Colors.red,
                    label: state.predictionMinutes == 0
                        ? 'Now'
                        : '+${state.predictionMinutes} min',
                    onChanged: (val) => state.setPrediction(val.toInt()),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: ['Now', '+30m', '+60m', '+90m', '+120m']
                        .map((t) => Text(t,
                            style: const TextStyle(
                                fontSize: 9, color: Colors.grey)))
                        .toList(),
                  ),
                ]),
              ),
            ),

          // ── Side FABs: Expandable Tactical Menu ──────────
          if (!state.droneActive)
            Positioned(
              bottom: 100,
              left: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_isFabOpen) ...[
                    _buildFab(
                      icon: Icons.videocam_rounded,
                      label: 'Drone',
                      color: Colors.blue,
                      onTap: () {
                        HapticFeedback.lightImpact();
                        setState(() => _isFabOpen = false);
                        state.toggleDrone();
                      },
                    ),
                    const SizedBox(height: 12),
                    _buildFab(
                      icon: Icons.wifi_tethering_rounded,
                      label: 'Broadcast',
                      color: Colors.orange,
                      onTap: () {
                        HapticFeedback.heavyImpact(); // High-stakes action
                        setState(() => _isFabOpen = false);
                        state.broadcastSafeCheck();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: Colors.orange.shade700,
                            content: const Row(children: [
                              Icon(Icons.broadcast_on_personal, color: Colors.white),
                              SizedBox(width: 12),
                              Text('Safe-Check broadcast to 1.2km radius!',
                                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            ]),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                  ],
                  FloatingActionButton(
                    heroTag: 'tactical_fab',
                    backgroundColor: const Color(0xFF1F3864),
                    onPressed: () {
                      HapticFeedback.selectionClick();
                      setState(() => _isFabOpen = !_isFabOpen);
                    },
                    child: AnimatedRotation(
                      turns: _isFabOpen ? 0.125 : 0,
                      duration: const Duration(milliseconds: 200),
                      child: const Icon(Icons.add, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),

          // ── View Outcomes Button ──────────────────
          if (!state.droneActive)
            Positioned(
              bottom: 25,
              left: 16,
              right: 16,
              child: Container(
                height: 58,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: const LinearGradient(
                      colors: [Color(0xFF1F3864), Color(0xFF2C539E)]),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xFF1F3864).withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 6))
                  ],
                ),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.analytics_rounded,
                      color: Colors.white, size: 22),
                  label: const Text('View Outcome Metrics | نتائج دیکھیں',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                  ),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const OutcomeScreen())),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── Full Screen Drone Vision Overlay ──────────────────────────
  Widget _buildDroneOverlay(CIROState state) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.88),
        child: Column(
          children: [
            // Drone header bar with prominent close button
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              color: Colors.black,
              child: Row(children: [
                // ── X Close Button (top-left) ──
                GestureDetector(
                  onTap: () => state.toggleDrone(),
                  child: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.5), blurRadius: 8)],
                    ),
                    child: const Icon(Icons.close, color: Colors.white, size: 20),
                  ),
                ),
                const SizedBox(width: 12),
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (_, __) => Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Colors.redAccent
                          .withOpacity(0.5 + _pulseController.value * 0.5),
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('DRONE-01 | CAM-ISB-9921 | AI VISION',
                      style: TextStyle(
                          color: Colors.green,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0,
                          fontFamily: 'monospace')),
                ),
              ]),
            ),

            // Drone video area
            Expanded(
              child: Stack(
                children: [
                  // Green scanline animation
                  AnimatedBuilder(
                    animation: _scanController,
                    builder: (_, __) {
                      return CustomPaint(
                        painter: _DroneVisionPainter(
                            _scanController.value, _pulseController.value),
                        child: const SizedBox.expand(),
                      );
                    },
                  ),

                  // Corner brackets (tactical UI)
                  Positioned(top: 20, left: 20, child: _cornerBracket()),
                  Positioned(
                      top: 20,
                      right: 20,
                      child: Transform.rotate(
                          angle: pi / 2, child: _cornerBracket())),
                  Positioned(
                      bottom: 20,
                      left: 20,
                      child: Transform.rotate(
                          angle: -pi / 2, child: _cornerBracket())),
                  Positioned(
                      bottom: 20,
                      right: 20,
                      child: Transform.rotate(
                          angle: pi, child: _cornerBracket())),

                  // Sci-Fi Scrolling Tapes (Altitude & Speed)
                  Positioned(
                    left: 10, top: 100, bottom: 100,
                    child: _buildScrollingTape('ALT (m)', _scanController, 100, 150),
                  ),
                  Positioned(
                    right: 10, top: 100, bottom: 100,
                    child: _buildScrollingTape('SPD (kt)', _scanController, 0, 50, reverse: true),
                  ),

                  // TV Static Overlay for Analog Feel
                  IgnorePointer(
                    child: Opacity(
                      opacity: 0.04,
                      child: AnimatedBuilder(
                        animation: _scanController,
                        builder: (_, __) => CustomPaint(
                          painter: _StaticNoisePainter(Random().nextDouble()),
                          child: const SizedBox.expand(),
                        ),
                      ),
                    ),
                  ),

                  // AI Detection Boxes
                  Positioned(
                    top: 100,
                    left: 60,
                    child: _aiDetectionBox('VEHICLE: STALLED', Colors.red,
                        _pulseController),
                  ),
                  Positioned(
                    top: 180,
                    right: 70,
                    child: _aiDetectionBox(
                        'ROAD: 80% BLOCKED', Colors.orange, _pulseController),
                  ),
                  Positioned(
                    bottom: 140,
                    left: 100,
                    child: _aiDetectionBox(
                        'VICTIM DETECTED', Colors.redAccent, _pulseController),
                  ),

                  // Center crosshair
                  Center(
                    child: CustomPaint(
                      painter: _CrosshairPainter(),
                      child: const SizedBox(width: 60, height: 60),
                    ),
                  ),

                  // Bottom AI data strip
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      color: Colors.black.withOpacity(0.8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(children: [
                          _dataTag('GPS', '33.668°N 73.001°E'),
                          _dataTag('ALT', '120m AGL'),
                          _dataTag('SPEED', '0.0 km/h'),
                          _dataTag('TEMP', '31°C'),
                          _dataTag('AI CONF', '94.2%'),
                          _dataTag('THREATS', '2 DETECTED'),
                        ]),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cornerBracket() {
    return SizedBox(
      width: 24,
      height: 24,
      child: CustomPaint(painter: _CornerBracketPainter()),
    );
  }

  Widget _buildScrollingTape(String label, AnimationController anim, int minVal, int maxVal, {bool reverse = false}) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) {
        final offset = (anim.value * 50) % 20;
        return Column(
          children: [
            Text(label, style: const TextStyle(color: Colors.green, fontSize: 8, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Expanded(
              child: ClipRect(
                child: Transform.translate(
                  offset: Offset(0, reverse ? offset : -offset),
                  child: Column(
                    children: List.generate(20, (i) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text('${minVal + (i * 5)} -', style: const TextStyle(color: Colors.green, fontSize: 9)),
                      );
                    }),
                  ),
                ),
              ),
            ),
          ],
        );
      }
    );
  }

  Widget _aiDetectionBox(
      String label, Color color, AnimationController pulse) {
    return AnimatedBuilder(
      animation: pulse,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          border: Border.all(
              color: color.withOpacity(0.5 + pulse.value * 0.5), width: 2),
          color: color.withOpacity(0.05 + pulse.value * 0.05),
        ),
        child: Text(label,
            style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.8)),
      ),
    );
  }

  Widget _dataTag(String key, String value) {
    return Padding(
      padding: const EdgeInsets.only(right: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(key,
              style: const TextStyle(
                  color: Colors.grey, fontSize: 8, letterSpacing: 0.5)),
          Text(value,
              style: const TextStyle(
                  color: Colors.green,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }

  Widget _buildFab(
      {required IconData icon,
      required String label,
      required Color color,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4))
            ],
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(height: 4),
        Text(label,
            style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.bold,
                color: color)),
      ]),
    );
  }

  Widget _statChip(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05), blurRadius: 5)
        ],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 8),
        Text(text,
            style: TextStyle(
                color: color,
                fontWeight: FontWeight.w900,
                fontSize: 12)),
      ]),
    );
  }
}

// ── Custom Painters ────────────────────────────────────────────

class _DroneVisionPainter extends CustomPainter {
  final double scanProgress;
  final double pulse;
  _DroneVisionPainter(this.scanProgress, this.pulse);

  @override
  void paint(Canvas canvas, Size size) {
    // Scanning line
    final scanY = size.height * scanProgress;
    final scanPaint = Paint()
      ..color = Colors.green.withOpacity(0.6)
      ..strokeWidth = 2;
    canvas.drawLine(Offset(0, scanY), Offset(size.width, scanY), scanPaint);

    // Grid overlay
    final gridPaint = Paint()
      ..color = Colors.green.withOpacity(0.08)
      ..strokeWidth = 0.5;
    for (double x = 0; x < size.width; x += 40) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += 40) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
  }

  @override
  bool shouldRepaint(_DroneVisionPainter old) =>
      old.scanProgress != scanProgress;
}

class _CrosshairPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.green
      ..strokeWidth = 1.5;
    final cx = size.width / 2;
    final cy = size.height / 2;
    canvas.drawLine(Offset(0, cy), Offset(size.width, cy), paint);
    canvas.drawLine(Offset(cx, 0), Offset(cx, size.height), paint);
    canvas.drawCircle(Offset(cx, cy), 10, paint..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(_CrosshairPainter old) => false;
}

class _CornerBracketPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.green
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square;
    canvas.drawLine(Offset.zero, Offset(size.width, 0), paint);
    canvas.drawLine(Offset.zero, Offset(0, size.height), paint);
  }

  @override
  bool shouldRepaint(_CornerBracketPainter old) => false;
}

// ── New Sci-Fi / Weather Painters ────────────────────────────────────────

class _WeatherParticlePainter extends CustomPainter {
  final double animationValue;
  _WeatherParticlePainter(this.animationValue);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue.withOpacity(0.3)
      ..strokeWidth = 1.5;
    
    // Create random stable seed so particles just move down
    final random = Random(42); 
    
    for (int i = 0; i < 150; i++) {
      final x = random.nextDouble() * size.width;
      final startY = random.nextDouble() * size.height;
      final speed = 0.5 + random.nextDouble() * 1.5;
      
      // Calculate current position with wrap-around
      double currentY = (startY + (animationValue * size.height * speed * 2)) % size.height;
      
      canvas.drawLine(
        Offset(x, currentY),
        Offset(x - 5, currentY + 15), // Diagonal rain
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WeatherParticlePainter old) => old.animationValue != animationValue;
}

class _StaticNoisePainter extends CustomPainter {
  final double seed;
  _StaticNoisePainter(this.seed);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white;
    final random = Random((seed * 1000).toInt());
    for (int i = 0; i < 500; i++) {
      canvas.drawCircle(
        Offset(random.nextDouble() * size.width, random.nextDouble() * size.height),
        0.5 + random.nextDouble(),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _StaticNoisePainter old) => true;
}
