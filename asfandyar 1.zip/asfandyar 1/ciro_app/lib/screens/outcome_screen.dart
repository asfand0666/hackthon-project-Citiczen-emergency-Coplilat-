import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/ciro_state.dart';
import 'logs_screen.dart';

class OutcomeScreen extends StatelessWidget {
  const OutcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();
    final metrics = state.simulation?['metrics'] as Map? ?? {};

    final cBefore = metrics['congestion_before_pct'] ?? 87;
    final cAfter = metrics['congestion_after_pct'] ?? 87;
    final rBefore = metrics['response_time_before_min'] ?? 22;
    final rAfter = metrics['response_time_after_min'] ?? 22;
    final cDelta = metrics['congestion_delta_pct'] ?? 0;
    final rDelta = metrics['response_time_delta_min'] ?? 0;
    final vehicles = metrics['vehicles_rerouted'] ?? 0;
    final alerts = metrics['alerts_sent_count'] ?? 0;
    final tickets =
        state.simulation?['emergency_tickets'] as List? ?? [];

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        title: const Text('Outcome Metrics | نتائج',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: const Color(0xFF1F3864),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1F3864), Color(0xFF2C539E)],
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ── Before / After Header ─────────────────
            Row(children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.red.shade700,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.2), blurRadius: 8)],
                  ),
                  child: const Text('BEFORE',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.2)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.green.shade700,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.2), blurRadius: 8)],
                  ),
                  child: const Text('AFTER CIRO',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.2)),
                ),
              ),
            ]),
            const SizedBox(height: 24),

            // ── Congestion Row ────────────────────────
            _comparisonCard(
              'Traffic Congestion',
              Icons.traffic_rounded,
              '$cBefore%',
              '$cAfter%',
              '-$cDelta%',
              Colors.red,
              Colors.green,
            ),
            const SizedBox(height: 12),

            // ── Response Time Row ─────────────────────
            _comparisonCard(
              'Emergency Response',
              Icons.speed_rounded,
              '$rBefore min',
              '$rAfter min',
              '-$rDelta min faster',
              Colors.red,
              Colors.green,
            ),
            const SizedBox(height: 24),

            // ── Impact Numbers ────────────────────────
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Impact Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Color(0xFF1F3864))),
                Text('اثرات کا خلاصہ', style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _impactCard(vehicles.toString(), 'Vehicles\nDiverted', Icons.alt_route_rounded, Colors.blue)),
              const SizedBox(width: 8),
              Expanded(
                  child: _impactCard('${alerts > 1000 ? (alerts ~/ 1000) : alerts}${alerts > 1000 ? 'K' : ''}', 'Residents\nAlerted',
                      Icons.notifications_active_rounded, Colors.orange)),
              const SizedBox(width: 8),
              Expanded(child: _impactCard('${tickets.length}', 'Tickets\nActive', Icons.local_hospital_rounded, Colors.red)),
            ]),
            const SizedBox(height: 32),

            // ── View Logs Button ──────────────────────
            Container(
              height: 55,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [Color(0xFF5B2C6F), Color(0xFF8E44AD)]),
                boxShadow: [BoxShadow(color: const Color(0xFF5B2C6F).withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.receipt_long_rounded, color: Colors.white),
                label: const Text('View Trace Logs | لاگز دیکھیں', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: () async {
                  await context.read<CIROState>().fetchLogs();
                  if (context.mounted) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const LogsScreen()));
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _comparisonCard(String title, IconData icon, String before, String after, String delta, Color beforeColor, Color afterColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10)],
      ),
      child: Column(children: [
        Row(children: [
          Icon(icon, size: 18, color: Colors.grey[400]),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFF1F3864))),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(
            child: Column(children: [
              Text(before, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: beforeColor)),
              const Text('Before | پہلے', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
            ]),
          ),
          Column(children: [
            const Icon(Icons.arrow_forward_rounded, color: Colors.grey, size: 20),
            Text(delta, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w900, fontSize: 11)),
          ]),
          Expanded(
            child: Column(children: [
              Text(after, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: afterColor)),
              const Text('After CIRO | بعد میں', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
            ]),
          ),
        ]),
      ]),
    );
  }

  Widget _impactCard(String value, String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 5)],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 12),
          Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: color)),
          const SizedBox(height: 4),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
