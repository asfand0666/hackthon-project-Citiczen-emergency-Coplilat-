import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/ciro_state.dart';
import 'signal_input_screen.dart';
import 'crisis_screen.dart';
import 'plan_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  @override
  void initState() {
    super.initState();
    // Check backend connectivity on first load
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CIROState>().checkBackend();
    });
    
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A), // Tactical Dark Mode
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('CIRO Command Center',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            Row(children: [
              Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: state.backendStatus == 'ONLINE' ? Colors.greenAccent : Colors.redAccent,
                ),
              ),
              const SizedBox(width: 4),
              Text(state.backendStatus,
                  style: TextStyle(
                      fontSize: 10,
                      color: state.backendStatus == 'ONLINE' ? Colors.greenAccent : Colors.orange.shade200,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5)),
            ]),
          ],
        ),
        backgroundColor: state.survivalMode ? Colors.black : const Color(0xFF1F3864),
        flexibleSpace: state.survivalMode 
          ? null 
          : Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0F172A), Color(0xFF1E293B)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
        elevation: 0,
        actions: [
          Row(
            children: [
              Icon(state.survivalMode ? Icons.battery_saver : Icons.battery_full, 
                   color: state.survivalMode ? Colors.green : Colors.white70, size: 18),
              Switch(
                value: state.survivalMode,
                activeColor: Colors.green,
                onChanged: (v) => state.toggleSurvivalMode(),
              ),
            ],
          ),
        ],
      ),
      body: Container(
        color: state.survivalMode ? Colors.black : const Color(0xFF0F172A),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (state.survivalMode)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 20),
                  color: Colors.black,
                  child: const Text('SURVIVAL MODE ACTIVE: UI SIMPLIFIED FOR BATTERY SAVING',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 10)),
                ),
            // ── Multi-Agency Sync Room ────────────────
            Row(children: [
              _headerStat('POLICE', Icons.local_police, state.agencyStatus['POLICE'] == 'SYNCED' ? Colors.blue : Colors.grey),
              const SizedBox(width: 8),
              _headerStat('FIRE', Icons.local_fire_department, state.agencyStatus['FIRE'] == 'SYNCED' ? Colors.orange : Colors.grey),
              const SizedBox(width: 8),
              _headerStat('MEDICAL', Icons.medical_services, state.agencyStatus['MEDICAL'] == 'SYNCED' ? Colors.red : Colors.grey),
            ]),
            const SizedBox(height: 20),

            // ── Status Card (Neon Glassmorphic Glow) ───────────────────────────
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, child) {
                final isCrisis = state.crisis != null;
                return Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: isCrisis 
                            ? Colors.redAccent.withOpacity(0.2 + 0.2 * _pulseController.value)
                            : Colors.greenAccent.withOpacity(0.05),
                        blurRadius: isCrisis ? 20 : 10,
                        spreadRadius: isCrisis ? 2 * _pulseController.value : 0,
                      ),
                    ],
                    border: Border.all(
                      color: isCrisis 
                          ? Colors.redAccent.withOpacity(0.5) 
                          : Colors.white.withOpacity(0.05)
                    ),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    leading: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: (isCrisis ? Colors.redAccent : Colors.greenAccent).withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isCrisis ? Icons.warning_amber_rounded : Icons.radar,
                        color: isCrisis ? Colors.redAccent : Colors.greenAccent,
                        size: 32,
                      ),
                    ),
                    title: Text(
                      isCrisis ? 'ACTIVE CRISIS | ہنگامی صورتحال' : 'System: All Clear | سب ٹھیک ہے',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: isCrisis ? Colors.redAccent : Colors.greenAccent,
                      ),
                    ),
                    subtitle: Text(
                      isCrisis
                          ? 'Response protocol active | امدادی کارروائی جاری ہے'
                          : 'No threats detected | کوئی خطرہ نہیں ہے',
                      style: const TextStyle(fontSize: 12, color: Colors.white70),
                    ),
                  ),
                );
              }
            ),
            const SizedBox(height: 24),

            // ── Mini Metrics Grid ──────────────────────
            Row(children: [
              Expanded(child: _miniMetric('14.2s', 'Avg. Analysis', Icons.bolt, Colors.orange)),
              const SizedBox(width: 12),
              Expanded(child: _miniMetric('98%', 'AI Accuracy', Icons.verified_user, Colors.teal)),
            ]),
            const SizedBox(height: 24),

            // ── Signal Feed Card ─────────────────────
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10, offset: const Offset(0, 4)),
                ],
                border: Border.all(color: Colors.white.withOpacity(0.05)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Signal Feed',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
                          Text('سگنل فیڈ',
                              style: TextStyle(fontSize: 12, color: Colors.white54, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.blueAccent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
                        ),
                        child: Text('${state.signals.length} Signals',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (state.signals.isEmpty)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        child: Column(
                          children: [
                            Icon(Icons.sensors_off_rounded, size: 40, color: Colors.white24),
                            const SizedBox(height: 8),
                            const Text('Monitoring local emergency bands...', style: TextStyle(color: Colors.white54, fontSize: 13)),
                          ],
                        ),
                      ),
                    )
                  else
                    ...state.signals.map((sig) => Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.03),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white.withOpacity(0.05)),
                          ),
                          child: Row(children: [
                            const Icon(Icons.emergency_recording_rounded, size: 16, color: Colors.blueAccent),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text('${sig['location'] ?? 'Unknown'} — ${sig['signal_type'] ?? 'Report'}',
                                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: Colors.white70)),
                            ),
                          ]),
                        )),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // ── Buttons ───────────────────────────────
            Container(
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(
                  colors: [Color(0xFF3B82F6), Color(0xFF2563EB)],
                ),
                boxShadow: [
                  BoxShadow(color: Colors.blueAccent.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6)),
                ],
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add_circle_outline, color: Colors.white, size: 24),
                label: const Text('INGEST NEW SIGNAL | نیا سگنل',
                    style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SignalInputScreen()),
                ),
              ),
            ),
            const SizedBox(height: 16),
            // ── View Active Crisis Button (shown when crisis exists) ───
            if (state.crisis != null)
              Container(
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: LinearGradient(colors: [Colors.red.shade700, Colors.red.shade500]),
                  boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.warning_rounded, color: Colors.white),
                  label: const Text('VIEW ACTIVE CRISIS | بحران دیکھیں',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CrisisScreen())),
                ),
              ),
            if (state.plan != null) ...[  
              const SizedBox(height: 10),
              Container(
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: LinearGradient(colors: [Colors.orange.shade700, Colors.orange.shade500]),
                  boxShadow: [BoxShadow(color: Colors.orange.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.assignment_rounded, color: Colors.white),
                  label: const Text('VIEW RESPONSE PLAN | منصوبہ دیکھیں',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlanScreen())),
                ),
              ),
            ],
            const SizedBox(height: 16),
            if (state.signals.isNotEmpty || state.crisis != null)
              Center(
                child: TextButton.icon(
                  icon: const Icon(Icons.refresh, color: Colors.redAccent, size: 18),
                  label: const Text('SYSTEM RESET | ری سیٹ', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, fontSize: 12)),
                  onPressed: () => state.reset(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _headerStat(String label, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.1)),
        ),
        child: Column(children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: color, letterSpacing: 0.5)),
        ]),
      ),
    );
  }

  Widget _miniMetric(String value, String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10)],
      ),
      child: Stack(
        children: [
          // Background Sparkline Graphic
          Positioned.fill(
            child: Opacity(
              opacity: 0.1,
              child: CustomPaint(painter: _SparklinePainter(color)),
            ),
          ),
          Row(children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white)),
              Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54, fontWeight: FontWeight.bold)),
            ]),
          ]),
        ],
      ),
    );
  }
}

// ── Custom Sparkline Painter ──────────────────────────────────────────
class _SparklinePainter extends CustomPainter {
  final Color color;
  _SparklinePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;
    
    final path = Path();
    path.moveTo(0, size.height * 0.8);
    path.lineTo(size.width * 0.2, size.height * 0.6);
    path.lineTo(size.width * 0.4, size.height * 0.7);
    path.lineTo(size.width * 0.6, size.height * 0.3);
    path.lineTo(size.width * 0.8, size.height * 0.5);
    path.lineTo(size.width, size.height * 0.2);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
