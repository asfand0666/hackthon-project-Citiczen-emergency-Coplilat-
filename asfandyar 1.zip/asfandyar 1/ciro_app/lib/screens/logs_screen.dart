import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/ciro_state.dart';

class LogsScreen extends StatelessWidget {
  const LogsScreen({super.key});

  // Icon for each agent
  IconData _agentIcon(String agentName) {
    if (agentName.contains('Ingestion')) return Icons.input;
    if (agentName.contains('Detection')) return Icons.search;
    if (agentName.contains('Planning')) return Icons.assignment;
    if (agentName.contains('Simulation')) return Icons.play_arrow;
    return Icons.smart_toy;
  }

  // Colour for each agent
  Color _agentColor(String agentName) {
    if (agentName.contains('Ingestion')) return Colors.blue[700]!;
    if (agentName.contains('Detection')) return Colors.orange[700]!;
    if (agentName.contains('Planning')) return Colors.purple[700]!;
    if (agentName.contains('Simulation')) return Colors.green[700]!;
    return Colors.grey[700]!;
  }

  @override
  Widget build(BuildContext context) {
    final logs = context.watch<CIROState>().logs;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        title: const Text('Agent Reasoning Traces | فیصلوں کا ریکارڈ',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
        backgroundColor: const Color(0xFF5B2C6F),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF5B2C6F), Color(0xFF8E44AD)],
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: logs.isEmpty
          ? Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.terminal_rounded, size: 64, color: Colors.grey.shade300),
                const SizedBox(height: 16),
                const Text('No trace logs available.', style: TextStyle(color: Colors.grey, fontSize: 16, fontWeight: FontWeight.bold)),
                const Text('Orchestration events will appear here.', style: TextStyle(color: Colors.grey, fontSize: 13)),
              ]),
            )
          : Column(children: [
              // ── Summary Bar ───────────────────────────
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4)],
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('${logs.length} TRACE ENTRIES',
                      style: const TextStyle(color: Color(0xFF5B2C6F), fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.1)),
                  const Text('CIRO Autonomous Engine', style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold)),
                ]),
              ),

              // ── Log Entries ───────────────────────────
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: logs.length,
                  itemBuilder: (context, i) {
                    final log = logs[i] as Map;
                    final agent = log['agent']?.toString() ?? 'Unknown';
                    final color = _agentColor(agent);

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Agent Header
                            Row(children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
                                child: Icon(_agentIcon(agent), size: 16, color: color),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(agent, style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: 14, letterSpacing: 0.5)),
                              ),
                              Text('#${i + 1}', style: TextStyle(color: Colors.grey.shade400, fontWeight: FontWeight.bold, fontSize: 11)),
                            ]),
                            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(height: 1)),

                            // Action & Input
                            _logRow('Action', log['action']?.toString() ?? ''),
                            _logRow('Input', log['input_summary']?.toString() ?? ''),
                            if (log['reasoning'] != null && log['reasoning'].toString().isNotEmpty)
                              _logRow('💡 Reasoning', log['reasoning'].toString()),
                            if (log['output_summary'] != null && log['output_summary'].toString().isNotEmpty)
                              _logRow('📤 Output', log['output_summary'].toString()),

                            const SizedBox(height: 12),
                            // Footer
                            Row(children: [
                              Icon(Icons.timer_rounded, size: 12, color: Colors.grey.shade400),
                              const SizedBox(width: 4),
                              Text('${log['duration_ms'] ?? 0}ms', style: TextStyle(fontSize: 10, color: Colors.grey.shade400, fontWeight: FontWeight.bold)),
                              const Spacer(),
                              Icon(Icons.code_rounded, size: 12, color: Colors.grey.shade400),
                              const SizedBox(width: 4),
                              Text(
                                (log['antigravity_trace_id'] ?? 'N/A').toString().take(12),
                                style: TextStyle(fontSize: 10, color: Colors.grey.shade400, fontFamily: 'monospace'),
                              ),
                            ]),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ]),
    );
  }

  Widget _logRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text('$label:',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: Colors.grey)),
          ),
          Expanded(child: Text(value, style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
  }
}

extension _Take on String {
  String take(int n) => length <= n ? this : substring(0, n);
}
