import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/ciro_state.dart';
import 'plan_screen.dart';
import 'donation_screen.dart';

class CrisisScreen extends StatelessWidget {
  const CrisisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();
    final crisis = state.crisis;

    if (crisis == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Crisis')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final severity = crisis['severity']?.toString().toUpperCase() ?? 'UNKNOWN';
    final confidence = (crisis['confidence'] as num?)?.toDouble() ?? 0.0;
    final crisisType = crisis['crisis_type']?.toString().replaceAll('_', ' ').toUpperCase() ?? 'UNKNOWN';

    Color severityColor() {
      switch (severity) {
        case 'CRITICAL': return Colors.red.shade900;
        case 'HIGH': return Colors.orange.shade800;
        case 'MEDIUM': return Colors.amber.shade700;
        default: return Colors.green.shade700;
      }
    }

    return Scaffold(
      backgroundColor: const Color(0xFFFDFDFD),
      appBar: AppBar(
        title: const Text('Crisis Detected | بحران کا پتہ چلا',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Colors.red.shade800,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.red.shade800, Colors.red.shade600],
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ── Crisis Type Banner ────────────────────
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.red.shade50, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.red.shade100),
                boxShadow: [
                  BoxShadow(color: Colors.red.withOpacity(0.05), blurRadius: 15, offset: const Offset(0, 5)),
                ],
              ),
              child: Column(children: [
                const Icon(Icons.warning_rounded, color: Colors.red, size: 48),
                const SizedBox(height: 12),
                Text(crisisType,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: Colors.red.shade900, letterSpacing: 1.1)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.location_on, color: Colors.red, size: 18),
                  const SizedBox(width: 4),
                  Text(crisis['location']?.toString() ?? 'Unknown',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.grey.shade700)),
                ]),
              ]),
            ),
            const SizedBox(height: 20),

            // ── Confidence Bar ────────────────────────
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Detection Confidence', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text('تشخیص کا یقین', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const Spacer(),
                    Text('${(confidence * 100).toStringAsFixed(0)}%',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: confidence > 0.85 ? Colors.green : Colors.orange)),
                  ]),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: confidence,
                      minHeight: 10,
                      backgroundColor: Colors.grey.shade100,
                      valueColor: AlwaysStoppedAnimation<Color>(confidence > 0.85 ? Colors.green : Colors.orange),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // ── Severity Badge ────────────────────────
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                decoration: BoxDecoration(
                  color: severityColor(),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: severityColor().withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Text('SEVERITY: $severity | شدت',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1.0)),
              ),
            ),
            const SizedBox(height: 24),

            // ── Supporting Evidence ───────────────────
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Supporting Signals', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text('معاون سگنلز', style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            ... (crisis['supporting_evidence'] as List? ?? []).map((ev) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade50),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.verified_user_rounded, size: 20, color: Colors.green),
                  const SizedBox(width: 12),
                  Expanded(child: Text(ev.toString(), style: const TextStyle(fontSize: 13, height: 1.4))),
                ],
              ),
            )),
            const SizedBox(height: 24),

            // ── AI Reasoning ──────────────────────────
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(15),
              ),
              child: ExpansionTile(
                title: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('System Reasoning', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text('نظام کی منطق', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  ],
                ),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(crisis['reasoning']?.toString() ?? 'No detail.',
                        style: TextStyle(fontSize: 14, height: 1.6, color: Colors.grey.shade800)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // ── Verified Relief Fund Card ────────────
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      const Icon(Icons.volunteer_activism, color: Colors.pink, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('VERIFIED RELIEF FUND',
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Color(0xFFC0392B), letterSpacing: 0.5)),
                            const Text('تصدیق شدہ امدادی فنڈ',
                                style: TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Support victims at this location:', style: TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w600)),
                  const Text('اس مقام پر متاثرین کی مدد کریں:', style: TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FontWeight.bold), textDirection: TextDirection.rtl),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: state.reliefRaised / state.reliefTarget,
                      backgroundColor: Colors.pink.withOpacity(0.1),
                      color: Colors.pink,
                      minHeight: 12,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Raised: ${state.reliefRaised.toInt()} PKR', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: Colors.pink)),
                      Text('Goal: ${state.reliefTarget.toInt()} PKR', style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.payment, color: Colors.white),
                      label: const Text('DONATE NOW | عطیہ دیں', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.pink,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const DonationScreen()),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // ── Generate Plan Button ──────────────────
            Container(
              height: 55,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [Color(0xFFC55A11), Color(0xFFE87E33)]),
                boxShadow: [BoxShadow(color: const Color(0xFFC55A11).withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
              ),
              child: ElevatedButton.icon(
                icon: state.loading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.auto_fix_high, color: Colors.white),
                label: Text(
                  state.loading ? 'Generating Plan...' : 'Generate Response Plan | جوابی منصوبہ',
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: state.loading
                    ? null
                    : () {
                        if (state.plan != null) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const PlanScreen()));
                        }
                      },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
