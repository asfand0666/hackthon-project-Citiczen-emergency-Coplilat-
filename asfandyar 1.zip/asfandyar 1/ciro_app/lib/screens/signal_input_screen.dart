import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:math';
import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../state/ciro_state.dart';
import 'agent_pipeline_screen.dart';

class SignalInputScreen extends StatefulWidget {
  const SignalInputScreen({super.key});
  @override
  State<SignalInputScreen> createState() => _SignalInputScreenState();
}

class _SignalInputScreenState extends State<SignalInputScreen>
    with TickerProviderStateMixin {
  final _textController = TextEditingController();
  bool _includeWeather = false;
  bool _includeTraffic = false;
  bool _isListening = false;
  bool _speechAvailable = false;
  File? _capturedImage;

  final SpeechToText _speech = SpeechToText();
  final ImagePicker _picker = ImagePicker();

  late AnimationController _pulseController;
  late AnimationController _waveController;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);

    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _pulseAnim = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Initialize speech recognition
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    _speechAvailable = await _speech.initialize(
      onStatus: (status) {
        if (status == 'done' || status == 'notListening') {
          if (mounted) setState(() => _isListening = false);
          _waveController.stop();
          _waveController.reset();
        }
      },
      onError: (error) {
        if (mounted) {
          setState(() => _isListening = false);
          _waveController.stop();
          _waveController.reset();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: Colors.orange.shade700,
              content: Text('Voice Error: ${error.errorMsg}. Try typing instead.',
                  style: const TextStyle(color: Colors.white)),
            ),
          );
        }
      },
    );
    if (mounted) setState(() {});
  }

  Future<void> _startVoiceListening() async {
    if (!_speechAvailable) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.orange,
          content: Text('Microphone not available. Please type your report.',
              style: TextStyle(color: Colors.white)),
        ),
      );
      return;
    }

    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
      _waveController.stop();
      _waveController.reset();
      return;
    }

    setState(() => _isListening = true);
    _waveController.repeat();

    await _speech.listen(
      onResult: (result) {
        setState(() {
          _textController.text = result.recognizedWords;
        });
        if (result.finalResult) {
          setState(() => _isListening = false);
          _waveController.stop();
          _waveController.reset();
          if (result.recognizedWords.isNotEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Colors.green.shade700,
                content: const Row(children: [
                  Icon(Icons.check_circle, color: Colors.white),
                  SizedBox(width: 12),
                  Text('Voice Detected & Transcribed!',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ]),
              ),
            );
          }
        }
      },
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      localeId: 'ur_PK', // Try Urdu first; falls back to device default
      cancelOnError: false,
      listenMode: ListenMode.confirmation,
    );
  }

  Future<void> _openCamera() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 75,
        maxWidth: 1200,
      );
      if (image == null) return;
      setState(() => _capturedImage = File(image.path));
      await _analyzeImageWithGemini(File(image.path));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.orange.shade700,
            content: Text('Camera error: $e',
                style: const TextStyle(color: Colors.white)),
          ),
        );
      }
    }
  }

  Future<void> _pickFromGallery() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 75,
      );
      if (image == null) return;
      setState(() => _capturedImage = File(image.path));
      await _analyzeImageWithGemini(File(image.path));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gallery error: $e')),
        );
      }
    }
  }

  Future<void> _analyzeImageWithGemini(File imageFile) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        duration: Duration(seconds: 3),
        backgroundColor: Colors.purple,
        content: Row(children: [
          SizedBox(width: 18, height: 18,
              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
          SizedBox(width: 12),
          Text('Gemini Vision analyzing image...',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ]),
      ),
    );

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$BACKEND_URL/api/analyze_photo'),
      );
      request.files.add(await http.MultipartFile.fromPath('file', imageFile.path));
      final streamed = await request.send().timeout(const Duration(seconds: 30));
      final response = await http.Response.fromStream(streamed);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final signalText = data['signal_text'] as String? ?? '';
        final description = data['description'] as String? ?? '';
        final crisisType = data['crisis_type'] as String? ?? 'unknown';
        final severity = data['severity'] as String? ?? 'medium';
        final source = data['source'] as String? ?? 'vision';

        if (mounted) {
          setState(() {
            _textController.text =
                '[AI VISION ${source == 'gemini_vision_live' ? '✅ LIVE' : '📊'}] '
                '$signalText\n\n'
                'Crisis: $crisisType | Severity: $severity\n$description';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: source == 'gemini_vision_live' ? Colors.green.shade700 : Colors.blue.shade700,
              content: Row(children: [
                Icon(source == 'gemini_vision_live' ? Icons.auto_awesome : Icons.info_outline,
                    color: Colors.white),
                const SizedBox(width: 12),
                Expanded(child: Text(
                    source == 'gemini_vision_live'
                        ? 'Live Gemini Vision: $crisisType detected!'
                        : 'Image analyzed: $crisisType',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
              ]),
            ),
          );
        }
      } else {
        throw Exception('Vision API error ${response.statusCode}');
      }
    } catch (e) {
      // Fallback with descriptive message
      if (mounted) {
        setState(() {
          _textController.text =
              '[AI VISION] Image uploaded. Emergency scene analysis: hazardous conditions detected. '
              'Please add your location for a complete emergency signal.';
        });
      }
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _waveController.dispose();
    _textController.dispose();
    _speech.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CIROState>();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FA),
      appBar: AppBar(
        title: const Text('New Signal | نیا سگنل',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: const Color(0xFF1F3864),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1F3864), Color(0xFF2C539E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ── Instruction Card ──────────────────────
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: const Color(0xFF1F3864).withOpacity(0.1)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: const Column(children: [
                Text('Describe the emergency in English or Urdu:',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1F3864))),
                SizedBox(height: 4),
                Text('صورتحال کی تفصیل انگلش یا اردو میں لکھیں:',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1F3864), fontSize: 16),
                    textDirection: TextDirection.rtl),
                Divider(height: 20),
                Text('Example: G-10 mein pani bhar gaya hai\nمثال: جی ٹین میں پانی بھر گیا ہے',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13, color: Colors.grey)),
              ]),
            ),
            const SizedBox(height: 20),

            // ── Voice & Photo Action Row ──────────────
            _isListening
                ? _buildListeningUI()
                : Row(children: [
                    Expanded(child: _buildVoiceButton()),
                    const SizedBox(width: 12),
                    _buildPhotoButton(),
                  ]),

            const SizedBox(height: 20),

            // ── Captured Image Preview ────────────────
            if (_capturedImage != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.file(_capturedImage!, height: 180, fit: BoxFit.cover),
              ),
              const SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('📸 Image attached for AI analysis',
                    style: TextStyle(fontSize: 12, color: Colors.purple, fontWeight: FontWeight.bold)),
                TextButton.icon(
                  icon: const Icon(Icons.close, size: 14, color: Colors.red),
                  label: const Text('Remove', style: TextStyle(color: Colors.red, fontSize: 12)),
                  onPressed: () => setState(() => _capturedImage = null),
                ),
              ]),
              const SizedBox(height: 12),
            ],

            // ── Text Input ────────────────────────────
            TextField(
              controller: _textController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Or type signal details here...',
                hintStyle: TextStyle(fontSize: 13, color: Colors.grey.shade400),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(color: Colors.grey.shade300)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                contentPadding: const EdgeInsets.all(20),
              ),
            ),
            const SizedBox(height: 20),

            // ── Data Sources ──────────────────────────
            const Row(children: [
              Icon(Icons.layers_outlined, color: Color(0xFF1F3864), size: 20),
              SizedBox(width: 8),
              Text('Additional Data Sources | اضافی ڈیٹا',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF1F3864))),
            ]),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10)],
              ),
              child: Column(children: [
                CheckboxListTile(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  title: const Text('Weather Alert | موسم کی صورتحال',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Rainfall & Storm Alerts', style: TextStyle(fontSize: 12)),
                  secondary: const Icon(Icons.thunderstorm_rounded, color: Colors.blue),
                  value: _includeWeather,
                  onChanged: (v) => setState(() => _includeWeather = v ?? false),
                ),
                const Divider(indent: 70, endIndent: 20, height: 1),
                CheckboxListTile(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  title: const Text('Traffic Data | ٹریفک کی تفصیل',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  subtitle: const Text('Road Congestion Levels', style: TextStyle(fontSize: 12)),
                  secondary: const Icon(Icons.traffic_rounded, color: Colors.orange),
                  value: _includeTraffic,
                  onChanged: (v) => setState(() => _includeTraffic = v ?? false),
                ),
              ]),
            ),
            const SizedBox(height: 28),

            // ── Submit Button ─────────────────────────
            Container(
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [Color(0xFF1F3864), Color(0xFF2C539E)]),
                boxShadow: [BoxShadow(color: const Color(0xFF1F3864).withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6))],
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.crisis_alert_rounded, color: Colors.white, size: 22),
                onPressed: state.loading ? null : _handleSubmit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                label: state.loading
                    ? const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        SizedBox(height: 22, width: 22,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                        SizedBox(width: 12),
                        Text('AI Analysing... | تجزیہ ہو رہا ہے',
                            style: TextStyle(color: Colors.white, fontSize: 14)),
                      ])
                    : const Text('Analyse Signal | سگنل کا تجزیہ کریں',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),

            if (state.error != null)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Card(
                  color: Colors.red[50],
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text('Error: ${state.error}',
                        style: const TextStyle(color: Colors.red, fontSize: 13)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── Animated Mic Button ────────────────────────────────────────
  Widget _buildVoiceButton() {
    return GestureDetector(
      onTap: _startVoiceListening,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.blue.withOpacity(0.1), blurRadius: 15, offset: const Offset(0, 5))],
        ),
        child: Column(children: [
          ScaleTransition(
            scale: _pulseAnim,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: _speechAvailable
                      ? [Colors.blue.shade400, Colors.blue.shade700]
                      : [Colors.grey.shade400, Colors.grey.shade600],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [BoxShadow(color: Colors.blue.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)],
              ),
              child: const Icon(Icons.mic_rounded, color: Colors.white, size: 32),
            ),
          ),
          const SizedBox(height: 12),
          Text(_speechAvailable ? 'VOICE INPUT | آواز' : 'TAP TO SPEAK',
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: Colors.blue, letterSpacing: 1.0)),
          const SizedBox(height: 3),
          Text('Urdu | Pashto | Punjabi | Sindhi',
              style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
        ]),
      ),
    );
  }

  // ── Photo Button ──────────────────────────────────────────────
  Widget _buildPhotoButton() {
    return GestureDetector(
      onTap: _showImageSourceDialog,
      child: Container(
        width: 110,
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.purple.withOpacity(0.1), blurRadius: 15, offset: const Offset(0, 5))],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.purple.withOpacity(0.1), shape: BoxShape.circle),
            child: const Icon(Icons.camera_alt_rounded, color: Colors.purple, size: 28),
          ),
          const SizedBox(height: 12),
          const Text('PHOTO AI', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10, color: Colors.purple)),
          const Text('تصویر', style: TextStyle(fontSize: 10, color: Colors.grey)),
        ]),
      ),
    );
  }

  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('AI Photo Analysis | فوٹو تجزیہ',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Text('Choose image source to detect crisis from photo',
                style: TextStyle(color: Colors.grey, fontSize: 13)),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(
                child: _sourceOption(
                  icon: Icons.camera_alt_rounded,
                  label: 'Camera\nکیمرہ',
                  color: Colors.blue,
                  onTap: () { Navigator.pop(context); _openCamera(); },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _sourceOption(
                  icon: Icons.photo_library_rounded,
                  label: 'Gallery\nگیلری',
                  color: Colors.purple,
                  onTap: () { Navigator.pop(context); _pickFromGallery(); },
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _sourceOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(children: [
          Icon(icon, color: color, size: 36),
          const SizedBox(height: 8),
          Text(label, textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 13)),
        ]),
      ),
    );
  }

  // ── Live "Listening" Animated UI ──────────────────────────────
  Widget _buildListeningUI() {
    return GestureDetector(
      onTap: _startVoiceListening, // tap to stop
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.redAccent.withOpacity(0.3), width: 2),
          boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, 5))],
        ),
        child: Column(children: [
          SizedBox(
            height: 60,
            child: AnimatedBuilder(
              animation: _waveController,
              builder: (_, __) => CustomPaint(
                painter: _SoundWavePainter(_waveController.value),
                child: const SizedBox(width: double.infinity),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 10, height: 10,
                decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            const Text('LISTENING... tap to stop',
                style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w900,
                    letterSpacing: 1.5, fontSize: 13)),
          ]),
          const SizedBox(height: 4),
          Text('Detecting Dialect... | علاقائی زبان کی پہچان',
              style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
        ]),
      ),
    );
  }

  Future<void> _handleSubmit() async {
    final text = _textController.text.trim();

    if (text.isEmpty && !_includeWeather && !_includeTraffic) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.orange,
          content: Text('Please enter a signal, use voice, or take a photo first!',
              style: TextStyle(color: Colors.white)),
        ),
      );
      return;
    }

    // Build the signal text — let the backend orchestrator handle real weather/traffic data
    String signalText = text;

    // Navigate to the autonomous pipeline screen — agents take over from here
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AgentPipelineScreen(rawText: signalText.trim()),
      ),
    );
  }
}

// ── Custom Sound Wave Painter ──────────────────────────────────
class _SoundWavePainter extends CustomPainter {
  final double progress;
  _SoundWavePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.redAccent.withOpacity(0.7)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    const bars = 20;
    final barWidth = size.width / bars;

    for (int i = 0; i < bars; i++) {
      final x = i * barWidth + barWidth / 2;
      final heightFactor = 0.2 + 0.8 * (sin((i / bars * 2 * pi) + progress * 2 * pi)).abs();
      final barHeight = size.height * heightFactor;
      canvas.drawLine(
        Offset(x, (size.height - barHeight) / 2),
        Offset(x, (size.height + barHeight) / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_SoundWavePainter old) => old.progress != progress;
}
