class CrisisDomainException(Exception):
    """Base exception for all crisis platform domain errors."""
    def __init__(self, message: str, status_code: int = 400, error_code: str = "GENERIC_ERROR"):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_code = error_code

class IngestionError(CrisisDomainException):
    """Error during raw text parsing or entities extraction."""
    def __init__(self, message: str):
        super().__init__(message, status_code=422, error_code="INGESTION_FAILED")

class CrisisDetectionError(CrisisDomainException):
    """Error during cross-signal analysis or crisis classification."""
    def __init__(self, message: str):
        super().__init__(message, status_code=500, error_code="DETECTION_FAILED")

class PlanningError(CrisisDomainException):
    """Error during response plan generation or resource checks."""
    def __init__(self, message: str):
        super().__init__(message, status_code=500, error_code="PLANNING_FAILED")

class SimulationError(CrisisDomainException):
    """Error during metrics modeling or physics simulation."""
    def __init__(self, message: str):
        super().__init__(message, status_code=500, error_code="SIMULATION_FAILED")

class RateLimitExceeded(CrisisDomainException):
    """Rate limiter triggered for the client."""
    def __init__(self, message: str = "Rate limit exceeded. Maximum 10 requests per minute."):
        super().__init__(message, status_code=429, error_code="RATE_LIMIT_EXCEEDED")
