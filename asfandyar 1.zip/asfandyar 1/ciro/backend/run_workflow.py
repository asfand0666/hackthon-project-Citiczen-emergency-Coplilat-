"""
run_workflow.py
---------------
Batch script to run predefined crisis scenarios through the CIRO Antigravity Layer.
This will trigger the full agent pipeline (Ingestion -> Detection -> Planning -> Simulation)
and write all execution traces to logs/trace.jsonl.
"""

import os
import json
from antigravity_layer.workflow import run_workflow

# ---------------------------------------------------------------------------
# Predefined Scenarios
# ---------------------------------------------------------------------------

SCENARIOS = [
    {
        "name": "Scenario 1: Urban Flooding in G-10",
        "input": "G-10 mein pani bhar gaya hai, gaariyan phans gayi hain",
        "filename": "flood_result.json"
    },
    {
        "name": "Scenario 2: Traffic Collision at Faizabad",
        "input": "Massive collision at Faizabad interchange, all lanes blocked, speed 0 km/h.",
        "filename": "accident_result.json"
    },
    {
        "name": "Scenario 3: Severe Heatwave Warning",
        "input": "Temperatures expected to cross 45C today. Hospitals reporting heat strokes.",
        "filename": "heatwave_result.json"
    },
    {
        "name": "Scenario 4: Benign/No Crisis",
        "input": "Clear skies today in Islamabad, traffic moving smoothly.",
        "filename": "benign_result.json"
    }
]

def main():
    print("==================================================")
    print(" CIRO: Antigravity Layer - Scenario Runner")
    print("==================================================")
    
    # Create the scenarios output directory if it doesn't exist
    scenarios_dir = os.path.join(os.path.dirname(__file__), "scenarios")
    os.makedirs(scenarios_dir, exist_ok=True)
    
    print(f"Running {len(SCENARIOS)} predefined scenarios...\n")
    
    for i, scenario in enumerate(SCENARIOS, 1):
        print(f"--- [Scenario {i}/4] {scenario['name']} ---")
        print(f"Input: {scenario['input']}")
        print("Executing workflow...")
        
        try:
            results = run_workflow(scenario["input"])
            
            # Save results to the specified file
            output_path = os.path.join(scenarios_dir, scenario["filename"])
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"Saved to: scenarios/{scenario['filename']}")
            
            if results.get("status") == "no_crisis":
                print("Result: No actionable crisis detected.")
            else:
                plan = results.get("plan", {})
                actions = len(plan.get("actions", []))
                sim_metrics = results.get("simulation", {}).get("metrics", {})
                
                print(f"Result: Crisis Type = {results.get('crisis', {}).get('crisis_type')}")
                print(f"        Actions planned = {actions}")
                print(f"        Simulation congestion delta = {sim_metrics.get('congestion_delta_pct', 0)}%")
                print(f"        Log ID embedded: {plan.get('response_id')}")
                
        except Exception as e:
            print(f"Error executing scenario: {str(e)}")
            
        print("-" * 50 + "\n")
        
    print("All scenarios completed. Check logs/trace.jsonl for detailed execution traces.")

if __name__ == "__main__":
    main()
