@echo off
echo ============================================
echo   CIRO Backend Startup
echo ============================================
echo.

cd /d "%~dp0"

:: Check if venv exists
if not exist "venv\Scripts\activate.bat" (
    echo [ERROR] Virtual environment not found.
    echo Please run: python -m venv venv
    echo Then run: venv\Scripts\pip install -r requirements.txt
    pause
    exit /b 1
)

:: Activate venv
call venv\Scripts\activate.bat

:: Show your local IP so you can configure the Flutter app
echo Your local IP addresses (use one in Flutter ciro_state.dart):
ipconfig | findstr /i "IPv4"
echo.
echo ============================================
echo   Starting FastAPI on http://0.0.0.0:8000
echo   API Docs: http://localhost:8000/docs
echo   Flutter config: BACKEND_URL = http://YOUR_IP:8000
echo ============================================
echo.

uvicorn main:app --host 0.0.0.0 --port 8000 --reload

pause
