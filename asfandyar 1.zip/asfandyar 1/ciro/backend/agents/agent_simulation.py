"""
agent_simulation.py
-------------------
Simulation engine for CIRO emergency response plans.

This is a pure Python module (no Gemini API calls) that evaluates a structured
response plan (produced by agent_planning) and predicts its outcomes via
deterministic simulation logic.

It processes actions by priority and models their effects on key urban metrics:
- Congestion
- Response times
- Evacuation/rerouting counts
- Alert dissemination
"""

import uuid
from datetime import datetime
from dataclasses import dataclass, field, asdict

# ---------------------------------------------------------------------------
# State definitions
# ---------------------------------------------------------------------------

@dataclass
class SimulationMetrics:
    congestion_before_pct: int = 87
    congestion_after_pct: int = 87
    response_time_before_min: int = 22
    response_time_after_min: int = 22
    vehicles_rerouted: int = 0
    alerts_sent_count: int = 0
    tickets_created: int = 0

    # Derived
    congestion_delta_pct: int = 0
    response_time_delta_min: int = 0

@dataclass
class SimulationState:
    metrics: SimulationMetrics = field(default_factory=SimulationMetrics)
    traffic_routes: dict = field(default_factory=dict)
    emergency_tickets: list = field(default_factory=list)
    alerts_sent: list = field(default_factory=list)
    map_overlays: list = field(default_factory=list)
    execution_log: list = field(default_factory=list)

# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------

def simulate_plan(plan: dict) -> dict:
    """
    Simulate the execution of an emergency response plan.

    Parameters
    ----------
    plan : dict
        A response plan dict as produced by agent_planning.plan_response().
        Must contain an 'actions' list.

    Returns
    -------
    dict
        The final SimulationState as a dictionary.
    """
    state = SimulationState()
    actions = plan.get("actions", [])

    # Sort actions by priority (1 is highest priority, so sort ascending)
    # If priority is missing, default to 5 (lowest).
    sorted_actions = sorted(actions, key=lambda a: a.get("priority", 5))

    for action in sorted_actions:
        a_type = action.get("type")
        a_id = action.get("action_id", "A-?")
        target = action.get("target_location", "unknown")
        
        # Log the start of action processing
        state.execution_log.append(f"[{datetime.utcnow().isoformat()}] Starting {a_id} ({a_type}) priority {action.get('priority', 5)}")

        if a_type == "traffic_reroute":
            # Add route to traffic_routes
            route_id = f"RTE-{uuid.uuid4().hex[:6].upper()}"
            state.traffic_routes[route_id] = {
                "target": target,
                "status": "ACTIVE"
            }
            
            # Append reroute_polyline overlay
            state.map_overlays.append({
                "type": "reroute_polyline",
                "color": "#28A745",
                "target": target
            })
            
            # Update metrics
            state.metrics.vehicles_rerouted += 220
            
            # Reduce congestion (minimum 20)
            new_cong = max(20, state.metrics.congestion_after_pct - 53)
            state.metrics.congestion_after_pct = new_cong
            
            state.execution_log.append(f"  -> Rerouted 220 vehicles at {target}. Congestion dropped to {new_cong}%.")

        elif a_type == "emergency_dispatch":
            # Create a ticket
            ticket_id = f"T-{uuid.uuid4().hex[:6].upper()}"
            eta = action.get("estimated_time_minutes", 15)
            
            ticket = {
                "ticket_id": ticket_id,
                "resources": action.get("resources_needed", []),
                "target": target,
                "status": "DISPATCHED",
                "eta_minutes": eta
            }
            state.emergency_tickets.append(ticket)
            
            # Update metrics
            state.metrics.tickets_created += 1
            state.metrics.response_time_after_min = eta
            
            state.execution_log.append(f"  -> Dispatched resources {ticket['resources']} to {target}. ETA: {eta} min.")

        elif a_type == "public_alert":
            # Create alert
            alert_id = f"A-{uuid.uuid4().hex[:6].upper()}"
            recipients = 14892
            
            alert = {
                "alert_id": alert_id,
                "channel": "SMS+push",
                "recipients": recipients
            }
            state.alerts_sent.append(alert)
            
            # Update metrics
            state.metrics.alerts_sent_count += recipients
            
            state.execution_log.append(f"  -> Sent {recipients} alerts via {alert['channel']}.")
            
        elif a_type == "resource_allocation":
            # Just log it for now, no specific metrics updates defined in requirements
            state.execution_log.append(f"  -> Allocated resources {action.get('resources_needed', [])} at {target}.")
            
        else:
            state.execution_log.append(f"  -> Unknown action type: {a_type}")

    # Compute deltas
    state.metrics.congestion_delta_pct = state.metrics.congestion_before_pct - state.metrics.congestion_after_pct
    state.metrics.response_time_delta_min = state.metrics.response_time_before_min - state.metrics.response_time_after_min

    state.execution_log.append(f"[{datetime.utcnow().isoformat()}] Simulation complete.")

    return asdict(state)

# ---------------------------------------------------------------------------
# Quick smoke-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    
    test_plan = {
        "response_id": "R-1234abcd",
        "priority_level": 4,
        "actions": [
            {
                "action_id": "A-1",
                "type": "public_alert",
                "target_location": "G-10",
                "priority": 3
            },
            {
                "action_id": "A-2",
                "type": "emergency_dispatch",
                "target_location": "G-10",
                "resources_needed": ["rescue_boats", "ambulances"],
                "estimated_time_minutes": 15,
                "priority": 1
            },
            {
                "action_id": "A-3",
                "type": "traffic_reroute",
                "target_location": "G-10",
                "priority": 2
            }
        ]
    }

    print("Input Plan:")
    print(json.dumps(test_plan, indent=2))
    print("\nSimulating...\n")

    result = simulate_plan(test_plan)
    
    print("Output State:")
    print(json.dumps(result, indent=2))

    # ---- Assertions ----
    metrics = result["metrics"]
    
    # Priority sorting check (A-2 then A-3 then A-1)
    logs = "\n".join(result["execution_log"])
    assert logs.find("Starting A-2") < logs.find("Starting A-3") < logs.find("Starting A-1"), \
        "Actions were not processed in priority order (1 -> 2 -> 3)"

    # Traffic reroute checks
    assert metrics["congestion_before_pct"] == 87
    assert metrics["congestion_after_pct"] == 34  # 87 - 53
    assert metrics["congestion_delta_pct"] == 53
    assert metrics["vehicles_rerouted"] == 220
    assert len(result["traffic_routes"]) == 1
    assert any(o["type"] == "reroute_polyline" and o["color"] == "#28A745" for o in result["map_overlays"])

    # Emergency dispatch checks
    assert metrics["tickets_created"] == 1
    assert len(result["emergency_tickets"]) == 1
    assert result["emergency_tickets"][0]["status"] == "DISPATCHED"
    assert metrics["response_time_after_min"] == 15
    assert metrics["response_time_delta_min"] == 7  # 22 - 15

    # Public alert checks
    assert metrics["alerts_sent_count"] == 14892
    assert len(result["alerts_sent"]) == 1
    assert result["alerts_sent"][0]["channel"] == "SMS+push"

    print("\n[OK] All assertions passed. Pure Python simulation logic verified.")
