"""
agent_ingestion.py
------------------
Ingestion agent for CIRO crisis-signal processing.

Uses google-genai (Gemini 2.0 Flash) to parse raw text reports and extract
structured crisis metadata: signal_type, location, coordinates,
crisis_keywords, severity_hint, language, raw_text, timestamp.

DEMO_MODE (set via .env DEMO_MODE=true) skips the API call and uses a
local rule-based extractor — useful when the free-tier quota is exhausted.
"""

import json
import os
import re
import time
from datetime import datetime

from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai import errors as genai_errors

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

load_dotenv()

_API_KEY = os.getenv("GEMINI_API_KEY", "")
DEMO_MODE: bool = os.getenv("DEMO_MODE", "false").lower() == "true"

# gemini-1.5-flash is deprecated; 2.0-flash is the current equivalent.
MODEL_NAME = "gemini-2.5-flash"

# Retry settings
MAX_RETRIES = 2
RETRY_BASE_DELAY = 5

# ---------------------------------------------------------------------------
# Pakistan-wide location coordinates — 80+ cities, towns, and neighbourhoods
# ---------------------------------------------------------------------------

LOCATION_COORDINATES: dict[str, tuple[float, float]] = {
    # ── Islamabad / Rawalpindi ──────────────────────────────────────────────
    "G-10": (33.6844, 73.0479), "G-11": (33.6919, 73.0291),
    "G-9":  (33.6988, 73.0680), "G-8":  (33.7063, 73.0555),
    "G-7":  (33.7200, 73.0638), "G-6":  (33.7290, 73.0737),
    "G-5":  (33.7370, 73.0820),
    "F-10": (33.7100, 73.0238), "F-11": (33.7199, 73.0112),
    "F-8":  (33.7176, 73.0479), "F-7":  (33.7244, 73.0580),
    "F-6":  (33.7310, 73.0680),
    "E-7":  (33.7363, 73.0753), "E-8":  (33.7280, 73.0525),
    "E-9":  (33.7150, 73.0370), "E-10": (33.7050, 73.0200),
    "E-11": (33.6950, 73.0050),
    "D-12": (33.6960, 72.9850), "D-11": (33.7050, 72.9950),
    "D-10": (33.7150, 73.0100),
    "I-8":  (33.6700, 73.0830), "I-9":  (33.6644, 73.0758),
    "I-10": (33.6560, 73.0630), "I-11": (33.6480, 73.0480),
    "I-14": (33.6350, 73.0150), "I-16": (33.6200, 72.9800),
    "H-8":  (33.6810, 73.0620), "H-9":  (33.6750, 73.0700),
    "H-10": (33.6700, 73.0550), "H-11": (33.6650, 73.0400),
    "H-13": (33.6550, 73.0200),
    "Bahria Town Islamabad": (33.5494, 72.9943),
    "DHA Islamabad": (33.5295, 73.1185),
    "Faizabad": (33.6650, 73.0820),
    "Murree Road": (33.6644, 73.0758),
    "Blue Area": (33.7215, 73.0588),
    "Centaurus": (33.7205, 73.0495),
    "Pakistan Secretariat": (33.7290, 73.0930),
    "Rawalpindi": (33.5651, 73.0169),
    "Saddar Rawalpindi": (33.5977, 73.0479),
    "Lal Kurti": (33.6050, 73.0580),
    "Murree": (33.9079, 73.3939),
    # ── Lahore ─────────────────────────────────────────────────────────────
    "Lahore": (31.5204, 74.3587),
    "Gulberg Lahore": (31.5144, 74.3468),
    "DHA Lahore": (31.4722, 74.4000),
    "Bahria Town Lahore": (31.3621, 74.1819),
    "Model Town Lahore": (31.4815, 74.3299),
    "Johar Town Lahore": (31.4692, 74.2761),
    "Cantonment Lahore": (31.5355, 74.4057),
    "Allama Iqbal Town": (31.5117, 74.2917),
    "Township Lahore": (31.5004, 74.2717),
    "Wapda Town Lahore": (31.4610, 74.2706),
    "Raiwind": (31.2456, 74.2166),
    "Sheikhupura": (31.7126, 73.9858),
    # ── Karachi ────────────────────────────────────────────────────────────
    "Karachi": (24.8607, 67.0011),
    "Clifton Karachi": (24.8138, 67.0300),
    "DHA Karachi": (24.8070, 67.0614),
    "Bahria Town Karachi": (24.8617, 66.9714),
    "Gulshan-e-Iqbal": (24.9227, 67.1023),
    "PECHS Karachi": (24.8791, 67.0503),
    "Saddar Karachi": (24.8580, 67.0105),
    "Korangi": (24.8325, 67.1222),
    "Malir": (24.8940, 67.2045),
    "Landhi": (24.8420, 67.1833),
    "Lyari": (24.8755, 66.9996),
    "North Nazimabad": (24.9374, 67.0452),
    "Federal B Area": (24.9174, 67.0710),
    "Gulistan-e-Johar": (24.9218, 67.1301),
    # ── Faisalabad ─────────────────────────────────────────────────────────
    "Faisalabad": (31.4504, 73.1350),
    "Peoples Colony Faisalabad": (31.4398, 73.0932),
    # ── Multan ─────────────────────────────────────────────────────────────
    "Multan": (30.1575, 71.5249),
    "Bahria Town Multan": (30.2631, 71.4756),
    # ── Peshawar ───────────────────────────────────────────────────────────
    "Peshawar": (34.0151, 71.5249),
    "Hayatabad Peshawar": (33.9964, 71.4622),
    "University Town Peshawar": (34.0086, 71.4814),
    # ── Quetta ─────────────────────────────────────────────────────────────
    "Quetta": (30.1798, 66.9750),
    # ── Other Major Cities ─────────────────────────────────────────────────
    "Gujranwala": (32.1877, 74.1945),
    "Sialkot": (32.4945, 74.5229),
    "Bahawalpur": (29.3956, 71.6836),
    "Sargodha": (32.0836, 72.6711),
    "Hyderabad": (25.3960, 68.3578),
    "Sukkur": (27.7052, 68.8574),
    "Larkana": (27.5578, 68.2122),
    "Nawabshah": (26.2442, 68.4100),
    "Mirpur Khas": (25.5272, 69.0124),
    "Abbottabad": (34.1463, 73.2117),
    "Mansehra": (34.3322, 73.1975),
    "Swat": (34.7680, 72.3599),
    "Gilgit": (35.9218, 74.3083),
    "Skardu": (35.2894, 75.6333),
    "Muzaffarabad": (34.3700, 73.4700),
    "Gwadar": (25.1264, 62.3225),
    "Hub": (25.0500, 66.8832),
    "Turbat": (25.9874, 63.0620),
    "Dera Ghazi Khan": (30.0490, 70.6347),
    "Rahim Yar Khan": (28.4212, 70.2955),
    "Attock": (33.7665, 72.3601),
    "Jhelum": (32.9382, 73.7313),
    "Gujrat": (32.5736, 74.0790),
    "Sahiwal": (30.6682, 73.1110),
    "Okara": (30.8138, 73.4534),
    "Vehari": (30.0454, 72.3508),
    "Khanewal": (30.3013, 71.9322),
    "Pakpattan": (30.3438, 73.3869),
    "Lodhran": (29.5327, 71.6313),
    # Fallback — if nothing matches
    "Pakistan": (30.3753, 69.3451),
}

def _resolve_coordinates(location: str) -> tuple[float, float] | None:
    """
    Resolve any Pakistan location to GPS coordinates.
    1. Try the hardcoded dictionary first (fast, no API call).
    2. Fuzzy partial match against known locations.
    3. Fallback: Use OpenWeatherMap Geocoding API for ANY location in Pakistan.
    """
    if not location:
        return None
    # Exact match first
    if location in LOCATION_COORDINATES:
        return LOCATION_COORDINATES[location]
    # Case-insensitive partial match
    location_lower = location.lower()
    normalized_loc = location_lower.replace(" ", "-")
    for key, coords in LOCATION_COORDINATES.items():
        if key.lower() in location_lower or location_lower in key.lower() or key.lower() in normalized_loc or normalized_loc in key.lower():
            return coords
            
    # ── Live Geocoding Fallback (OpenWeatherMap) ─────────────────
    owm_key = os.getenv("OPENWEATHER_API_KEY", "")
    if owm_key:
        try:
            import requests
            def _geocode_owm(loc_str: str):
                query = f"{loc_str}, Pakistan"
                url = f"http://api.openweathermap.org/geo/1.0/direct?q={query}&limit=1&appid={owm_key}"
                res = requests.get(url, timeout=5)
                if res.status_code == 200:
                    data = res.json()
                    if data and len(data) > 0:
                        lat = data[0].get("lat")
                        lon = data[0].get("lon")
                        if lat and lon and 23 <= lat <= 38 and 60 <= lon <= 78:
                            print(f"[ingestion] Geocoded '{loc_str}' -> [{lat}, {lon}] via OpenWeatherMap")
                            return (lat, lon)
                return None

            result = _geocode_owm(location)
            if result: return result
            
            clean_loc = re.sub(r'(?i)\b(cantt|cantonment|city|town)\b', '', location).strip()
            if clean_loc and clean_loc != location:
                result = _geocode_owm(clean_loc)
                if result: return result
        except Exception as e:
            print(f"[ingestion] OWM Geocoding failed for '{location}': {e}")
            
    # ── Free Universal Fallback (OpenStreetMap / Nominatim) ─────────────────
    try:
        import requests
        def _geocode_osm(loc_str: str):
            url = f"https://nominatim.openstreetmap.org/search?q={loc_str},+Pakistan&format=json&limit=1"
            headers = {'User-Agent': 'CIRO-Emergency-System/1.0'}
            res = requests.get(url, headers=headers, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data and len(data) > 0:
                    lat = float(data[0].get("lat"))
                    lon = float(data[0].get("lon"))
                    if 23 <= lat <= 38 and 60 <= lon <= 78:
                        print(f"[ingestion] Geocoded '{loc_str}' -> [{lat}, {lon}] via OpenStreetMap")
                        return (lat, lon)
            return None

        result = _geocode_osm(location)
        if result: return result
        
        clean_loc = re.sub(r'(?i)\b(cantt|cantonment|city|town)\b', '', location).strip()
        if clean_loc and clean_loc != location:
            result = _geocode_osm(clean_loc)
            if result: return result
    except Exception as e:
        print(f"[ingestion] OSM Geocoding failed for '{location}': {e}")

    # Fallback to center of Pakistan if everything fails
    return LOCATION_COORDINATES["Pakistan"]


# ---------------------------------------------------------------------------
# Prompt template (used in live mode)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """
You are a crisis-signal extraction engine for an emergency response platform.
Given a raw text message (which may be in English, Urdu, Roman Urdu, Pushto, Sindhi, Punjabi, or Balochi), extract
the following fields and return ONLY a valid JSON object — no markdown, no explanation.

Fields to extract:
- signal_type    : Category of crisis (e.g. "flood", "fire", "accident", "medical", "earthquake", "traffic_gridlock", "disease_outbreak", "infrastructure_collapse", "multiple_crisis", "unknown")
- location       : Named place mentioned (e.g. "G-10", "Hayatabad Peshawar", "Clifton Karachi"). Use null if unclear.
- coordinates    : [lat, lng] from the known list below if the location matches, else null.
- crisis_keywords: List of key terms describing the crisis (in English), e.g. ["flood", "stuck cars"]
- severity_hint  : One of "low", "medium", "high", "critical" based on urgency cues in the text.
- language       : ISO 639-1 code of the primary language ("en" for English, "ur" for Urdu/Roman-Urdu, "ps" for Pushto, "sd" for Sindhi, "pa" for Punjabi, "bal" for Balochi).
- raw_text       : The original input text, unchanged.

Rules:
1. If the text mentions water logging, flooding, or "pani bhar gaya", set signal_type = "flood".
2. If vehicles are stuck / people are trapped, set severity_hint = "high" at minimum.
3. Return ONLY the JSON object. Do not include ```json fences or any commentary.
""".strip()

# ---------------------------------------------------------------------------
# Rule-based fallback extractor (DEMO_MODE or after quota exhaustion)
# ---------------------------------------------------------------------------

_FLOOD_KEYWORDS_UR = ["pani", "bhar", "sailab", "flood", "water", "barish", "baarish", "baran", "پانی", "بارش"]
_FIRE_KEYWORDS     = ["aag", "fire", "jalana", "burn", "dhuan", "smoke", "آگ", "دھواں"]
_TRAPPED_KEYWORDS  = ["phans", "trapped", "stuck", "phas", "collision", "accident", "crash", "hadsa", "ٹکر", "حادثہ"]
_EARTHQUAKE_KEYWORDS = ["earthquake", "zalzala", "quake", "hila", "زلزلہ"]
_GRIDLOCK_KEYWORDS = ["gridlock", "jam", "slow", "heavy traffic", "rush", "بلاک", "جام"]
_OUTBREAK_KEYWORDS = ["dengue", "corona", "outbreak", "disease", "sick", "virus", "hospital", "waba", "بیماری", "وبا"]
_COLLAPSE_KEYWORDS = ["collapse", "fell", "damage", "structural", "shikast", "گرگیا", "نقصان"]

def _demo_extract(raw_input: str) -> dict:
    """
    Lightweight rule-based extractor — no API call required.
    Covers the Islamabad/Pakistan locations defined in LOCATION_COORDINATES.
    """
    text_lower = raw_input.lower()

    # --- location ---
    location = None
    coordinates = None
    # Sort locations by length in descending order to prevent overlap matching (e.g. "Lahore" instead of "DHA Lahore")
    sorted_locations = sorted(LOCATION_COORDINATES.items(), key=lambda item: len(item[0]), reverse=True)
    for name, (lat, lng) in sorted_locations:
        if name.lower() in text_lower:
            location = name
            coordinates = [lat, lng]
            break

    # --- signal_type ---
    if any(kw in text_lower for kw in _FLOOD_KEYWORDS_UR):
        signal_type = "flood"
    elif any(kw in text_lower for kw in _FIRE_KEYWORDS):
        signal_type = "fire"
    elif any(kw in text_lower for kw in _EARTHQUAKE_KEYWORDS):
        signal_type = "earthquake"
    elif any(kw in text_lower for kw in _GRIDLOCK_KEYWORDS):
        signal_type = "traffic_gridlock"
    elif any(kw in text_lower for kw in _OUTBREAK_KEYWORDS):
        signal_type = "disease_outbreak"
    elif any(kw in text_lower for kw in _COLLAPSE_KEYWORDS):
        signal_type = "infrastructure_collapse"
    elif any(kw in text_lower for kw in _TRAPPED_KEYWORDS):
        signal_type = "accident"
    else:
        signal_type = "unknown"

    # --- severity_hint ---
    if any(kw in text_lower for kw in ["critical", "muth", "dead", "harkat", "شدید"]):
        severity_hint = "critical"
    elif any(kw in text_lower for kw in _TRAPPED_KEYWORDS) or signal_type in ["earthquake", "infrastructure_collapse"]:
        severity_hint = "high"
    elif signal_type in ["flood", "fire", "disease_outbreak"]:
        severity_hint = "medium"
    else:
        severity_hint = "low"

    # --- crisis_keywords ---
    crisis_keywords: list[str] = []
    if signal_type == "flood":
        crisis_keywords.append("flood")
    elif signal_type == "fire":
        crisis_keywords.append("fire")
    elif signal_type == "earthquake":
        crisis_keywords.append("earthquake")
    elif signal_type == "traffic_gridlock":
        crisis_keywords.append("traffic_gridlock")
    elif signal_type == "disease_outbreak":
        crisis_keywords.append("disease_outbreak")
    elif signal_type == "infrastructure_collapse":
        crisis_keywords.append("infrastructure_collapse")
    elif signal_type == "accident":
        crisis_keywords.append("accident")

    if any(kw in text_lower for kw in _TRAPPED_KEYWORDS):
        crisis_keywords.append("stuck vehicles")

    # --- language ---
    pushto_markers = ["day", "zma", "dere", "wraz", "takar"]
    sindhi_markers = ["thiyo", "chho", "sajhi", "hadso"]
    punjabi_markers = ["assi", "tussi", "hoya", "nu", "vahva", "barish"]
    balochi_markers = ["aast", "cha", "sharr", "aap"]
    urdu_roman_markers = ["mein", "hai", "gaya", "gayi", "hain", "ka", "ki", "ko"]
    
    words = set(text_lower.split())
    if any(m in words for m in pushto_markers):
        language = "ps"
    elif any(m in words for m in sindhi_markers):
        language = "sd"
    elif any(m in words for m in punjabi_markers):
        language = "pa"
    elif any(m in words for m in balochi_markers):
        language = "bal"
    elif any(m in words for m in urdu_roman_markers):
        language = "ur"
    else:
        language = "en"

    return {
        "signal_type":     signal_type,
        "location":        location,
        "coordinates":     coordinates,
        "crisis_keywords": crisis_keywords,
        "severity_hint":   severity_hint,
        "language":        language,
        "raw_text":        raw_input,
    }

# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------

def process_signal(raw_input: str) -> dict:
    """
    Parse a raw crisis-signal text and return a structured dict.

    Parameters
    ----------
    raw_input : str
        The raw text message from any reporting channel.

    Returns
    -------
    dict
        Structured signal with keys: signal_type, location, coordinates,
        crisis_keywords, severity_hint, language, raw_text, timestamp.
        Includes a 'source' key: 'gemini' or 'demo_fallback'.
    """
    result: dict | None = None

    if not DEMO_MODE:
        client = genai.Client(api_key=_API_KEY)
        last_error: Exception | None = None

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = client.models.generate_content(
                    model=MODEL_NAME,
                    contents=raw_input,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT,
                        response_mime_type="application/json",
                    ),
                )
                text = response.text.strip()

                # Strip accidental markdown fences if model adds them
                if text.startswith("```"):
                    text = re.sub(r"^```(?:json)?\s*", "", text)
                    text = re.sub(r"\s*```$", "", text)

                result = json.loads(text)
                result["source"] = "gemini"
                break  # success — exit retry loop

            except genai_errors.ClientError as exc:
                # Only retry on 429 Resource Exhausted; re-raise other client errors
                if exc.code != 429:
                    raise
                last_error = exc
                retry_after = RETRY_BASE_DELAY * attempt
                print(
                    f"[agent_ingestion] 429 quota exceeded (attempt {attempt}/{MAX_RETRIES}). "
                    f"Waiting {retry_after}s before retry…"
                )
                time.sleep(retry_after)

            except Exception as exc:
                # For non-quota errors, fail fast
                raise exc

        if result is None:
            # All retries exhausted — fall through to demo fallback
            print(
                f"[agent_ingestion] Quota still exhausted after {MAX_RETRIES} retries. "
                "Switching to rule-based DEMO fallback."
            )
            result = _demo_extract(raw_input)
            result["source"] = "demo_fallback"
    else:
        print("[agent_ingestion] DEMO_MODE=true — using rule-based extractor.")
        result = _demo_extract(raw_input)
        result["source"] = "demo_fallback"

    # ------------------------------------------------------------------
    # Post-processing: fill coordinates from known table if model missed them
    # ------------------------------------------------------------------
    if result.get("location") and result.get("coordinates") is None:
        loc = result["location"]
        if loc in LOCATION_COORDINATES:
            lat, lng = LOCATION_COORDINATES[loc]
            result["coordinates"] = [lat, lng]

    # ------------------------------------------------------------------
    # Append server-side UTC timestamp
    # ------------------------------------------------------------------
    result["timestamp"] = datetime.utcnow().isoformat() + "Z"

    return result

# ---------------------------------------------------------------------------
# Quick smoke-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    test_input = "G-10 mein pani bhar gaya hai, gaariyan phans gayi hain"
    print(f"Input  : {test_input}")
    print(f"Source : {'DEMO_MODE (rule-based)' if DEMO_MODE else 'Gemini API (with fallback)'}\n")

    output = process_signal(test_input)
    print("Output:")
    print(json.dumps(output, indent=2, ensure_ascii=False))

    # Assertions for expected values
    assert output.get("location") == "G-10",      f"Expected location=G-10,  got {output.get('location')}"
    assert output.get("language") == "ur",         f"Expected language=ur,    got {output.get('language')}"
    assert output.get("severity_hint") == "high",  f"Expected severity=high,  got {output.get('severity_hint')}"
    assert "timestamp" in output,                  "Missing timestamp field"

    print(f"\n[OK] All assertions passed.  [source={output.get('source')}]")
