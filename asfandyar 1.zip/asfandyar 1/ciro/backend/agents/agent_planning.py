"""
agent_planning.py
-----------------
Planning agent for CIRO emergency response.

Uses google-genai (Gemini 2.5 Pro) to translate a detected crisis dict
(produced by agent_detection) into a concrete, prioritised response plan.

Output fields
-------------
- response_id          : str  — unique plan ID, format "R-<8 hex chars>"
- priority_level       : int  — 1 (lowest) … 5 (highest)
- actions              : list[dict]  — ordered list of response actions
- expected_outcomes    : list[str]  — one sentence per anticipated outcome
- escalation_threshold : str  — condition under which to escalate further

Each action dict contains
- action_id            : str  — "A-<N>" (1-indexed)
- type                 : "traffic_reroute" | "emergency_dispatch"
                         | "public_alert" | "resource_allocation"
- description          : str
- target_location      : str
- resources_needed     : list[str]
- estimated_time_minutes: int
- priority             : int 1–5

DEMO_MODE (DEMO_MODE=true in .env) skips the API and uses a rule-based
fallback — useful when the free-tier quota is exhausted or during testing.
"""

import json
import os
import re
import time
import uuid
from datetime import datetime

from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai import errors as genai_errors

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

load_dotenv()

_API_KEY  = os.getenv("GEMINI_API_KEY", "")
DEMO_MODE: bool = os.getenv("DEMO_MODE", "false").lower() == "true"

# gemini-2.5-flash — fast and capable for real-time emergency planning.
MODEL_NAME     = "gemini-2.5-flash"
FALLBACK_MODEL = "gemini-2.0-flash"

# Retry settings
MAX_RETRIES      = 2
RETRY_BASE_DELAY = 5

# ---------------------------------------------------------------------------
# Available resources (hardcoded inventory)
# ---------------------------------------------------------------------------

RESOURCES: dict = {
    "rescue_boats": {
        "count": 2,
        "base":  "Margalla Station",
    },
    "ambulances": {
        "count": 4,
        "bases": ["PIMS", "Polyclinic"],
    },
    "police_units": {
        "count":      6,
        "deployment": "city-wide",
    },
    "alert_subscribers": 15_000,
}

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = f"""
You are a real-time emergency response planning engine for CIRO — an urban
crisis management platform serving all major cities across Pakistan.

You will receive a JSON object describing a detected crisis. Your task is to
generate a concrete, prioritised response plan and return ONLY a valid JSON
object — no markdown, no explanation outside the JSON.

Available resources
-------------------
{json.dumps(RESOURCES, indent=2)}

Output schema (return EXACTLY this structure)
---------------------------------------------
{{
  "response_id"          : "<provided — do not change>",
  "priority_level"       : <int 1–5>,
  "actions"              : [
    {{
      "action_id"               : "A-1",
      "type"                    : "<traffic_reroute|emergency_dispatch|public_alert|resource_allocation>",
      "description"             : "<concise, actionable instruction>",
      "target_location"         : "<location string>",
      "resources_needed"        : ["<resource name>", ...],
      "estimated_time_minutes"  : <int>,
      "priority"                : <int 1–5>
    }},
    ...
  ],
  "expected_outcomes"    : ["<one sentence per outcome>", ...],
  "escalation_threshold" : "<condition string — when to escalate further>"
}}

Planning rules
--------------
1. Generate between 2 and 4 actions. Each must be distinct in type.
2. For urban_flooding crises:
   - ALWAYS include a traffic_reroute action.
   - ALWAYS include an emergency_dispatch action (rescue boats + ambulances).
   - ALWAYS include a public_alert action targeting alert_subscribers.
3. For heatwave: include public_alert + resource_allocation (medical teams).
4. For road_blockage/accident: include traffic_reroute + emergency_dispatch.
5. priority_level must equal the highest action priority in the plan.
6. escalation_threshold must be a specific, measurable condition
   (e.g. "Water level exceeds 1.5 m OR casualties reported > 10").
7. Assign resources only from the Available resources list above.
8. The response_id field is pre-filled — copy it unchanged into your output.
9. Return ONLY the JSON object. No ```json fences.
""".strip()

# ---------------------------------------------------------------------------
# Rule-based fallback planner (DEMO_MODE or after quota exhaustion)
# ---------------------------------------------------------------------------

def _demo_plan(crisis: dict, response_id: str) -> dict:
    """
    Lightweight rule-based planner — no API call required.
    Produces a deterministic plan based on crisis_type and severity.
    """
    crisis_type = (crisis.get("crisis_type") or "none").lower()
    location    = crisis.get("location") or "unknown location"
    severity    = (crisis.get("severity") or "medium").lower()
    confidence  = float(crisis.get("confidence") or 0.5)

    # Map severity to priority
    sev_priority = {"low": 1, "medium": 2, "high": 4, "critical": 5}
    base_priority = sev_priority.get(severity, 3)

    actions: list[dict] = []
    outcomes: list[str] = []
    escalation = f"Situation deteriorates or confidence rises above {min(confidence + 0.05, 1.0):.2f}."

    action_counter = 1

    # ------------------------------------------------------------------ flood
    if crisis_type == "urban_flooding":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Divert all inbound traffic away from {location} via alternative "
                "routes. Deploy traffic police at all entry points."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 10,
            "priority"               : base_priority,
        })
        action_counter += 1
        outcomes.append(f"Traffic congestion at {location} reduced within 15 minutes.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Deploy 2 rescue boats from Margalla Station and 2 ambulances "
                f"from PIMS to {location} for stranded vehicle rescue."
            ),
            "target_location"        : location,
            "resources_needed"       : ["rescue_boats", "ambulances"],
            "estimated_time_minutes" : 20,
            "priority"               : base_priority,
        })
        action_counter += 1
        outcomes.append("Stranded residents evacuated; casualty risk minimised.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"Send flood warning SMS/push notification to all "
                f"{RESOURCES['alert_subscribers']:,} subscribers. "
                f"Advise avoidance of {location} and low-lying roads."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 3,
            "priority"               : base_priority - 1 if base_priority > 1 else 1,
        })
        action_counter += 1
        outcomes.append("Public informed; voluntary road avoidance reduces secondary congestion.")

        escalation = (
            "Water level exceeds 1.5 m OR reported casualties > 5 OR "
            "rescue boats unable to access within 30 minutes."
        )

    # ----------------------------------------------------------------- heatwave
    elif crisis_type == "heatwave":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"Issue heatwave advisory to {RESOURCES['alert_subscribers']:,} "
                "subscribers. Advise indoor shelter 11 AM–4 PM."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 3,
            "priority"               : base_priority,
        })
        action_counter += 1
        outcomes.append("Public awareness raised; heat-stroke incidents reduced.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "resource_allocation",
            "description"            : (
                f"Pre-position 2 ambulances at PIMS and Polyclinic for rapid "
                "heat-stroke response."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances"],
            "estimated_time_minutes" : 15,
            "priority"               : base_priority - 1 if base_priority > 1 else 1,
        })
        action_counter += 1
        outcomes.append("Medical response capacity staged; response time under 8 minutes.")

        escalation = "Heat index exceeds 48 °C OR hospital admissions > 20 per hour."

    # -------------------------------------------------- road_blockage / accident
    elif crisis_type in ("road_blockage", "accident"):
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Close blocked segment at {location}. Redirect traffic via "
                "designated detour corridors."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 8,
            "priority"               : base_priority,
        })
        action_counter += 1
        outcomes.append("Traffic flow restored on alternate routes within 20 minutes.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Dispatch 1 ambulance from nearest base to {location} for "
                "injury triage and police units to clear collision debris."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances", "police_units"],
            "estimated_time_minutes" : 12,
            "priority"               : base_priority,
        })
        action_counter += 1
        outcomes.append("Injured parties treated and structural clearance complete.")

        escalation = "Casualties reported > 3 OR blockage duration exceeds 45 minutes."

    # ----------------------------------------------------------------- earthquake
    elif crisis_type == "earthquake":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"🚨 Broadcast emergency earthquake advisory to all {RESOURCES['alert_subscribers']:,} "
                "residents in the zone. Advise open spaces, drop-cover-hold, and warn of aftershocks."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 2,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Resident awareness raised; evacuation to safe zones completed.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Deploy 4 ambulances and 4 police units to {location} for structural search "
                "and rescue operations and crowd management."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances", "police_units"],
            "estimated_time_minutes" : 15,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Rescue teams active; critical trauma cases stabilized and transported.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "resource_allocation",
            "description"            : (
                f"Set up emergency field triage and distribution of food, water, and "
                f"first-aid supplies at {location} security perimeter."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 25,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Relief distribution established; immediate community needs served.")

        escalation = "Secondary structural collapse reported OR aftershock magnitude exceeds 5.5."

    # ------------------------------------------------------------- traffic_gridlock
    elif crisis_type == "traffic_gridlock":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Configure dynamic green-wave signals and set up detours at all main entries "
                f"leading to {location}."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 5,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Inbound volume reduced, enabling standard clear-out.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Deploy 4 police units to physically manage intersections and clear gridlocked cars."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 10,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Gridlock bottleneck unlocked; vehicular movement restored.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"Broadcast congestion bypass SMS to {RESOURCES['alert_subscribers']:,} subscribers, "
                f"warning of extreme delays around {location}."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 3,
            "priority"               : 3,
        })
        action_counter += 1
        outcomes.append("Alternative route adoption by public reduces local demand.")

        escalation = "Gridlock grid extends beyond 5km radius OR duration exceeds 3 hours."

    # ------------------------------------------------------------- disease_outbreak
    elif crisis_type == "disease_outbreak":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"Distribute sanitary and isolation guidelines to {RESOURCES['alert_subscribers']:,} "
                f"subscribers in the {location} sector to contain outbreak spread."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 5,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Public hygiene adherence established; community transmission rate stabilized.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "resource_allocation",
            "description"            : (
                f"Pre-position mobile health response units and diagnostic hubs near {location}."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances"],
            "estimated_time_minutes" : 20,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Triage pipeline operational; early detection of active cases.")

        escalation = "Infection growth rate exceeds 20% in 24 hours OR hospital beds reach 100% capacity."

    # ------------------------------------------------------- infrastructure_collapse
    elif crisis_type == "infrastructure_collapse":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Complete dynamic road closures around structural collapse at {location}. "
                "Redirect all surrounding pathways to buffer zone exits."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 5,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Structural collapse site secured; traffic completely diverted.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Dispatch 3 ambulances and 4 police units to collapsed structure at {location} "
                "for victim extraction and emergency medical response."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances", "police_units"],
            "estimated_time_minutes" : 12,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Victims extricated; primary safety check verified.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"SMS alert broadcast: Extreme structural failure at {location}. Stay 1km clear."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 3,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Public safety perimeter established through informational warning.")

        escalation = "Trapped survivors count exceeds 10 OR sliding sensor triggers secondary failure."

    # -------------------------------------------------------------- multiple_crisis
    elif crisis_type == "multiple_crisis":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description" : (
                f"🚨 CRITICAL: Coordinated multi-agency alert broadcast to all {RESOURCES['alert_subscribers']:,} "
                f"subscribers. Simultaneous emergencies active at {location}. Stay indoors."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 2,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Information disseminated instantly; public evacuation behaviors controlled.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Coordinated deployment: 2 rescue boats and 4 ambulances dispatched to {location} "
                "for simultaneous medical emergencies."
            ),
            "target_location"        : location,
            "resources_needed"       : ["rescue_boats", "ambulances"],
            "estimated_time_minutes" : 15,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Emergency services activated concurrently across all hazard points.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Divert all vehicles in 2km radius around {location}. Mobilize 6 police units."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 8,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Complete exclusion zone established; clear channels for rescue vehicles.")

        escalation = "Rescue resources depleted OR casualties reported > 15."

    # -------------------------------------------------------------------------- fire
    elif crisis_type == "fire":
        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "emergency_dispatch",
            "description"            : (
                f"Dispatch fire engines and 2 ambulances to {location} for active blaze control and triage."
            ),
            "target_location"        : location,
            "resources_needed"       : ["ambulances", "police_units"],
            "estimated_time_minutes" : 10,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Fire containment operations initiated; casualties treated on site.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "public_alert",
            "description"            : (
                f"Broadcast evacuation SMS to all {RESOURCES['alert_subscribers']:,} subscribers in "
                f"{location} sector due to toxic smoke plumes and explosion hazards."
            ),
            "target_location"        : location,
            "resources_needed"       : ["alert_subscribers"],
            "estimated_time_minutes" : 3,
            "priority"               : 5,
        })
        action_counter += 1
        outcomes.append("Zone successfully evacuated within safety window.")

        actions.append({
            "action_id"              : f"A-{action_counter}",
            "type"                   : "traffic_reroute",
            "description"            : (
                f"Establish a safety perimeter and redirect all traffic away from {location}."
            ),
            "target_location"        : location,
            "resources_needed"       : ["police_units"],
            "estimated_time_minutes" : 7,
            "priority"               : 4,
        })
        action_counter += 1
        outcomes.append("Traffic isolated; access corridors kept clear.")

        escalation = "Blaze spreads to adjacent structures OR secondary hazardous chemicals explode."

    # -------------------------------------------------------------------- none
    else:
        actions.append({
            "action_id"              : "A-1",
            "type"                   : "public_alert",
            "description"            : "Monitor situation and issue advisory if conditions worsen.",
            "target_location"        : location,
            "resources_needed"       : [],
            "estimated_time_minutes" : 5,
            "priority"               : 1,
        })
        outcomes.append("Situation remains under observation with no immediate action required.")
        escalation = "Any new signal corroborates an active crisis."

    priority_level = max(a["priority"] for a in actions)

    return {
        "response_id"         : response_id,
        "priority_level"      : priority_level,
        "actions"             : actions,
        "expected_outcomes"   : outcomes,
        "escalation_threshold": escalation,
    }

# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------

def plan_response(crisis: dict) -> dict:
    """
    Generate a structured emergency response plan for a detected crisis.

    Parameters
    ----------
    crisis : dict
        Crisis assessment dict as produced by agent_detection.detect_crisis().
        Expected keys: crisis_type, location, confidence, severity,
        impact_areas, supporting_evidence, reasoning.

    Returns
    -------
    dict
        Keys: response_id, priority_level, actions, expected_outcomes,
        escalation_threshold, timestamp, source.
    """
    # Generate a stable response ID up-front so it can be embedded in the prompt
    response_id = "R-" + uuid.uuid4().hex[:8]

    result: dict | None = None

    if not DEMO_MODE:
        client  = genai.Client(api_key=_API_KEY)
        last_error: Exception | None = None

        # Inject response_id into the payload so the model echoes it unchanged
        payload_obj = dict(crisis)
        payload_obj["response_id"] = response_id
        payload = json.dumps(payload_obj, ensure_ascii=False, indent=2)

        active_model = MODEL_NAME

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = client.models.generate_content(
                    model=active_model,
                    contents=payload,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT,
                        response_mime_type="application/json",
                    ),
                )
                text = response.text.strip()

                # Strip accidental markdown fences if the model adds them
                if text.startswith("```"):
                    text = re.sub(r"^```(?:json)?\s*", "", text)
                    text = re.sub(r"\s*```$",          "", text)

                result = json.loads(text)
                # Guarantee response_id is correct even if model mutated it
                result["response_id"] = response_id
                result["source"]      = f"gemini ({active_model})"
                break  # success — exit retry loop

            except genai_errors.ClientError as exc:
                if exc.code == 404 and active_model != FALLBACK_MODEL:
                    # Primary model unavailable — switch to fallback once
                    print(
                        f"[agent_planning] {active_model} returned 404. "
                        f"Switching to fallback model {FALLBACK_MODEL}."
                    )
                    active_model = FALLBACK_MODEL
                    continue
                if exc.code != 429:
                    raise
                last_error  = exc
                retry_after = RETRY_BASE_DELAY * attempt
                print(
                    f"[agent_planning] 429 quota exceeded (attempt {attempt}/{MAX_RETRIES}). "
                    f"Waiting {retry_after}s before retry…"
                )
                time.sleep(retry_after)

            except Exception:
                raise  # non-quota errors fail fast

        if result is None:
            print(
                f"[agent_planning] Quota still exhausted after {MAX_RETRIES} retries. "
                "Switching to rule-based DEMO fallback."
            )
            result = _demo_plan(crisis, response_id)
            result["source"] = "demo_fallback"
    else:
        print("[agent_planning] DEMO_MODE=true — using rule-based planner.")
        result = _demo_plan(crisis, response_id)
        result["source"] = "demo_fallback"

    result["timestamp"] = datetime.utcnow().isoformat() + "Z"
    return result

# ---------------------------------------------------------------------------
# Quick smoke-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    test_crisis = {
        "crisis_detected"     : True,
        "crisis_type"         : "urban_flooding",
        "location"            : "G-10",
        "confidence"          : 0.94,
        "severity"            : "high",
        "impact_areas"        : ["traffic", "safety"],
        "supporting_evidence" : [
            "Social signal from G-10 indicates flooding (keywords: flood, stuck vehicles).",
            "Weather sensor reports 85 mm rainfall (RED alert).",
            "Traffic sensor at G-10: 5 km/h avg speed, 87% congestion.",
        ],
        "reasoning"           : "Three corroborating signals confirm urban flooding at G-10.",
    }

    print(f"Crisis   : {test_crisis['crisis_type']} @ {test_crisis['location']}")
    print(f"Source   : {'DEMO_MODE (rule-based)' if DEMO_MODE else 'Gemini API (with fallback)'}\n")

    output = plan_response(test_crisis)
    print("Output:")
    print(json.dumps(output, indent=2, ensure_ascii=False))

    # ---- Assertions ----
    assert output.get("response_id", "").startswith("R-"), \
        f"Expected response_id to start with 'R-', got: {output.get('response_id')}"

    actions = output.get("actions", [])
    assert 2 <= len(actions) <= 4, \
        f"Expected 2–4 actions, got {len(actions)}"

    action_types = {a.get("type") for a in actions}
    for required_type in ("traffic_reroute", "emergency_dispatch", "public_alert"):
        assert required_type in action_types, \
            f"Missing required action type: {required_type}. Got: {action_types}"

    assert all("action_id" in a for a in actions), \
        "One or more actions missing 'action_id'"
    assert all("estimated_time_minutes" in a for a in actions), \
        "One or more actions missing 'estimated_time_minutes'"
    assert "timestamp" in output, \
        "Missing timestamp field"

    print(f"\n[OK] All assertions passed.  [source={output.get('source')}]")
    print(f"     response_id={output.get('response_id')}  |  "
          f"priority_level={output.get('priority_level')}  |  "
          f"actions={len(actions)}")
