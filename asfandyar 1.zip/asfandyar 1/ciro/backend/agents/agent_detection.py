"""
agent_detection.py
------------------
Detection agent for CIRO crisis-signal processing.

Uses google-genai (Gemini 2.5 Pro) to analyse a list of pre-parsed signal
dicts (produced by agent_ingestion) and decide whether a crisis is occurring.

Output fields
-------------
- crisis_detected    : bool
- crisis_type        : "urban_flooding" | "heatwave" | "road_blockage"
                       | "accident" | "none"
- location           : dominant location string (or null)
- confidence         : float 0.0–1.0
- severity           : "low" | "medium" | "high" | "critical"
- impact_areas       : list[str]  — areas / roads / zones likely affected
- supporting_evidence: list[str]  — one sentence per corroborating signal
- reasoning          : str        — concise explanation of the decision

DEMO_MODE (DEMO_MODE=true in .env) skips the API and uses a rule-based
fallback — useful when the free-tier quota is exhausted or during testing.
"""

import json
import os
import re
import time
from datetime import datetime

from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai import errors as genai_errors

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

load_dotenv()

_API_KEY   = os.getenv("GEMINI_API_KEY", "")
DEMO_MODE: bool = os.getenv("DEMO_MODE", "false").lower() == "true"

# gemini-2.5-flash — fast and capable. Primary model for real-time emergency use.
MODEL_NAME     = "gemini-2.5-flash"
FALLBACK_MODEL = "gemini-2.0-flash"

# Retry settings
MAX_RETRIES      = 2
RETRY_BASE_DELAY = 5

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """
You are a real-time urban crisis detection engine for an emergency response
platform serving all major cities and metropolitan areas across Pakistan
(Islamabad, Rawalpindi, Lahore, Karachi, Peshawar, Quetta, Faisalabad, 
Multan, and 80+ other locations).

You will receive a JSON array of signal objects. Each signal has already been
parsed by an ingestion agent and contains:
  signal_type, location, coordinates, crisis_keywords, severity_hint,
  language, raw_text, timestamp, source  (and optionally sensor fields such as
  rainfall_mm, alert_level, avg_speed_kmh, congestion_percent).

Your task
---------
Analyse ALL signals together and return ONLY a valid JSON object with these
exact fields — no markdown, no explanation outside the JSON:

{
  "crisis_detected"     : <bool>,
  "crisis_type"         : <"urban_flooding"|"heatwave"|"road_blockage"|"accident"|"fire"|"earthquake"|"traffic_gridlock"|"disease_outbreak"|"infrastructure_collapse"|"multiple_crisis"|"none">,
  "location"            : <string or null>,
  "confidence"          : <float 0.0–1.0>,
  "severity"            : <"low"|"medium"|"high"|"critical">,
  "impact_areas"        : [<string>, ...],
  "supporting_evidence" : [<string>, ...],
  "reasoning"           : <string>
}

Detection rules
---------------
1. PHYSICAL CROSS-REFERENCE VALIDATION (CRITICAL):
   - You MUST use your Google Search tool to search for real-time news, live traffic reports, or recent social media updates to verify if a flood, fire, or accident is actually happening in the specified location right now.
   - Do NOT blindly trust the user report. You must cross-examine user claims against physical telemetry signals AND live Google Search results.
   - CONTRADICTION RULE: If a user report claims an emergency but your Google Search or live weather sensor shows normal conditions, you MUST mark crisis_detected = false, crisis_type = "none", and set confidence < 0.30. In your reasoning, clearly flag this as a contradiction (e.g., "Google Search and live sensors confirm normal conditions, contradicting the user report").
   - EXCEPTION TO CONTRADICTION: If a user claims flooding but weather is dry, yet an independent "traffic" signal or Google Search confirms a massive local water pipe burst, detect "infrastructure_collapse" or "road_blockage" with medium confidence, NOT "urban_flooding".

2. CORROBORATION REQUIRED: You must have at least 2 independent signals
   pointing to the same crisis before setting confidence > 0.85.
   A single signal caps confidence at 0.60.

3. URBAN FLOODING cues: signal_type="flood", keywords containing "flood" /
   "pani" / "water logging", rainfall_mm >= 20 (requires matching weather telemetry),
   congestion spikes co-located with a confirmed flood signal.

4. HEATWAVE cues: signal_type="heatwave", temperature >= 42 °C, heat-index
   alerts.

5. ROAD BLOCKAGE / ACCIDENT: avg_speed_kmh < 10 with congestion_percent > 80
   and a matching social or sensor signal.

6. EARTHQUAKE: signal_type="earthquake", seismic anomalies.

7. TRAFFIC GRIDLOCK: signal_type="traffic_gridlock", massive vehicle traffic blockage.

8. DISEASE OUTBREAK: signal_type="disease_outbreak", healthcare alerts or viral spikes.

9. INFRASTRUCTURE COLLAPSE: signal_type="infrastructure_collapse", structural failure (e.g., burst pipes, building collapse).

10. MULTIPLE CRISIS: More than one high-severity distinct crises co-occurring.

11. Set severity = "critical" when confidence >= 0.90 AND severity_hint =
   "high" or "critical" in at least one signal.

12. impact_areas must list distinct location names extracted from the signals.

13. supporting_evidence must contain one concise sentence per signal that
   supports the conclusion (skip signals that contradict or are irrelevant).

14. If no crisis is detected, set crisis_detected=false, crisis_type="none",
   confidence <= 0.30, severity="low".

Return ONLY the JSON object. No ```json fences.
""".strip()

# ---------------------------------------------------------------------------
# Rule-based fallback detector (DEMO_MODE or after quota exhaustion)
# ---------------------------------------------------------------------------

def _demo_detect(signals: list) -> dict:
    """
    Lightweight rule-based crisis detector — no API call required.
    Mirrors the logic described in SYSTEM_PROMPT but executed locally.
    """
    flood_signals   = 0
    traffic_signals = 0
    heat_signals    = 0
    fire_signals    = 0
    earthquake_signals = 0
    gridlock_signals = 0
    outbreak_signals = 0
    collapse_signals = 0
    
    locations: list[str] = []
    evidence: list[str]  = []
    max_rainfall    = 0.0
    min_speed       = float("inf")
    max_congestion  = 0.0

    for sig in signals:
        loc = sig.get("location")
        if loc:
            locations.append(loc)

        st    = (sig.get("signal_type") or "").lower()
        kws   = [k.lower() for k in (sig.get("crisis_keywords") or [])]
        shint = (sig.get("severity_hint") or "low").lower()

        # --- flood indicators ---
        if st == "flood" or any(k in kws for k in ("flood", "pani", "water logging")):
            flood_signals += 1
            evidence.append(
                f"Social/sensor signal from {loc or 'unknown'} indicates flooding "
                f"(keywords: {', '.join(kws) or st})."
            )

        rain = sig.get("rainfall_mm", 0) or 0
        if rain > max_rainfall:
            max_rainfall = rain
        if rain >= 50:
            flood_signals += 1
            level = sig.get("alert_level", "")
            evidence.append(
                f"Weather sensor reports {rain} mm rainfall"
                + (f" ({level} alert)" if level else "") + "."
            )

        # --- traffic indicators ---
        speed  = sig.get("avg_speed_kmh")
        cong   = sig.get("congestion_percent", 0) or 0
        if speed is not None and speed < min_speed:
            min_speed = speed
        if cong > max_congestion:
            max_congestion = cong
        if speed is not None and speed < 10 and cong > 80:
            traffic_signals += 1
            evidence.append(
                f"Traffic sensor at {loc or 'unknown'}: {speed} km/h avg speed, "
                f"{cong}% congestion."
            )

        # --- heat indicators ---
        if st == "heatwave":
            heat_signals += 1
            evidence.append(f"Heatwave signal detected at {loc or 'unknown'}.")

        # --- fire indicators ---
        if st == "fire" or "fire" in kws:
            fire_signals += 1
            evidence.append(f"Fire emergency detected at {loc or 'unknown'}.")

        # --- earthquake indicators ---
        if st == "earthquake" or "earthquake" in kws:
            earthquake_signals += 1
            evidence.append(f"Seismic activity detected at {loc or 'unknown'}.")

        # --- gridlock indicators ---
        if st == "traffic_gridlock" or "traffic_gridlock" in kws:
            gridlock_signals += 1
            evidence.append(f"Traffic gridlock reported at {loc or 'unknown'}.")

        # --- disease outbreak indicators ---
        if st == "disease_outbreak" or "disease_outbreak" in kws:
            outbreak_signals += 1
            evidence.append(f"Disease outbreak alert issued at {loc or 'unknown'}.")

        # --- infrastructure collapse indicators ---
        if st == "infrastructure_collapse" or "infrastructure_collapse" in kws:
            collapse_signals += 1
            evidence.append(f"Infrastructure collapse reported at {loc or 'unknown'}.")

    # --- deduplicate locations ---
    seen: set[str] = set()
    impact_areas: list[str] = []
    for l in locations:
        if l not in seen:
            seen.add(l)
            impact_areas.append(l)

    # --- determine crisis type & confidence ---
    crisis_detected = False
    crisis_type     = "none"
    confidence      = 0.20
    severity        = "low"

    # Coordinated Multiple Crisis Check
    active_types = []
    if flood_signals >= 1: active_types.append("urban_flooding")
    if fire_signals >= 1: active_types.append("fire")
    if earthquake_signals >= 1: active_types.append("earthquake")
    if outbreak_signals >= 1: active_types.append("disease_outbreak")
    if collapse_signals >= 1: active_types.append("infrastructure_collapse")

    if len(active_types) >= 2:
        crisis_detected = True
        crisis_type     = "multiple_crisis"
        confidence      = 0.95
        severity        = "critical"
    elif earthquake_signals >= 1:
        crisis_detected = True
        crisis_type     = "earthquake"
        confidence      = 0.92
        severity        = "critical"
    elif collapse_signals >= 1:
        crisis_detected = True
        crisis_type     = "infrastructure_collapse"
        confidence      = 0.88
        severity        = "critical"
    elif fire_signals >= 1:
        crisis_detected = True
        crisis_type     = "fire"
        confidence      = 0.85
        severity        = "high"
    elif outbreak_signals >= 1:
        crisis_detected = True
        crisis_type     = "disease_outbreak"
        confidence      = 0.82
        severity        = "high"
    elif gridlock_signals >= 1:
        crisis_detected = True
        crisis_type     = "traffic_gridlock"
        confidence      = 0.80
        severity        = "medium"
    elif flood_signals >= 2:
        crisis_detected = True
        crisis_type     = "urban_flooding"
        confidence      = min(0.95, 0.70 + 0.10 * flood_signals)
        severity        = "critical" if confidence >= 0.90 else "high"
    elif traffic_signals >= 2:
        crisis_detected = True
        crisis_type     = "road_blockage"
        confidence      = 0.80
        severity        = "high"
    elif heat_signals >= 2:
        crisis_detected = True
        crisis_type     = "heatwave"
        confidence      = 0.78
        severity        = "high"
    elif flood_signals == 1 or traffic_signals == 1:
        crisis_detected = True
        crisis_type     = "urban_flooding" if flood_signals else "road_blockage"
        confidence      = 0.55
        severity        = "medium"

    reasoning = (
        f"Rule-based fallback: detected {flood_signals} flood, {traffic_signals} traffic, "
        f"{heat_signals} heat, {fire_signals} fire, {earthquake_signals} earthquake, "
        f"{gridlock_signals} gridlock, {outbreak_signals} outbreak, {collapse_signals} collapse "
        f"across {len(signals)} signals. "
        f"Peak rainfall: {max_rainfall} mm. "
        f"Min speed: {min_speed if min_speed < float('inf') else 'N/A'} km/h. "
        f"Max congestion: {max_congestion}%."
    )

    return {
        "crisis_detected"     : crisis_detected,
        "crisis_type"         : crisis_type,
        "location"            : impact_areas[0] if impact_areas else None,
        "confidence"          : round(confidence, 3),
        "severity"            : severity,
        "impact_areas"        : impact_areas,
        "supporting_evidence" : evidence,
        "reasoning"           : reasoning,
    }

# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------

def detect_crisis(signals: list) -> dict:
    """
    Analyse a list of pre-parsed signal dicts and return a structured
    crisis-detection assessment.

    Parameters
    ----------
    signals : list[dict]
        Signal dicts as produced by agent_ingestion.process_signal().
        Must contain at least one element.

    Returns
    -------
    dict
        Keys: crisis_detected, crisis_type, location, confidence, severity,
        impact_areas, supporting_evidence, reasoning, timestamp, source.
    """
    if not signals:
        return {
            "crisis_detected"     : False,
            "crisis_type"         : "none",
            "location"            : None,
            "confidence"          : 0.0,
            "severity"            : "low",
            "impact_areas"        : [],
            "supporting_evidence" : [],
            "reasoning"           : "No signals provided.",
            "timestamp"           : datetime.utcnow().isoformat() + "Z",
            "source"              : "empty_input",
        }

    result: dict | None = None

    if not DEMO_MODE:
        client     = genai.Client(api_key=_API_KEY)
        last_error: Exception | None = None
        payload    = json.dumps(signals, ensure_ascii=False, indent=2)
        active_model = MODEL_NAME

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = client.models.generate_content(
                    model=active_model,
                    contents=payload,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT,
                        response_mime_type="application/json",
                        tools=[{"google_search": {}}],
                    ),
                )
                text = response.text.strip()

                # Strip accidental markdown fences if the model adds them
                if text.startswith("```"):
                    text = re.sub(r"^```(?:json)?\s*", "", text)
                    text = re.sub(r"\s*```$",          "", text)

                result = json.loads(text)
                result["source"] = f"gemini ({active_model})"
                break  # success — exit retry loop

            except genai_errors.ClientError as exc:
                if exc.code == 404 and active_model != FALLBACK_MODEL:
                    # Primary model not available — switch to fallback once
                    print(
                        f"[agent_detection] {active_model} returned 404. "
                        f"Switching to fallback model {FALLBACK_MODEL}."
                    )
                    active_model = FALLBACK_MODEL
                    continue  # retry immediately with fallback model
                if exc.code != 429:
                    raise
                last_error  = exc
                retry_after = RETRY_BASE_DELAY * attempt
                print(
                    f"[agent_detection] 429 quota exceeded (attempt {attempt}/{MAX_RETRIES}). "
                    f"Waiting {retry_after}s before retry…"
                )
                time.sleep(retry_after)

            except Exception as exc:
                raise  # non-quota errors fail fast

        if result is None:
            print(
                f"[agent_detection] Quota still exhausted after {MAX_RETRIES} retries. "
                "Switching to rule-based DEMO fallback."
            )
            result = _demo_detect(signals)
            result["source"] = "demo_fallback"
    else:
        print("[agent_detection] DEMO_MODE=true — using rule-based detector.")
        result = _demo_detect(signals)
        result["source"] = "demo_fallback"

    result["timestamp"] = datetime.utcnow().isoformat() + "Z"
    return result

# ---------------------------------------------------------------------------
# Quick smoke-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Three corroborating signals — should yield urban_flooding, confidence > 0.85
    test_signals = [
        {
            # Signal 1 — social media report in Roman Urdu
            "signal_type"    : "flood",
            "location"       : "G-10",
            "coordinates"    : [33.6844, 73.0479],
            "crisis_keywords": ["flood", "stuck vehicles"],
            "severity_hint"  : "high",
            "language"       : "ur",
            "raw_text"       : "G-10 mein pani bhar gaya hai, gaariyan phans gayi hain",
            "timestamp"      : "2026-05-16T07:00:00Z",
            "source"         : "social_media",
        },
        {
            # Signal 2 — weather sensor with RED alert rainfall
            "signal_type"    : "flood",
            "location"       : "G-10",
            "coordinates"    : [33.6844, 73.0479],
            "crisis_keywords": ["heavy rainfall", "red alert"],
            "severity_hint"  : "critical",
            "language"       : "en",
            "raw_text"       : "Rainfall 85mm in 1 hour — RED ALERT issued for G-10 sector.",
            "timestamp"      : "2026-05-16T07:05:00Z",
            "source"         : "weather_sensor",
            # extra sensor fields for rule-based fallback
            "rainfall_mm"    : 85,
            "alert_level"    : "RED",
        },
        {
            # Signal 3 — traffic sensor showing near-standstill
            "signal_type"    : "traffic",
            "location"       : "G-10",
            "coordinates"    : [33.6844, 73.0479],
            "crisis_keywords": ["congestion", "slow traffic"],
            "severity_hint"  : "high",
            "language"       : "en",
            "raw_text"       : "G-10 main boulevard: avg speed 5 km/h, congestion 87%.",
            "timestamp"      : "2026-05-16T07:10:00Z",
            "source"         : "traffic_sensor",
            # extra sensor fields for rule-based fallback
            "avg_speed_kmh"     : 5,
            "congestion_percent": 87,
        },
    ]

    print(f"Signals  : {len(test_signals)}")
    print(f"Source   : {'DEMO_MODE (rule-based)' if DEMO_MODE else 'Gemini API (with fallback)'}\n")

    output = detect_crisis(test_signals)
    print("Output:")
    print(json.dumps(output, indent=2, ensure_ascii=False))

    # ---- Assertions ----
    assert output.get("crisis_detected") is True,          \
        f"Expected crisis_detected=True, got {output.get('crisis_detected')}"
    assert output.get("crisis_type") == "urban_flooding",  \
        f"Expected crisis_type=urban_flooding, got {output.get('crisis_type')}"
    assert output.get("confidence", 0) >= 0.85,            \
        f"Expected confidence >= 0.85, got {output.get('confidence')}"
    assert "timestamp" in output,                          \
        "Missing timestamp field"

    print(f"\n[OK] All assertions passed.  [source={output.get('source')}]")
