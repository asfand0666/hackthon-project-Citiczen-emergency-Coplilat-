import os
import json
import base64
import time
import uuid
import logging
import hashlib
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, HTTPException, File, UploadFile, Form, Request
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from google import genai
from google.genai import types
from dotenv import load_dotenv
from starlette.middleware.base import BaseHTTPMiddleware

# Custom Errors and Exceptions
from errors import (
    CrisisDomainException,
    IngestionError,
    CrisisDetectionError,
    PlanningError,
    SimulationError,
    RateLimitExceeded
)

load_dotenv()
_API_KEY = os.environ.get("GEMINI_API_KEY", "")

from agents.agent_ingestion import process_signal
from agents.agent_detection import detect_crisis
from agents.agent_planning import plan_response
from agents.agent_simulation import simulate_plan
from agents.agent_orchestrator import autonomous_run

# ---------------------------------------------------------------------------
# Structured JSON Logging
# ---------------------------------------------------------------------------

class StructuredJSONFormatter(logging.Formatter):
    def format(self, record):
        log_record = {
            "severity": record.levelname,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno
        }
        # Attach Trace ID if present in extra parameters
        if hasattr(record, "trace_id"):
            log_record["logging.googleapis.com/trace"] = record.trace_id
        return json.dumps(log_record)

# Initialize API Logger
logger = logging.getLogger("ciro_api")
logger.setLevel(logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(StructuredJSONFormatter())
logger.addHandler(stream_handler)

# ---------------------------------------------------------------------------
# In-Memory Response Caching
# ---------------------------------------------------------------------------

class InMemoryCache:
    def __init__(self, ttl_seconds: int = 30):
        self.ttl = ttl_seconds
        self.store = {} # key -> (data, timestamp)

    def _make_key(self, endpoint: str, data: Any) -> str:
        # Generate hash signature of the request payload
        serialized = json.dumps(data, sort_keys=True)
        return f"{endpoint}:{hashlib.sha256(serialized.encode()).hexdigest()}"

    def get(self, endpoint: str, data: Any) -> Optional[Any]:
        key = self._make_key(endpoint, data)
        if key in self.store:
            val, timestamp = self.store[key]
            if time.time() - timestamp < self.ttl:
                return val
            else:
                del self.store[key]
        return None

    def set(self, endpoint: str, data: Any, val: Any) -> None:
        key = self._make_key(endpoint, data)
        self.store[key] = (val, time.time())

# Instantiate dynamic cache with 30s TTL
cache = InMemoryCache(ttl_seconds=30)

# Initialize FastAPI App
app = FastAPI(
    title="CIRO Backend API",
    description="Crisis Intelligence & Response Orchestrator - Robust Multi-Agent Platform"
)

# ---------------------------------------------------------------------------
# Middleware Definitions
# ---------------------------------------------------------------------------

class LoggingAndTraceMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Inject Unique Trace ID
        trace_id = "tr-" + uuid.uuid4().hex[:12].upper()
        request.state.trace_id = trace_id

        logger.info(
            f"HTTP {request.method} request received for {request.url.path}",
            extra={"trace_id": trace_id}
        )
        
        t0 = time.time()
        response = await call_next(request)
        duration = time.time() - t0

        logger.info(
            f"HTTP {request.method} {request.url.path} responded {response.status_code} in {duration:.4f}s",
            extra={"trace_id": trace_id}
        )
        return response

class RateLimitingMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, requests_limit: int = 30, window_seconds: int = 60):
        super().__init__(app)
        self.requests_limit = requests_limit
        self.window_seconds = window_seconds
        self.client_history = {} # client_ip -> list of timestamps

    async def dispatch(self, request: Request, call_next):
        # Exclude documentation / health endpoints
        if request.url.path in ("/docs", "/redoc", "/openapi.json", "/health", "/favicon.ico", "/"):
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        now = time.time()

        # Evict timestamps outside current window
        history = self.client_history.get(client_ip, [])
        history = [t for t in history if now - t < self.window_seconds]
        self.client_history[client_ip] = history

        if len(history) >= self.requests_limit:
            logger.warning(
                f"Rate limit hit for IP: {client_ip}",
                extra={"trace_id": getattr(request.state, "trace_id", None)}
            )
            return JSONResponse(
                status_code=429,
                content={
                    "error_code": "RATE_LIMIT_EXCEEDED",
                    "message": f"Rate limit exceeded. Maximum {self.requests_limit} requests per {self.window_seconds} seconds.",
                    "timestamp": datetime.utcnow().isoformat() + "Z"
                }
            )

        self.client_history[client_ip].append(now)
        return await call_next(request)

# Register Custom Middlewares
app.add_middleware(LoggingAndTraceMiddleware)
app.add_middleware(RateLimitingMiddleware)

# Cross-Origin Resource Sharing
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Exception Handlers
# ---------------------------------------------------------------------------

@app.exception_handler(CrisisDomainException)
def domain_exception_handler(request: Request, exc: CrisisDomainException):
    logger.error(
        f"Domain error {exc.error_code}: {exc.message}",
        extra={"trace_id": getattr(request.state, "trace_id", None)}
    )
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error_code": exc.error_code,
            "message": exc.message,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
    )

@app.exception_handler(Exception)
def global_exception_handler(request: Request, exc: Exception):
    logger.exception(
        f"Unhandled system error: {str(exc)}",
        extra={"trace_id": getattr(request.state, "trace_id", None)}
    )
    return JSONResponse(
        status_code=500,
        content={
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected critical system failure occurred on CIRO platform.",
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }
    )

# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------

class IngestRequest(BaseModel):
    raw_text: str

class DetectRequest(BaseModel):
    signals: List[Dict[str, Any]]

class PlanRequest(BaseModel):
    crisis: Dict[str, Any]

class SimulateRequest(BaseModel):
    plan: Dict[str, Any]

class AutonomousRequest(BaseModel):
    raw_text: str
    include_weather: bool = True
    include_traffic: bool = True

# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/docs")

@app.get("/favicon.ico", include_in_schema=False)
def favicon():
    return {}

@app.post("/api/autonomous_run")
def api_autonomous_run(req: AutonomousRequest):
    """
    🤖 AUTONOMOUS PIPELINE ENDPOINT
    """
    cached = cache.get("autonomous_run", req.dict())
    if cached:
        return cached

    try:
        result = autonomous_run(
            raw_text=req.raw_text,
            include_weather=req.include_weather,
            include_traffic=req.include_traffic,
        )
        cache.set("autonomous_run", req.dict(), result)
        return result
    except Exception as e:
        raise CrisisDetectionError(f"Autonomous orchestration pipeline crashed: {str(e)}")

@app.post("/api/ingest")
def api_ingest(req: IngestRequest):
    """
    Process raw text signal and extract structured entities.
    """
    cached = cache.get("ingest", req.dict())
    if cached:
        return cached

    try:
        result = process_signal(req.raw_text)
        cache.set("ingest", req.dict(), result)
        return result
    except Exception as e:
        raise IngestionError(f"Signal extraction failed: {str(e)}")

@app.post("/api/detect")
def api_detect(req: DetectRequest):
    """
    Analyze multiple signals to detect if a crisis is occurring.
    """
    cached = cache.get("detect", req.dict())
    if cached:
        return cached

    try:
        result = detect_crisis(req.signals)
        cache.set("detect", req.dict(), result)
        return result
    except Exception as e:
        raise CrisisDetectionError(f"Crisis multi-signal detection failed: {str(e)}")

@app.post("/api/plan")
def api_plan(req: PlanRequest):
    """
    Generate an emergency response plan from a detected crisis.
    """
    cached = cache.get("plan", req.dict())
    if cached:
        return cached

    try:
        result = plan_response(req.crisis)
        cache.set("plan", req.dict(), result)
        return result
    except Exception as e:
        raise PlanningError(f"Response plan generation failed: {str(e)}")

@app.post("/api/simulate")
def api_simulate(req: SimulateRequest):
    """
    Simulate the execution of a response plan and compute metrics.
    """
    cached = cache.get("simulate", req.dict())
    if cached:
        return cached

    try:
        result = simulate_plan(req.plan)
        cache.set("simulate", req.dict(), result)
        return result
    except Exception as e:
        raise SimulationError(f"Metrics simulation failed: {str(e)}")

@app.get("/api/logs")
def api_logs():
    """
    Read execution logs from trace.jsonl.
    """
    base_dir = Path(__file__).resolve().parent
    logs_path = base_dir.parent.parent / "logs" / "trace.jsonl"
    
    if not logs_path.exists():
        return {"logs": []}
        
    logs = []
    try:
        with open(logs_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    logs.append(json.loads(line))
        return {"logs": logs}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read logs: {str(e)}")

@app.post("/api/reset")
def api_reset():
    """
    Clear all execution logs to reset the state.
    """
    base_dir = Path(__file__).resolve().parent
    logs_path = base_dir.parent.parent / "logs" / "trace.jsonl"
    
    try:
        if logs_path.exists():
            open(logs_path, 'w').close()
        return {"status": "success", "message": "Logs cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to reset logs: {str(e)}")

@app.post("/api/analyze_photo")
async def api_analyze_photo(file: UploadFile = File(...)):
    """
    🤖 REAL Gemini Vision Photo Analysis
    """
    try:
        image_bytes = await file.read()
        mime_type = file.content_type or "image/jpeg"

        if not _API_KEY:
            raise HTTPException(status_code=500, detail="GEMINI_API_KEY not configured")

        client = genai.Client(api_key=_API_KEY)

        system_prompt = """
You are a highly accurate emergency crisis detection AI for a smart city platform.

CRITICAL RULES:
1. You must ONLY detect a crisis if you can clearly see emergency conditions in the image.
2. If the image shows a normal scene (room, office, street with no emergency, food, selfie, nature, etc.), you MUST set crisis_detected=false and crisis_type="none".
3. Do NOT hallucinate or fabricate emergencies. Be truthful about what you see.
4. Only set crisis_detected=true if you see CLEAR evidence of: flooding, fire, smoke, accident, structural damage, crowd panic, medical emergency, etc.

Analyze the uploaded image and return ONLY a valid JSON object:
{
  "crisis_detected": <bool - true ONLY if a real emergency is visible>,
  "crisis_type": "<urban_flooding|fire|accident|road_blockage|earthquake|infrastructure_collapse|heatwave|none>",
  "severity": "<low|medium|high|critical>",
  "confidence": <float 0.0-1.0>,
  "description": "<2-3 sentence HONEST description of what you actually see in the image>",
  "location_hints": "<any visible location identifiers or 'not visible'>",
  "immediate_actions": ["<action 1>", "<action 2>"],
  "estimated_affected": "<number or range or 'none'>",
  "signal_text": "<A natural language description suitable as an emergency signal, or 'No emergency detected in image' if none>"
}

If there is NO emergency visible, return:
  crisis_detected=false, crisis_type="none", severity="low", confidence=0.95,
  description="No emergency detected. The image shows [describe what you see].",
  signal_text="No emergency detected in image."
""".strip()

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=[
                types.Part.from_bytes(data=image_bytes, mime_type=mime_type),
                "Analyze this image. Is there any real emergency or crisis visible? Be honest and accurate. Do not fabricate emergencies.",
            ],
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                response_mime_type="application/json",
            ),
        )

        result = json.loads(response.text.strip())
        result["source"] = "gemini_vision_live"
        return result

    except Exception as e:
        return {
            "crisis_detected": False,
            "crisis_type": "none",
            "severity": "low",
            "confidence": 0.0,
            "description": "Image analysis could not be completed. Please describe the emergency in text instead.",
            "location_hints": "not visible",
            "immediate_actions": ["Describe the situation in the text box below"],
            "estimated_affected": "unknown",
            "signal_text": "Photo analysis failed. Please type your emergency report.",
            "source": "vision_error",
            "error": str(e),
        }

@app.get("/health")
def health_check():
    import os
    return {
        "status": "ok",
        "gemini_key_set": bool(_API_KEY),
        "openweather_key_set": bool(os.getenv("OPENWEATHER_API_KEY", "")),
        "agents": ["ingestion", "detection", "planning", "simulation", "orchestrator", "vision"],
        "models": "gemini-2.5-flash (all agents)",
        "coverage": "All Pakistan — 80+ cities and areas",
    }
