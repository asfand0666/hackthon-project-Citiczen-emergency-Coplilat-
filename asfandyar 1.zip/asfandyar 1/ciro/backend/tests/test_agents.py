import unittest
import sys
import os
from datetime import datetime

# Ensure DEMO_MODE is true BEFORE imports to bypass Gemini API calls completely in testing
os.environ["DEMO_MODE"] = "true"

# Set up module paths
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import agents.agent_ingestion
import agents.agent_detection
import agents.agent_planning

agents.agent_ingestion.DEMO_MODE = True
agents.agent_detection.DEMO_MODE = True
agents.agent_planning.DEMO_MODE = True

from agents.agent_ingestion import process_signal, LOCATION_COORDINATES
from agents.agent_detection import detect_crisis
from agents.agent_planning import plan_response
from agents.agent_simulation import simulate_plan
from antigravity_layer.workflow import run_workflow

class TestCIROAgents(unittest.TestCase):

    def setUp(self):
        pass

    def test_multi_language_ingestion(self):
        """Test entity and language extraction across English, Urdu, Pashto, Sindhi, Punjabi, and Balochi."""
        # 1. Romanized Urdu
        ur_res = process_signal("G-10 mein pani bhar gaya hai, gaariyan phans gayi hain")
        self.assertEqual(ur_res["signal_type"], "flood")
        self.assertEqual(ur_res["location"], "G-10")
        self.assertEqual(ur_res["language"], "ur")
        self.assertEqual(ur_res["coordinates"], [33.6844, 73.0479])
        self.assertEqual(ur_res["severity_hint"], "high")

        # 2. Pashto (Peshawar region)
        ps_res = process_signal("Hayatabad Peshawar day baran kharab tufan takar")
        self.assertEqual(ps_res["location"], "Hayatabad Peshawar")
        self.assertEqual(ps_res["language"], "ps")
        self.assertEqual(ps_res["signal_type"], "flood")  # 'baran' triggers flood

        # 3. Sindhi (Karachi region)
        sd_res = process_signal("Clifton Karachi jo pani aahe hadso")
        self.assertEqual(sd_res["location"], "Clifton Karachi")
        self.assertEqual(sd_res["language"], "sd")
        self.assertEqual(sd_res["signal_type"], "flood")  # 'pani' triggers flood

        # 4. Punjabi (Lahore region)
        pa_res = process_signal("DHA Lahore da area barish te hoya gaya")
        self.assertEqual(pa_res["location"], "DHA Lahore")
        self.assertEqual(pa_res["language"], "pa")

        # 5. Balochi (Quetta region)
        bal_res = process_signal("Quetta cha aap aast sharr")
        self.assertEqual(bal_res["location"], "Quetta")
        self.assertEqual(bal_res["language"], "bal")

    def test_advanced_crisis_detection(self):
        """Test detection of standard and newly added advanced crisis types (Earthquake, Outbreak, Collapse, etc.)."""
        # 1. Earthquake Detection
        quake_sig = process_signal("Quetta mein heavy earthquake zalzala feel hua")
        det_res = detect_crisis([quake_sig])
        self.assertTrue(det_res["crisis_detected"])
        self.assertEqual(det_res["crisis_type"], "earthquake")
        self.assertEqual(det_res["severity"], "critical")
        self.assertEqual(det_res["confidence"], 0.92)

        # 2. Infrastructure Collapse Detection
        collapse_sig = process_signal("Gulberg Lahore main building collapse structural damage fell down")
        det_res2 = detect_crisis([collapse_sig])
        self.assertTrue(det_res2["crisis_detected"])
        self.assertEqual(det_res2["crisis_type"], "infrastructure_collapse")
        self.assertEqual(det_res2["severity"], "critical")

        # 3. Disease Outbreak Detection
        outbreak_sig = process_signal("F-10 area main dengue malaria disease outbreak hospital loaded")
        det_res3 = detect_crisis([outbreak_sig])
        self.assertTrue(det_res3["crisis_detected"])
        self.assertEqual(det_res3["crisis_type"], "disease_outbreak")
        self.assertEqual(det_res3["severity"], "high")

        # 4. Multiple Crisis (Coordinated Check)
        flood_sig = process_signal("Faizabad main heavy flood water logging")
        fire_sig = process_signal("Faizabad main fire emergency and toxic smoke")
        det_res4 = detect_crisis([flood_sig, fire_sig])
        self.assertTrue(det_res4["crisis_detected"])
        self.assertEqual(det_res4["crisis_type"], "multiple_crisis")
        self.assertEqual(det_res4["severity"], "critical")
        self.assertEqual(det_res4["confidence"], 0.95)

    def test_response_planning_templates(self):
        """Test action plan generation maps resource and escalation thresholds for advanced crises."""
        # 1. Earthquake Response Plan
        quake_crisis = {
            "crisis_detected": True,
            "crisis_type": "earthquake",
            "location": "Quetta",
            "confidence": 0.92,
            "severity": "critical"
        }
        plan = plan_response(quake_crisis)
        self.assertEqual(plan["priority_level"], 5)
        self.assertTrue(any(a["type"] == "public_alert" for a in plan["actions"]))
        self.assertTrue(any(a["type"] == "emergency_dispatch" for a in plan["actions"]))
        self.assertTrue(any(a["type"] == "resource_allocation" for a in plan["actions"]))
        self.assertIn("aftershock", plan["escalation_threshold"].lower())

        # 2. Disease Outbreak Plan
        outbreak_crisis = {
            "crisis_detected": True,
            "crisis_type": "disease_outbreak",
            "location": "F-10",
            "confidence": 0.82,
            "severity": "high"
        }
        plan2 = plan_response(outbreak_crisis)
        self.assertEqual(plan2["priority_level"], 4)
        self.assertTrue(any(a["type"] == "public_alert" for a in plan2["actions"]))
        self.assertTrue(any(a["type"] == "resource_allocation" for a in plan2["actions"]))
        self.assertIn("infection", plan2["escalation_threshold"].lower())

    def test_metrics_simulation(self):
        """Test execution simulation resolves routes, tickets, alert counts, and congestion reduction."""
        mock_plan = {
            "response_id": "R-TEST1234",
            "actions": [
                {
                    "action_id": "A-1",
                    "type": "traffic_reroute",
                    "target_location": "Johar Town Lahore",
                    "priority": 2
                },
                {
                    "action_id": "A-2",
                    "type": "emergency_dispatch",
                    "target_location": "Johar Town Lahore",
                    "resources_needed": ["ambulances"],
                    "estimated_time_minutes": 15,
                    "priority": 2
                },
                {
                    "action_id": "A-3",
                    "type": "public_alert",
                    "target_location": "Johar Town Lahore",
                    "priority": 1
                }
            ]
        }
        sim_res = simulate_plan(mock_plan)
        metrics = sim_res["metrics"]
        
        self.assertEqual(metrics["vehicles_rerouted"], 220)
        self.assertEqual(metrics["congestion_before_pct"], 87)
        self.assertEqual(metrics["congestion_after_pct"], 34)  # 87 - 53
        self.assertEqual(metrics["congestion_delta_pct"], 53)
        self.assertEqual(metrics["tickets_created"], 1)
        self.assertEqual(metrics["alerts_sent_count"], 14892)

    def test_end_to_end_orchestrator_workflow(self):
        """Test end-to-end Antigravity Layer run_workflow for a complete pipeline resolution."""
        results = run_workflow("G-10 main barish and pani bhar gaya")
        self.assertEqual(results["status"], "success")
        self.assertIn("signal", results)
        self.assertIn("crisis", results)
        self.assertIn("plan", results)
        self.assertIn("simulation", results)
        
        # Check trace logs got appended
        self.assertTrue(results["crisis"]["crisis_detected"])
        self.assertEqual(results["crisis"]["crisis_type"], "urban_flooding")

if __name__ == "__main__":
    unittest.main()
