\---

description: Build the entire CIRO backend from scratch in sequence

\---



When the user types `/buildciro`, execute these steps in order:



1\. Act as @engineer and use the `build\_agent` skill to build agent\_ingestion.py

2\. Act as @qa and review agent\_ingestion.py for errors

3\. Act as @engineer and use the `build\_agent` skill to build agent\_detection.py

4\. Act as @qa and review agent\_detection.py for errors

5\. Act as @engineer and use the `build\_agent` skill to build agent\_planning.py

6\. Act as @qa and review agent\_planning.py for errors

7\. Act as @engineer and use the `build\_agent` skill to build agent\_simulation.py

8\. Act as @qa and review agent\_simulation.py for errors

9\. Act as @engineer and use the `build\_fastapi` skill to build main.py

10\. Act as @engineer and use the `build\_workflow` skill to build workflow.py

11\. Act as @devops — start the server and confirm all endpoints respond

