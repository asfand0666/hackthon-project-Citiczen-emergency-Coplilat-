\# Skill: Build a CIRO AI Agent



\## Objective

Generate a single self-contained Python file for one CIRO AI agent.



\## Rules

\- File goes in `backend/agents/`

\- Always import: google.generativeai, os, json, re, dotenv

\- Always call load\_dotenv() and genai.configure() at the top

\- The prompt must instruct Gemini to return ONLY valid JSON, no markdown fences

\- Always include an extract\_json(text) helper that strips ```json fences using re.sub

\- Always include an if \_\_name\_\_ == '\_\_main\_\_' block with a realistic Islamabad test input

\- Temperature must be 0.2 (low randomness for consistent JSON output)

\- Never hardcode API keys — always use os.getenv()



\## Output Format

One complete .py file saved to backend/agents/

