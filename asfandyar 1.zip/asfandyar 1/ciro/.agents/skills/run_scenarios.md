\# Skill: Run and Cache All 3 Scenarios



\## Objective

Build run\_workflow.py and execute it for all 3 crisis scenarios to pre-cache results.



\## Rules

\- File goes in `backend/run\_workflow.py`

\- Define a SCENARIOS dict with keys: flood, accident, heatwave

\- Each scenario is a list of 3 raw signal strings (English/Urdu mix)

\- Read scenario name from sys.argv\[1], default to 'flood'

\- Call run\_workflow(SCENARIOS\[scenario])

\- Save result as JSON to scenarios/{scenario}\_result.json

\- Print confirmation with status



\## Flood scenario signals:

&#x20; - "G-10 mein pani bhar gaya hai, gaariyan phans gayi hain"

&#x20; - "Islamabad-West rainfall 85mm RED alert active"

&#x20; - "Traffic G-10/G-11 speed 5kmh congestion 87%"



\## Accident scenario signals:

&#x20; - "Murree Road par badha accident hua hai"

&#x20; - "Traffic Murree Road sudden congestion 12 minutes"

&#x20; - "2 vehicles collision near Faizabad"



\## Heatwave scenario signals:

&#x20; - "Weather alert: temperature 47C Islamabad city"

&#x20; - "G-9 mein bohat garmi hai, heat exhaustion cases"

&#x20; - "Hospital: 3 heatstroke admissions PIMS today"



\## Output

backend/run\_workflow.py

