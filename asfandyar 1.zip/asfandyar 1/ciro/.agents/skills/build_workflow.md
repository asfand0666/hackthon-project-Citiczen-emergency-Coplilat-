\# Skill: Build Antigravity Orchestration Workflow



\## Objective

Build the workflow.py file that chains all 4 agents sequentially and logs every step.



\## Rules

\- File goes in `backend/antigravity\_layer/workflow.py`

\- Also create `backend/antigravity\_layer/\_\_init\_\_.py` (empty)

\- The run\_workflow(raw\_signals: list) function must:

&#x20; 1. Loop through raw\_signals, call process\_signal() on each

&#x20; 2. Call detect\_crisis() on all parsed signals

&#x20; 3. If crisis\_detected is False, return {"status": "MONITORING", "crisis": crisis}

&#x20; 4. Call plan\_response() on the crisis dict

&#x20; 5. Call simulate\_plan() on the plan dict

&#x20; 6. Return {"status": "RESPONDING", "signals": ..., "crisis": ..., "plan": ..., "simulation": ...}

\- Every agent call must be wrapped in \_log() which writes a JSON line to logs/trace.jsonl

\- Each log entry must include: log\_id (L-{uuid}), timestamp, agent name, action name,

&#x20; input\_summary (string), output (dict), duration\_ms, antigravity\_trace\_id (ag-{uuid})

\- Use time.time() before and after each agent call to measure duration\_ms



\## Output

backend/antigravity\_layer/workflow.py and \_\_init\_\_.py

