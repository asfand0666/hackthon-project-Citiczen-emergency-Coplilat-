\# Skill: Build FastAPI Server



\## Objective

Generate the main.py FastAPI server that wires all 4 agents into REST endpoints.



\## Rules

\- File goes in `backend/main.py`

\- Import all 4 agent functions: process\_signal, detect\_crisis, plan\_response, simulate\_plan

\- Use CORSMiddleware with allow\_origins=\["\*"] so the Flutter phone app can call it

\- Use an in-memory signals\_store = \[] list

\- All endpoints must have try/except and raise HTTPException(500, str(e)) on failure

\- The /api/logs endpoint must read from ../../logs/trace.jsonl

\- Include a SignalInput pydantic model with a `text: str` field



\## Endpoints Required

\- GET  /              → {"status": "CIRO backend running"}

\- GET  /api/health    → {gemini\_key\_loaded: bool, maps\_key\_loaded: bool}

\- POST /api/ingest    → body: SignalInput → calls process\_signal, appends to store

\- POST /api/detect    → no body → calls detect\_crisis(signals\_store)

\- POST /api/plan      → body: crisis dict → calls plan\_response

\- POST /api/simulate  → body: plan dict → calls simulate\_plan

\- POST /api/reset     → clears signals\_store

\- GET  /api/logs      → reads trace.jsonl and returns entries



\## Output

One complete main.py saved to backend/

