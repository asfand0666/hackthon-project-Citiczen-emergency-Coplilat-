@echo off
title CIRO Web Tactical Command Center
cd /d "%~dp0ciro_web"
echo Starting CIRO Real-time Web Command Center...
start "" "http://localhost:3000"
node server.js
pause
