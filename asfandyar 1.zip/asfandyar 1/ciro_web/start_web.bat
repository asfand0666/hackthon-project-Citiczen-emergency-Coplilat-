@echo off
title CIRO Web Tactical Command Center
echo ========================================================
echo   CIRO - Crisis Intelligence ^& Response Orchestrator
echo   Real-time Autonomous Multi-Agent Web Dashboard
echo ========================================================
echo.
echo Starting CIRO Web Server on http://localhost:3000 ...
start "" "http://localhost:3000"
node server.js
pause
