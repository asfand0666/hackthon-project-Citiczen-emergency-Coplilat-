// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Centralized Data Contracts & Normalization Layer (types.js)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Normalizes incoming raw backend signal or citizen input into standard Signal format
 */
export function normalizeSignal(raw, index = 0) {
  const now = new Date();
  const timeStr = raw.time || raw.timestamp ? 
    (raw.time || new Date(raw.timestamp).toLocaleTimeString('en-GB', { hour12: false })) :
    now.toLocaleTimeString('en-GB', { hour12: false });

  let type = (raw.signal_type || raw.type || 'other').toLowerCase();
  if (type.includes('fire') || type.includes('aag') || type.includes('smoke')) type = 'fire';
  else if (type.includes('flood') || type.includes('water') || type.includes('rain')) type = 'flood';
  else if (type.includes('accident') || type.includes('crash') || type.includes('collision')) type = 'accident';
  else if (type.includes('medical') || type.includes('injury') || type.includes('heat')) type = 'medical';
  else type = 'other';

  return {
    id: raw.id || `SIG-${1000 + index}`,
    time: timeStr,
    timestamp: raw.timestamp || now.toISOString(),
    location: raw.location || 'Unknown Location',
    coordinates: raw.coordinates ? {
      lat: Array.isArray(raw.coordinates) ? raw.coordinates[0] : (raw.coordinates.lat || 33.6844),
      lng: Array.isArray(raw.coordinates) ? raw.coordinates[1] : (raw.coordinates.lng || 73.0479)
    } : { lat: 33.6844, lng: 73.0479 },
    type: type,
    message: raw.raw_text || raw.message || raw.text || 'Citizen incident report logged.',
    language: raw.language || 'English',
    severity: (raw.severity || raw.severity_hint || 'medium').toLowerCase(),
    confidence: typeof raw.confidence === 'number' ? raw.confidence : 0.85,
    incidentId: raw.incident_id || raw.incidentId || null,
    status: raw.status || 'correlated'
  };
}

/**
 * Normalizes an incident object to ensure consistent UI rendering
 */
export function normalizeIncident(raw, index = 0) {
  const id = raw.id || raw.incident_id || `INC-2026-${String(index + 88).padStart(3, '0')}`;
  let severity = (raw.severity || 'medium').toUpperCase();
  if (!['CRITICAL', 'HIGH', 'MEDIUM', 'MONITOR'].includes(severity)) {
    severity = 'HIGH';
  }

  return {
    id: id,
    type: raw.type || raw.crisis_type || 'General Emergency',
    title: raw.title || raw.type_label || `${raw.type || 'Urban'} Incident at ${raw.location || 'Site'}`,
    location: raw.location || 'Metropolitan Sector',
    coordinates: raw.coordinates || { lat: 33.6844, lng: 73.0479 },
    reportCount: raw.reportCount || raw.reports || (raw.signals ? raw.signals.length : 12),
    severity: severity,
    confidence: typeof raw.confidence === 'number' ? raw.confidence : 0.92,
    peopleAffected: raw.peopleAffected || raw.people_affected || 350,
    priorityScore: raw.priorityScore || raw.priority_score || 85,
    detectedTime: raw.detectedTime || raw.timestamp || 'Just now',
    status: raw.status || 'ACTIVE',
    aiSummary: raw.aiSummary || raw.reasoning || 'Automated multi-signal cross-correlation confirmed emergency parameters.',
    evidence: raw.evidence || raw.supporting_evidence || [
      'Multi-source citizen distress signals verified',
      'Physical sensor anomaly detected in cluster zone',
      'Corroborated by urban traffic velocity drops'
    ],
    priorityFactors: raw.priorityFactors || [
      '+ High life-safety risk',
      '+ Corroborating citizen reports',
      '+ Structural or roadway impact'
    ],
    recommendedResponse: raw.recommendedResponse || ['Immediate Emergency Dispatch', 'Traffic Reroute'],
    relatedSignalIds: raw.relatedSignalIds || []
  };
}

/**
 * Normalizes response plan data
 */
export function normalizeResponsePlan(raw, incident) {
  return {
    id: raw.id || `PLAN-${incident ? incident.id : '001'}`,
    incidentId: incident ? incident.id : (raw.incidentId || 'INC-2026-001'),
    incidentTitle: incident ? incident.title : (raw.incidentTitle || 'Emergency Response'),
    location: incident ? incident.location : (raw.location || 'Active Sector'),
    priority: raw.priority_level || (incident ? incident.severity : 'HIGH'),
    status: raw.status || 'PROPOSED', // PROPOSED, APPROVED, REJECTED
    recommended: raw.recommended || ['Fire Response', 'Medical Triage', 'Traffic Reroute'],
    resources: raw.resources || ['2 Rapid Response Vehicles', '6 Paramedics', 'Police Escort'],
    actions: raw.actions || [],
    reason: raw.reason || (incident ? incident.aiSummary : 'Prevent casualty escalation and clear transit routes.'),
    escalationConditions: raw.escalationConditions || [
      'If congestion index exceeds 85%',
      'If water level rises above curb line',
      'If toxic gas plume enters residential blocks'
    ]
  };
}
