// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Centralized Data Service (Application ➔ DataService ➔ API or Demo)
// ═══════════════════════════════════════════════════════════════════════════════

import { DEMO_INCIDENTS, DEMO_LATEST_SIGNALS, DEMO_ALL_SIGNALS, DEMO_PLANS } from '../data/demoData.js';

class DataService {
  constructor() {
    this.baseUrl = window.__CIRO_CONFIG__?.API_BASE_URL || '';
    this.mode = 'DEMO'; // Default to DEMO to ensure zero broken screens
    this.isBackendOnline = false;
    this.listeners = [];
  }

  onModeChange(callback) {
    this.listeners.push(callback);
  }

  notifyModeChange() {
    this.listeners.forEach(fn => fn({
      mode: this.mode,
      isOnline: this.isBackendOnline
    }));
  }

  setMode(newMode) {
    this.mode = newMode;
    this.notifyModeChange();
  }

  toggleMode() {
    this.mode = this.mode === 'DEMO' ? 'LIVE' : 'DEMO';
    this.notifyModeChange();
    return this.mode;
  }

  /**
   * Silently test if backend is available without user-facing errors
   */
  async checkBackendAvailability() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1800);
      const res = await fetch(`${this.baseUrl}/api/health`, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res && res.ok) {
        this.isBackendOnline = true;
        this.notifyModeChange();
        return true;
      }
    } catch (_) {
      // Silently catch all network/CORS/offline errors
    }
    this.isBackendOnline = false;
    this.mode = 'DEMO'; // Graceful silent fallback
    this.notifyModeChange();
    return false;
  }

  /**
   * Get 3 core top metrics for the minimal dashboard:
   * 1. Active Incidents
   * 2. Critical Incidents
   * 3. Incoming Signals
   */
  async getTopMetrics() {
    const incidents = await this.getIncidents();
    const signals = await this.getAllSignals();
    const criticalCount = incidents.filter(i => i.severity === 'CRITICAL').length;
    
    return {
      activeIncidents: incidents.length,
      criticalIncidents: criticalCount,
      incomingSignals: 98 // Realistic incoming total
    };
  }

  /**
   * Get Incidents list (API if available & LIVE mode, otherwise Demo)
   */
  async getIncidents() {
    if (this.mode === 'LIVE' && this.isBackendOnline) {
      try {
        const res = await fetch(`${this.baseUrl}/api/incidents`, { timeout: 3000 });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.incidents) && data.incidents.length > 0) {
            return data.incidents;
          }
        }
      } catch (_) {
        // Silently fallback to demo data
      }
    }
    return DEMO_INCIDENTS;
  }

  /**
   * Get only Critical incidents for dashboard Left / Large area
   */
  async getCriticalIncidents() {
    const incidents = await this.getIncidents();
    const criticals = incidents.filter(i => i.severity === 'CRITICAL');
    return criticals.length > 0 ? criticals : [incidents[0]];
  }

  /**
   * Get Priority Queue (Top 3 incidents ordered by deterministic priority)
   */
  async getTopPriorityQueue(limit = 3) {
    const incidents = await this.getIncidents();
    return [...incidents].sort((a, b) => b.priorityScore - a.priorityScore).slice(0, limit);
  }

  /**
   * Get Latest 5 signals for dashboard Bottom Live Activity
   */
  async getLatestSignals(limit = 5) {
    return DEMO_LATEST_SIGNALS.slice(0, limit);
  }

  /**
   * Get all signals for Live Signals page
   */
  async getAllSignals() {
    return DEMO_ALL_SIGNALS;
  }

  /**
   * Get response plans for Response Plans page
   */
  async getResponsePlans() {
    return DEMO_PLANS;
  }

  /**
   * Safe UI action: Approve plan
   */
  async approvePlan(planId) {
    const plan = DEMO_PLANS.find(p => p.id === planId);
    if (plan) plan.status = 'APPROVED';
    return { success: true, planId, status: 'APPROVED' };
  }

  /**
   * Safe UI action: Reject plan
   */
  async rejectPlan(planId) {
    const plan = DEMO_PLANS.find(p => p.id === planId);
    if (plan) plan.status = 'REJECTED';
    return { success: true, planId, status: 'REJECTED' };
  }
}

export const dataService = new DataService();
