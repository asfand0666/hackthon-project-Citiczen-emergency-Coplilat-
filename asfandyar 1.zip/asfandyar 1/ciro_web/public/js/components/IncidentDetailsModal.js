// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Incident Details Modal Component (Section 5)
// ═══════════════════════════════════════════════════════════════════════════════

export function openIncidentDetailsModal(incident, relatedSignals = []) {
  let modalEl = document.getElementById('incidentDetailsModal');
  if (!modalEl) {
    modalEl = document.createElement('div');
    modalEl.id = 'incidentDetailsModal';
    modalEl.className = 'modal-backdrop';
    document.body.appendChild(modalEl);
  }

  const signalsHtml = relatedSignals.length > 0 ? relatedSignals.map(s => `
    <div class="modal-signal-card">
      <div class="modal-signal-top">
        <span class="mono text-cyan">${s.id}</span>
        <span class="text-dim">${s.time}</span>
        <span class="badge badge-subtle">${s.language}</span>
      </div>
      <div class="modal-signal-text">"${s.message}"</div>
      <div class="modal-signal-meta text-dim"><i class="fa-solid fa-location-dot"></i> ${s.location}</div>
    </div>
  `).join('') : '<p class="text-dim">No individual raw signals linked.</p>';

  const evidenceHtml = (incident.evidence || []).map(e => `
    <li><i class="fa-solid fa-fingerprint text-amber"></i> ${e}</li>
  `).join('');

  const priorityFactorsHtml = (incident.priorityFactors || []).map(f => `
    <div class="priority-factor-tag">${f}</div>
  `).join('');

  const responseHtml = (incident.recommendedResponse || []).map((r, i) => `
    <div class="rec-action-item">
      <span class="rec-num">${i + 1}</span>
      <span>${r}</span>
    </div>
  `).join('');

  modalEl.innerHTML = `
    <div class="modal-window">
      <div class="modal-header">
        <div class="modal-title-group">
          <span class="badge ${incident.severity === 'CRITICAL' ? 'badge-critical' : 'badge-cyan'}">${incident.severity}</span>
          <span class="mono text-cyan" style="font-weight:700;">${incident.id}</span>
          <h2 class="modal-title">${incident.title}</h2>
        </div>
        <button class="modal-close-btn" onclick="document.getElementById('incidentDetailsModal').classList.remove('active')">&times;</button>
      </div>

      <div class="modal-body">
        <!-- Top Status Bar -->
        <div class="modal-stats-bar">
          <div class="modal-stat">
            <span class="lbl">Location</span>
            <span class="val"><i class="fa-solid fa-location-dot text-red"></i> ${incident.location}</span>
          </div>
          <div class="modal-stat">
            <span class="lbl">Report Corroboration</span>
            <span class="val text-cyan">${incident.reportCount} Verified Reports</span>
          </div>
          <div class="modal-stat">
            <span class="lbl">People Affected</span>
            <span class="val text-amber">${incident.peopleAffected} Civilians</span>
          </div>
          <div class="modal-stat">
            <span class="lbl">Priority Score</span>
            <span class="val text-purple" style="font-size:1.1rem;font-weight:800;">${incident.priorityScore}/100</span>
          </div>
          <div class="modal-stat">
            <span class="lbl">Status</span>
            <span class="val text-emerald">${incident.status}</span>
          </div>
        </div>

        <div class="modal-grid-content">
          <!-- Left Column -->
          <div class="modal-col">
            <div class="modal-section-card">
              <h4 class="modal-sec-title"><i class="fa-solid fa-brain text-purple"></i> AI Situation Summary</h4>
              <p class="modal-prose">${incident.aiSummary}</p>
            </div>

            <div class="modal-section-card">
              <h4 class="modal-sec-title"><i class="fa-solid fa-arrow-trend-up text-amber"></i> Deterministic Priority Factors (Why this is priority)</h4>
              <div class="priority-factors-cloud">
                ${priorityFactorsHtml}
              </div>
            </div>

            <div class="modal-section-card">
              <h4 class="modal-sec-title"><i class="fa-solid fa-file-shield text-cyan"></i> Corroborating Physical Telemetry &amp; Evidence</h4>
              <ul class="modal-evidence-list">
                ${evidenceHtml}
              </ul>
            </div>
          </div>

          <!-- Right Column -->
          <div class="modal-col">
            <div class="modal-section-card">
              <h4 class="modal-sec-title"><i class="fa-solid fa-clipboard-check text-emerald"></i> Recommended Response Plan</h4>
              <div class="rec-actions-list">
                ${responseHtml}
              </div>
            </div>

            <div class="modal-section-card">
              <h4 class="modal-sec-title"><i class="fa-solid fa-tower-cell text-cyan"></i> Incoming Citizen Signals (${relatedSignals.length})</h4>
              <div class="modal-signals-scroll">
                ${signalsHtml}
              </div>
            </div>
          </div>
        </div>

        <!-- Timeline Section -->
        <div class="modal-timeline-box">
          <h4 class="modal-sec-title"><i class="fa-solid fa-timeline text-cyan"></i> Incident Chronology &amp; Escalation Timeline</h4>
          <div class="modal-timeline-steps">
            <div class="timeline-step">
              <div class="tl-point"></div>
              <div class="tl-time">12:12:00 PKT</div>
              <div class="tl-text">Initial citizen signal received via WhatsApp gateway</div>
            </div>
            <div class="timeline-step">
              <div class="tl-point"></div>
              <div class="tl-time">12:14:15 PKT</div>
              <div class="tl-text">Qwen AI correlated 8 reports into single spatial cluster</div>
            </div>
            <div class="timeline-step">
              <div class="tl-point"></div>
              <div class="tl-time">12:16:30 PKT</div>
              <div class="tl-text">Physical telemetry verified; Priority Score escalated to ${incident.priorityScore}</div>
            </div>
            <div class="timeline-step">
              <div class="tl-point current"></div>
              <div class="tl-time">${incident.detectedTime}</div>
              <div class="tl-text">Tactical response plan generated &amp; multi-agency sync notified</div>
            </div>
          </div>
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn-outline" onclick="document.getElementById('incidentDetailsModal').classList.remove('active')">Close</button>
        <button class="btn-primary" onclick="window.CIRO_APP.navigateTo('response_plans'); document.getElementById('incidentDetailsModal').classList.remove('active');">
          <i class="fa-solid fa-file-circle-check"></i> View Action Plan
        </button>
      </div>
    </div>
  `;

  modalEl.classList.add('active');
}
