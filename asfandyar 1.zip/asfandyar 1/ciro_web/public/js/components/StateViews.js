// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Reusable UI State Components (Skeleton, Error, Empty States)
// ═══════════════════════════════════════════════════════════════════════════════

export function renderSkeletonCards(count = 4) {
  let html = '';
  for (let i = 0; i < count; i++) {
    html += `
      <div class="skeleton-card">
        <div class="skeleton-line w-40"></div>
        <div class="skeleton-line w-80"></div>
        <div class="skeleton-line w-60"></div>
      </div>
    `;
  }
  return html;
}

export function renderSkeletonTable(rows = 6) {
  let html = '<div class="skeleton-table">';
  for (let i = 0; i < rows; i++) {
    html += `
      <div class="skeleton-row">
        <div class="skeleton-cell w-15"></div>
        <div class="skeleton-cell w-25"></div>
        <div class="skeleton-cell w-40"></div>
        <div class="skeleton-cell w-20"></div>
      </div>
    `;
  }
  html += '</div>';
  return html;
}

export function renderEmptyState(title = "No Records Found", description = "There are currently no active signals or incidents matching your filter criteria.", icon = "fa-solid fa-folder-open") {
  return `
    <div class="empty-state-card">
      <div class="empty-icon"><i class="${icon}"></i></div>
      <h3 class="empty-title">${title}</h3>
      <p class="empty-desc">${description}</p>
    </div>
  `;
}

export function renderErrorState(message = "Failed to communicate with emergency backend services.", retryCallbackName = "retryOperation") {
  return `
    <div class="error-state-card">
      <div class="error-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
      <h3 class="error-title">Backend Unavailable</h3>
      <p class="error-desc">${message}</p>
      <div class="error-actions">
        <button class="btn-primary" onclick="${retryCallbackName}()">
          <i class="fa-solid fa-rotate"></i> Retry Connection
        </button>
        <button class="btn-outline" onclick="window.CIRO_APP.enableDemoMode()">
          <i class="fa-solid fa-flask"></i> Switch to Live Demo Mode
        </button>
      </div>
    </div>
  `;
}
