// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Tactical Toast Notification Component
// ═══════════════════════════════════════════════════════════════════════════════

export function showToast(message, type = 'info', duration = 3500) {
  let container = document.getElementById('ciroToastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'ciroToastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = 'fa-solid fa-circle-info';
  if (type === 'success') icon = 'fa-solid fa-circle-check';
  else if (type === 'warning') icon = 'fa-solid fa-triangle-exclamation';
  else if (type === 'error') icon = 'fa-solid fa-circle-xmark';

  toast.innerHTML = `
    <i class="${icon}"></i>
    <span class="toast-msg">${message}</span>
    <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-fadeout');
    setTimeout(() => toast.remove(), 400);
  }, duration);
}
