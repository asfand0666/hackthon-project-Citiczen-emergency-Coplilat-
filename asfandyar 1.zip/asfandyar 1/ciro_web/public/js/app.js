// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Citizen Emergency Copilot: Master Operations Controller (app.js)
// Next-Gen Emergency Operations Console • Zero API Dependency
// ═══════════════════════════════════════════════════════════════════════════════

import { dataService } from './services/dataService.js';
import { DEMO_INCIDENTS, DEMO_ALL_SIGNALS, DEMO_PLANS, DEMO_LATEST_SIGNALS } from './data/demoData.js';

class CIROApp {
  constructor() {
    this.activePage = 'dashboard';
    this.incidents = [];
    this.signals = [];
    this.plans = [];
    this.selectedIncidentFilter = 'ALL';
    this.mapInstance = null;
    this.mapMarkers = {};
  }

  async init() {
    this.initClock();
    this.initNavigation();
    this.initModeToggles();
    this.initSignalsSearch();

    // Check backend silently (defaults gracefully to DEMO mode with ZERO user-facing errors)
    await dataService.checkBackendAvailability();

    // Load initial dataset
    await this.loadData();

    // Setup global window reference for inline onclick triggers
    window.CIRO_APP = this;

    // Render initial views
    this.renderMinimalDashboard();
    this.renderIncidentsPage();
    this.renderSignalsPage();
    this.renderPlansPage();
  }

  // ── 1. REAL-TIME CLOCK ──
  initClock() {
    const clockEl = document.getElementById('liveClock');
    const updateTime = () => {
      const now = new Date();
      const options = { timeZone: 'Asia/Karachi', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' };
      if (clockEl) {
        clockEl.textContent = `${now.toLocaleTimeString('en-GB', options)} PKT`;
      }
    };
    updateTime();
    setInterval(updateTime, 1000);
  }

  // ── 2. CLEAN SIDEBAR NAVIGATION ──
  initNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetPage = btn.getAttribute('data-page');
        if (targetPage) {
          this.navigate(targetPage);
        }
      });
    });

    // Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if (menuToggle && sidebar) {
      menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
      });
    }

    // Modal close on backdrop click
    const modalBackdrop = document.getElementById('incidentModal');
    if (modalBackdrop) {
      modalBackdrop.addEventListener('click', (e) => {
        if (e.target === modalBackdrop) {
          modalBackdrop.classList.remove('active');
        }
      });
    }
  }

  navigate(pageId) {
    this.activePage = pageId;

    // Update sidebar buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
      if (btn.getAttribute('data-page') === pageId) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Switch page container
    document.querySelectorAll('.page-view').forEach(view => {
      if (view.id === `page-${pageId}`) {
        view.classList.add('active');
      } else {
        view.classList.remove('active');
      }
    });

    // Close mobile drawer if opened
    const sidebar = document.getElementById('sidebar');
    if (sidebar) sidebar.classList.remove('mobile-open');

    // Page-specific lazy initializations
    if (pageId === 'map') {
      setTimeout(() => this.initMap(), 150);
    }
  }

  // ── 3. MODE TOGGLES (LIVE / DEMO) ──
  initModeToggles() {
    const btnDemo = document.getElementById('btnModeDemo');
    const btnLive = document.getElementById('btnModeLive');

    if (btnDemo && btnLive) {
      btnDemo.addEventListener('click', () => {
        dataService.setMode('DEMO');
        btnDemo.classList.add('active');
        btnLive.classList.remove('active');
        this.loadData();
      });

      btnLive.addEventListener('click', async () => {
        const isOnline = await dataService.checkBackendAvailability();
        if (isOnline) {
          dataService.setMode('LIVE');
          btnLive.classList.add('active');
          btnDemo.classList.remove('active');
        } else {
          // If live backend is unreachable, keep in demo mode silently
          btnDemo.classList.add('active');
          btnLive.classList.remove('active');
        }
        this.loadData();
      });
    }
  }

  // ── 4. DATA FETCH & STATE REFRESH ──
  async loadData() {
    this.incidents = await dataService.getIncidents();
    this.signals = await dataService.getAllSignals();
    this.plans = await dataService.getResponsePlans();

    // Update nav pills
    const navIncidents = document.getElementById('navIncidentsCount');
    if (navIncidents) navIncidents.textContent = this.incidents.length;

    const navSignals = document.getElementById('navSignalsCount');
    if (navSignals) navSignals.textContent = this.signals.length;

    this.renderMinimalDashboard();
  }

  // ── 5. MINIMAL DASHBOARD RENDERING (Strictly Essential Info) ──
  async renderMinimalDashboard() {
    // 1. Top metrics: strictly 3 only
    const metrics = await dataService.getTopMetrics();
    const dashActive = document.getElementById('dashActiveCount');
    const dashCritical = document.getElementById('dashCriticalCount');
    const dashSignals = document.getElementById('dashSignalsCount');

    if (dashActive) dashActive.textContent = metrics.activeIncidents;
    if (dashCritical) dashCritical.textContent = metrics.criticalIncidents;
    if (dashSignals) dashSignals.textContent = metrics.incomingSignals;

    // 2. Left / Large: "Critical Incidents" only
    const criticalContainer = document.getElementById('dashCriticalContainer');
    if (criticalContainer) {
      const criticals = this.incidents.filter(inc => inc.severity === 'CRITICAL');
      const itemsToRender = criticals.length > 0 ? criticals : [this.incidents[0]];

      criticalContainer.innerHTML = itemsToRender.map(inc => `
        <div class="critical-incident-card">
          <div class="card-top-row">
            <span class="priority-tag-pill">
              <i class="fa-solid fa-triangle-exclamation"></i>
              ${inc.severity} SITUATION #${inc.id}
            </span>
            <span class="mono text-muted" style="font-size: 0.74rem;">Detected ${inc.detectedTime}</span>
          </div>

          <div>
            <div class="incident-headline">
              <i class="${inc.icon} text-red"></i>
              ${inc.title.toUpperCase()}
            </div>
            <div class="incident-loc">
              <i class="fa-solid fa-location-dot text-cyan"></i>
              <strong>${inc.location}</strong> Commercial Sector
            </div>
          </div>

          <div class="short-reason-box">
            <i class="fa-solid fa-bell text-red" style="margin-right: 6px;"></i>
            <strong>Threat Factor:</strong> ${inc.shortReason}
          </div>

          <div>
            <div class="card-bottom-row">
              <div class="corroboration-count">
                <i class="fa-solid fa-users text-cyan"></i>
                <span><strong>${inc.corroboratingReports}</strong> corroborating citizen reports</span>
              </div>

              <div style="display: flex; gap: 10px;">
                <button class="action-btn primary" onclick="window.CIRO_APP.openIncidentModal('${inc.id}')">
                  Inspect Situation &rarr;
                </button>
                <button class="action-btn" onclick="window.CIRO_APP.navigate('response_plans')">
                  Response Plan
                </button>
              </div>
            </div>

            <!-- Corroboration Visual Meter -->
            <div style="margin-top: 10px; width: 100%; background: rgba(255,255,255,0.06); height: 4px; border-radius: 2px; overflow: hidden;">
              <div style="width: 86%; height: 100%; background: linear-gradient(90deg, #f43f5e 0%, #fb7185 100%); box-shadow: 0 0 10px #f43f5e;"></div>
            </div>
          </div>
        </div>
      `).join('');
    }

    // 3. Right / Small: "Priority Queue" (Top 3 incidents only)
    const pqContainer = document.getElementById('dashPriorityQueue');
    if (pqContainer) {
      const top3 = [...this.incidents].sort((a, b) => b.priorityScore - a.priorityScore).slice(0, 3);

      pqContainer.innerHTML = top3.map((inc, idx) => {
        const sevClass = inc.severity === 'CRITICAL' ? 'critical' : (inc.severity === 'HIGH' ? 'high' : 'medium');
        return `
          <div class="pq-row" style="cursor: pointer;" onclick="window.CIRO_APP.openIncidentModal('${inc.id}')">
            <div class="pq-cell-left">
              <span style="font-family: var(--font-mono); font-size: 0.72rem; font-weight: 800; color: var(--text-muted); width: 20px;">#${idx + 1}</span>
              <span class="pq-priority-tag ${sevClass}">${inc.priority}</span>
              <div>
                <div class="pq-name">${inc.type}</div>
                <div class="pq-loc">${inc.location}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <div class="mono" style="font-size: 0.8rem; font-weight: 700; color: #fff;">${inc.priorityScore}<span class="text-muted" style="font-size: 0.68rem;">/100</span></div>
              <div class="mono text-muted" style="font-size: 0.7rem;">${inc.corroboratingReports} reports</div>
            </div>
          </div>
        `;
      }).join('');
    }

    // 4. Bottom: "Live Activity" (Latest 5 signals only)
    const activityContainer = document.getElementById('dashActivityFeed');
    if (activityContainer) {
      const latest5 = DEMO_LATEST_SIGNALS.slice(0, 5);
      activityContainer.innerHTML = latest5.map(sig => {
        let tagColor = 'color: var(--text-secondary); background: rgba(255,255,255,0.06);';
        if (sig.type === 'fire') tagColor = 'color: var(--red); background: rgba(244,63,94,0.15); border: 1px solid rgba(244,63,94,0.3);';
        else if (sig.type === 'accident') tagColor = 'color: var(--orange); background: rgba(249,115,22,0.15); border: 1px solid rgba(249,115,22,0.3);';
        else if (sig.type === 'flood') tagColor = 'color: var(--blue-light); background: rgba(14,165,233,0.15); border: 1px solid rgba(14,165,233,0.3);';
        else if (sig.type === 'medical') tagColor = 'color: var(--yellow); background: rgba(234,179,8,0.15); border: 1px solid rgba(234,179,8,0.3);';

        return `
          <div class="activity-item">
            <div class="activity-time mono">${sig.time}</div>
            <div class="activity-loc">${sig.location}</div>
            <div class="activity-type-pill" style="${tagColor}">${sig.type.toUpperCase()}</div>
            <div class="activity-msg">"${sig.message}"</div>
            <div class="mono text-muted" style="font-size: 0.72rem; flex-shrink: 0;">${Math.round(sig.confidence * 100)}% conf</div>
          </div>
        `;
      }).join('');
    }
  }

  // ── 6. INCIDENTS PAGE (Full Details View) ──
  renderIncidentsPage() {
    const container = document.getElementById('allIncidentsContainer');
    if (!container) return;

    let filtered = this.incidents;
    if (this.selectedIncidentFilter !== 'ALL') {
      filtered = this.incidents.filter(i => i.severity === this.selectedIncidentFilter);
    }

    container.innerHTML = filtered.map(inc => {
      const sevClass = inc.severity === 'CRITICAL' ? 'critical' : (inc.severity === 'HIGH' ? 'high' : 'medium');
      return `
        <div class="incident-full-card ${sevClass}" onclick="window.CIRO_APP.openIncidentModal('${inc.id}')">
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
              <span class="pq-priority-tag ${sevClass}">${inc.severity}</span>
              <div class="if-title">${inc.title}</div>
            </div>
            <div class="if-sub">${inc.location} • ${inc.shortReason}</div>
          </div>

          <div class="if-stats">
            <span><strong style="color: #fff;">${inc.corroboratingReports}</strong> reports</span>
            <span><strong style="color: #fff;">${inc.peopleAffected}</strong> affected</span>
            <button class="action-btn primary" onclick="event.stopPropagation(); window.CIRO_APP.openIncidentModal('${inc.id}')">
              View Incident &rarr;
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  filterIncidentsList(filter) {
    this.selectedIncidentFilter = filter;
    document.querySelectorAll('.filter-chip').forEach(chip => {
      if (chip.textContent.trim().toUpperCase() === filter) {
        chip.classList.add('active');
      } else {
        chip.classList.remove('active');
      }
    });
    this.renderIncidentsPage();
  }

  // ── 7. LIVE SIGNALS PAGE ──
  renderSignalsPage(query = '') {
    const tbody = document.getElementById('signalsTableBody');
    if (!tbody) return;

    let items = this.signals;
    if (query.trim()) {
      const q = query.toLowerCase();
      items = items.filter(s =>
        s.message.toLowerCase().includes(q) ||
        s.location.toLowerCase().includes(q) ||
        s.type.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q)
      );
    }

    tbody.innerHTML = items.map(sig => {
      const badgeColor = sig.severity === 'critical' ? 'text-red' : (sig.severity === 'high' ? 'text-orange' : 'text-amber');
      return `
        <tr>
          <td class="mono">${sig.time}</td>
          <td class="mono text-muted">${sig.id}</td>
          <td><strong>${sig.location}</strong></td>
          <td><span class="activity-type-pill">${sig.type.toUpperCase()}</span></td>
          <td>${sig.message}</td>
          <td class="mono ${badgeColor}"><strong>${sig.severity.toUpperCase()}</strong> (${Math.round(sig.confidence * 100)}%)</td>
          <td class="mono">
            <a href="javascript:void(0)" onclick="window.CIRO_APP.openIncidentModal('${sig.incidentId}')" style="color: var(--blue-light); text-decoration: none; font-weight: 600;">
              ${sig.incidentId}
            </a>
          </td>
        </tr>
      `;
    }).join('');
  }

  initSignalsSearch() {
    const searchInput = document.getElementById('signalsSearch');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.renderSignalsPage(e.target.value);
      });
    }
  }

  // ── 8. RESPONSE PLANS PAGE ──
  renderPlansPage() {
    const container = document.getElementById('plansContainer');
    if (!container) return;

    container.innerHTML = this.plans.map(plan => {
      const sevClass = plan.priority === 'CRITICAL' ? 'critical' : 'high';
      const escalationText = Array.isArray(plan.escalationConditions) ? plan.escalationConditions.join(' • ') : (plan.escalationCondition || 'Operator discretion');
      return `
        <div class="plan-card" id="card-${plan.id}">
          <div class="plan-header">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span class="pq-priority-tag ${sevClass}">${plan.priority}</span>
              <div>
                <h3 class="if-title">${plan.incidentTitle || plan.title}</h3>
                <div class="text-muted mono" style="font-size: 0.72rem;">Incident: ${plan.incidentId} • Location: ${plan.location}</div>
              </div>
            </div>
            <div>
              <span class="priority-tag-pill" id="status-${plan.id}" style="${plan.status === 'APPROVED' ? 'color: var(--emerald); border-color: var(--emerald); background: rgba(16,185,129,0.15);' : ''}">${plan.status}</span>
            </div>
          </div>

          <div class="plan-actions-list">
            ${(plan.actions || []).map(a => `
              <div class="plan-action-item">
                <div>
                  <strong style="color: #fff;">${a.title}</strong>
                  <div style="font-size: 0.76rem; color: var(--text-muted); margin-top: 3px;">
                    ${a.description} • <em>${a.resources}</em>
                  </div>
                </div>
                <span class="mono text-cyan" style="font-size: 0.76rem; flex-shrink: 0; padding-left: 12px; font-weight: 700;">ETA: ${a.eta}</span>
              </div>
            `).join('')}
          </div>

          <div class="short-reason-box" style="font-size: 0.78rem; border-left-color: var(--yellow);">
            <strong>Escalation / Trigger Conditions:</strong> ${escalationText}
          </div>

          <div class="plan-footer">
            <div style="display: flex; gap: 10px;">
              <button class="action-btn primary" onclick="window.CIRO_APP.approvePlan('${plan.id}')">
                <i class="fa-solid fa-check"></i> Authorize Plan
              </button>
              <button class="action-btn" onclick="window.CIRO_APP.rejectPlan('${plan.id}')">
                <i class="fa-solid fa-xmark"></i> Reject
              </button>
            </div>
            <button class="action-btn" onclick="window.CIRO_APP.openIncidentModal('${plan.incidentId}')">
              Inspect Incident &rarr;
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  approvePlan(planId) {
    dataService.approvePlan(planId);
    const chip = document.getElementById(`status-${planId}`);
    if (chip) {
      chip.textContent = 'APPROVED';
      chip.style.color = 'var(--emerald)';
      chip.style.borderColor = 'var(--emerald)';
      chip.style.background = 'rgba(16,185,129,0.15)';
    }
  }

  rejectPlan(planId) {
    dataService.rejectPlan(planId);
    const chip = document.getElementById(`status-${planId}`);
    if (chip) {
      chip.textContent = 'REJECTED';
      chip.style.color = 'var(--red)';
      chip.style.borderColor = 'var(--red)';
      chip.style.background = 'rgba(244,63,94,0.15)';
    }
  }

  // ── 9. INCIDENT DETAIL MODAL ──
  openIncidentModal(incidentId) {
    const inc = this.incidents.find(i => i.id === incidentId) || DEMO_INCIDENTS.find(i => i.id === incidentId);
    if (!inc) return;

    const modal = document.getElementById('incidentModal');
    if (!modal) return;

    // Header & Meta
    document.getElementById('modalSeverityPill').textContent = inc.severity;
    document.getElementById('modalTitle').textContent = inc.title;
    document.getElementById('modalLocation').textContent = inc.location;
    document.getElementById('modalReports').textContent = `${inc.corroboratingReports} Reports`;
    document.getElementById('modalAffected').textContent = `${inc.peopleAffected} Civilians`;
    document.getElementById('modalTime').textContent = inc.detectedTime;
    document.getElementById('modalStatus').textContent = inc.status;

    // AI Summary
    document.getElementById('modalAiSummary').textContent = inc.aiSummary;

    // Corroborating Evidence
    const evidenceList = document.getElementById('modalEvidenceList');
    if (evidenceList) {
      evidenceList.innerHTML = (inc.evidence || []).map(e => `<li>${e}</li>`).join('');
    }

    // Priority Factors
    const factorsList = document.getElementById('modalPriorityFactors');
    if (factorsList) {
      factorsList.innerHTML = (inc.priorityFactors || []).map(f => `<div class="priority-tag-item">+ ${f}</div>`).join('');
    }

    // Recommended Response
    const responseList = document.getElementById('modalResponseList');
    if (responseList) {
      responseList.innerHTML = (inc.recommendedResponse || []).map(r => `
        <div class="modal-action-row">
          <i class="fa-solid fa-arrow-right"></i> ${r}
        </div>
      `).join('');
    }

    modal.classList.add('active');
  }

  // ── 10. LEAFLET MAP INITIALIZATION (Zero API Key, High-Tech Dark Operations Cartography) ──
  initMap() {
    const mapEl = document.getElementById('operationsMap');
    if (!mapEl || typeof L === 'undefined') return;

    if (this.mapInstance) {
      this.mapInstance.invalidateSize();
      return;
    }

    // Center on city emergency sectors (Islamabad Metropolitan Grid)
    this.mapInstance = L.map('operationsMap', {
      zoomControl: true,
      attributionControl: false
    }).setView([33.6950, 73.0550], 12);

    // 100% Free, NO API Key Required, Clean Dark Tactical Base
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 18,
      subdomains: ['server', 'services']
    }).addTo(this.mapInstance);

    // Matching Dark Reference Labels Layer
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 18,
      subdomains: ['server', 'services']
    }).addTo(this.mapInstance);

    // Add Incident Markers with Glowing Tactical Indicators
    this.incidents.forEach(inc => {
      if (!inc.coordinates) return;

      const isCritical = inc.severity === 'CRITICAL';
      const markerColor = isCritical ? '#f43f5e' : (inc.severity === 'HIGH' ? '#f97316' : '#eab308');

      // Custom icon with animated radar pulse ring for Critical incidents
      const iconHtml = isCritical ? `
        <div class="radar-pulse-pin">
          <div style="background-color: ${markerColor}; width: 16px; height: 16px; border-radius: 50%; border: 2px solid #ffffff; box-shadow: 0 0 16px ${markerColor}; position: relative; z-index: 2;"></div>
        </div>
      ` : `
        <div style="background-color: ${markerColor}; width: 14px; height: 14px; border-radius: 50%; border: 2px solid #ffffff; box-shadow: 0 0 12px ${markerColor};"></div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-map-pin',
        html: iconHtml,
        iconSize: isCritical ? [36, 36] : [16, 16],
        iconAnchor: isCritical ? [18, 18] : [8, 8]
      });

      const marker = L.marker([inc.coordinates.lat, inc.coordinates.lng], { icon: customIcon }).addTo(this.mapInstance);

      marker.bindPopup(`
        <div style="color: #f8fafc; padding: 4px; min-width: 200px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
            <span style="font-size: 11px; font-weight: 800; color: ${markerColor}; font-family: monospace;">${inc.severity}</span>
            <span style="font-size: 10px; color: #94a3b8; font-family: monospace;">${inc.detectedTime}</span>
          </div>
          <h4 style="margin: 0 0 4px 0; font-size: 13px; color: #ffffff; font-weight: 700;">${inc.title}</h4>
          <p style="margin: 0 0 10px 0; font-size: 11px; color: #cbd5e1; line-height: 1.4;">${inc.shortReason}</p>
          <div style="font-size: 11px; color: #38bdf8; margin-bottom: 8px;"><strong>${inc.corroboratingReports}</strong> corroborating reports</div>
          <button style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #ffffff; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: 600; width: 100%;" onclick="window.CIRO_APP.openIncidentModal('${inc.id}')">
            Inspect Situation Details &rarr;
          </button>
        </div>
      `);

      this.mapMarkers[inc.id] = marker;
    });
  }

  zoomMapTo(target) {
    if (!this.mapInstance) return;

    // Update active state on map quick buttons
    document.querySelectorAll('.map-action-btn').forEach(btn => btn.classList.remove('active'));
    if (event && event.target) event.target.classList.add('active');

    if (target === 'all') {
      const group = L.featureGroup(Object.values(this.mapMarkers));
      if (group.getLayers().length > 0) {
        this.mapInstance.fitBounds(group.getBounds().pad(0.25));
      }
    } else {
      const inc = this.incidents.find(i => i.id === target);
      if (inc && inc.coordinates) {
        this.mapInstance.flyTo([inc.coordinates.lat, inc.coordinates.lng], 14, { duration: 1 });
        const marker = this.mapMarkers[target];
        if (marker) {
          setTimeout(() => marker.openPopup(), 1050);
        }
      }
    }
  }

  // ── 11. SETTINGS HANDLERS ──
  saveSettings() {
    const input = document.getElementById('backendUrlInput');
    if (input) {
      dataService.baseUrl = input.value.trim();
      alert('Configuration saved. CIRO will attempt connections to this endpoint when LIVE mode is toggled.');
    }
  }

  async testConnection() {
    const isOnline = await dataService.checkBackendAvailability();
    if (isOnline) {
      alert('Backend connection successful! Open-weight local inference endpoint is reachable.');
    } else {
      alert('Backend is currently offline or unreachable. CIRO will continue running smoothly in Demo Mode.');
    }
  }
}

// Instantiate and start when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const app = new CIROApp();
  app.init();
});
