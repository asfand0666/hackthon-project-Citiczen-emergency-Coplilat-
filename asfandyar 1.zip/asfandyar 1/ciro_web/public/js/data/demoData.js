// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Citizen Emergency Copilot: Realistic Emergency Operations Dataset
// ═══════════════════════════════════════════════════════════════════════════════

export const DEMO_INCIDENTS = [
  {
    id: "INC-101",
    type: "Market Fire",
    icon: "fa-solid fa-fire",
    title: "Market Fire — Main Market",
    location: "Main Market",
    severity: "CRITICAL", // RED
    priority: "CRITICAL",
    priorityScore: 96,
    shortReason: "Possible people trapped",
    corroboratingReports: 43,
    peopleAffected: 120,
    detectedTime: "12:40 PKT",
    status: "DISPATCHED",
    coordinates: { lat: 33.7294, lng: 73.0551 },
    aiSummary: "Multi-point commercial blaze in 3-story retail complex. Smoke plume extending across central plaza with civilian evacuation underway.",
    evidence: [
      "43 citizen reports logged within 6 minutes",
      "Thermal sensor threshold breached on central retail corridor",
      "Station 3 alarm elevated to 4-tender response"
    ],
    priorityFactors: [
      "High life-safety risk (civilian occupancy)",
      "43 corroborating citizen reports",
      "Combustible inventory in surrounding retail stalls"
    ],
    recommendedResponse: [
      "Deploy 4 fire tenders with high-pressure foam units",
      "Stage 2 ALS ambulances at West Gate",
      "Close Market Road for emergency access corridor"
    ]
  },
  {
    id: "INC-102",
    type: "Highway Accident",
    icon: "fa-solid fa-car-burst",
    title: "Highway Accident — Sector 12",
    location: "Sector 12",
    severity: "HIGH", // ORANGE
    priority: "HIGH",
    priorityScore: 88,
    shortReason: "Road access blocked, fuel leak",
    corroboratingReports: 25,
    peopleAffected: 45,
    detectedTime: "12:35 PKT",
    status: "DISPATCHED",
    coordinates: { lat: 33.6650, lng: 73.0820 },
    aiSummary: "Tanker collision with multiple passenger vehicles blocking 2 arterial lanes. Low hydrocarbon leak detected near median barrier.",
    evidence: [
      "25 citizen reports confirming vehicular standstill",
      "Speed sensor indicates 0 km/h gridlock spanning 1.8km",
      "Foam unit requested to prevent fuel vapor ignition"
    ],
    priorityFactors: [
      "Hydrocarbon fuel leak containment required",
      "25 corroborating commuter reports",
      "Arterial highway blockage delaying emergency units"
    ],
    recommendedResponse: [
      "Dispatch chemical foam tender for vapor suppression",
      "Deploy 2 trauma ambulances via service lane",
      "Divert traffic via Sector 11 expressway"
    ]
  },
  {
    id: "INC-103",
    type: "Urban Flooding",
    icon: "fa-solid fa-water",
    title: "Urban Flooding — G-10",
    location: "Sector G-10",
    severity: "HIGH", // ORANGE
    priority: "HIGH",
    priorityScore: 84,
    shortReason: "Water depth 3ft, ground floor ingress",
    corroboratingReports: 20,
    peopleAffected: 210,
    detectedTime: "12:28 PKT",
    status: "ACTIVE",
    coordinates: { lat: 33.6844, lng: 73.0479 },
    aiSummary: "Flash water accumulation following storm drain blockage. Multiple vehicles stalled and surface water entering commercial basements.",
    evidence: [
      "20 citizen distress reports with photo uploads",
      "Meteorological radar confirms 52mm rainfall in catchment",
      "Drainage pumping station operating at maximum load"
    ],
    priorityFactors: [
      "Water depth exceeding 3 feet on primary roadway",
      "20 corroborating reports in 400m radius",
      "Risk of electrical conduit submersion"
    ],
    recommendedResponse: [
      "Dispatch 2 high-capacity suction dewatering pumps",
      "Stage Rescue 1122 inflatable boat team",
      "Issue localized SMS advisory for ground floor evacuation"
    ]
  },
  {
    id: "INC-104",
    type: "Power Outage",
    icon: "fa-solid fa-bolt",
    title: "Power Outage — Sector 4",
    location: "Sector 4",
    severity: "MEDIUM", // YELLOW
    priority: "MEDIUM",
    priorityScore: 62,
    shortReason: "Transformer failure, traffic signals offline",
    corroboratingReports: 10,
    peopleAffected: 450,
    detectedTime: "12:15 PKT",
    status: "INVESTIGATING",
    coordinates: { lat: 33.6700, lng: 73.0300 },
    aiSummary: "Sub-station feeder trip causing blackout across 4 commercial blocks and 3 major signalized intersections.",
    evidence: [
      "10 citizen power outage tickets logged",
      "Grid telemetry alert code 402 received",
      "Traffic wardens dispatched to manual intersection control"
    ],
    priorityFactors: [
      "Traffic signal outage causing junction congestion",
      "10 corroborating commercial sector reports",
      "No structural or life-safety hazard identified"
    ],
    recommendedResponse: [
      "Deploy municipal utility repair crew to Sub-station 4",
      "Assign 4 traffic wardens to manual intersection control"
    ]
  }
];

// Latest 5 signals for dashboard bottom live activity
export const DEMO_LATEST_SIGNALS = [
  {
    id: "SIG-801",
    time: "12:44:10",
    location: "Main Market",
    type: "fire",
    message: "Black smoke coming from cloth market second floor, people shouting.",
    severity: "critical",
    confidence: 0.95,
    incidentId: "INC-101"
  },
  {
    id: "SIG-802",
    time: "12:43:25",
    location: "Sector 12",
    type: "accident",
    message: "Tanker collision near highway ramp, traffic at full stop.",
    severity: "high",
    confidence: 0.92,
    incidentId: "INC-102"
  },
  {
    id: "SIG-803",
    time: "12:41:50",
    location: "Sector G-10",
    type: "flood",
    message: "Water level reached car doors near Markaz roundabout.",
    severity: "high",
    confidence: 0.89,
    incidentId: "INC-103"
  },
  {
    id: "SIG-804",
    time: "12:39:15",
    location: "Sector 4",
    type: "medical",
    message: "Sub-station transformer tripped, 4 blocks without power, traffic signals dark.",
    severity: "medium",
    confidence: 0.82,
    incidentId: "INC-104"
  },
  {
    id: "SIG-805",
    time: "12:38:00",
    location: "Main Market",
    type: "fire",
    message: "Fire brigade sirens heard approaching Main Market west entrance.",
    severity: "critical",
    confidence: 0.94,
    incidentId: "INC-101"
  }
];

// Full signals list for Live Signals page
export const DEMO_ALL_SIGNALS = [
  ...DEMO_LATEST_SIGNALS,
  {
    id: "SIG-806",
    time: "12:36:12",
    location: "Main Market",
    type: "fire",
    message: "Flames visible through broken glass on 2nd floor, send ladder!",
    severity: "critical",
    confidence: 0.96,
    incidentId: "INC-101"
  },
  {
    id: "SIG-807",
    time: "12:35:40",
    location: "Sector 12",
    type: "accident",
    message: "Fuel is leaking onto asphalt, please divert vehicles away.",
    severity: "high",
    confidence: 0.90,
    incidentId: "INC-102"
  },
  {
    id: "SIG-808",
    time: "12:34:00",
    location: "Sector G-10",
    type: "flood",
    message: "Drainage culvert overflowing on Double Road.",
    severity: "high",
    confidence: 0.88,
    incidentId: "INC-103"
  },
  {
    id: "SIG-809",
    time: "12:31:20",
    location: "Sector 4",
    type: "medical",
    message: "Elevator stalled in commercial tower due to power cut, technicians on scene.",
    severity: "medium",
    confidence: 0.79,
    incidentId: "INC-104"
  },
  {
    id: "SIG-810",
    time: "12:28:45",
    location: "Main Market",
    type: "fire",
    message: "Police arrived, clearing people away from the building front.",
    severity: "critical",
    confidence: 0.93,
    incidentId: "INC-101"
  },
  {
    id: "SIG-811",
    time: "12:25:10",
    location: "Sector 12",
    type: "accident",
    message: "Two cars damaged, passengers receiving first aid on roadside.",
    severity: "high",
    confidence: 0.87,
    incidentId: "INC-102"
  },
  {
    id: "SIG-812",
    time: "12:20:00",
    location: "Sector G-10",
    type: "flood",
    message: "Basement parking in plaza has 2 feet water, pumps running.",
    severity: "high",
    confidence: 0.85,
    incidentId: "INC-103"
  }
];

// Response plans
export const DEMO_PLANS = [
  {
    id: "PLAN-101",
    incidentId: "INC-101",
    incidentTitle: "Market Fire — Main Market",
    location: "Main Market",
    priority: "CRITICAL",
    status: "PROPOSED",
    recommended: ["Fire Response", "Medical Standby", "Road Control"],
    actions: [
      { id: "A1", type: "fire", title: "4 Fire Tenders & Aerial Snorkel", description: "Deploy from Station 3 and Central Station with aqueous foam.", eta: "4 min", resources: "4 Tenders, 16 Firefighters" },
      { id: "A2", type: "medical", title: "2 ALS Trauma Ambulances", description: "Stage at West Gate plaza for burn and smoke inhalation triage.", eta: "6 min", resources: "2 Ambulances, 4 Paramedics" },
      { id: "A3", type: "traffic", title: "Market Road Closure & Perimeter", description: "Seal 400m perimeter to allow unimpeded tender access.", eta: "2 min", resources: "Traffic Police Unit 4" }
    ],
    reason: "Prevent structural collapse and extract possible trapped personnel.",
    escalationConditions: ["If fire spreads to adjacent wholesale depot", "If structural integrity is breached"]
  },
  {
    id: "PLAN-102",
    incidentId: "INC-102",
    incidentTitle: "Highway Accident — Sector 12",
    location: "Sector 12",
    priority: "HIGH",
    status: "APPROVED",
    recommended: ["Vapor Suppression", "Paramedic Dispatch", "Expressway Diversion"],
    actions: [
      { id: "A1", type: "fire", title: "Chemical Foam Vapor Blanketing", description: "Suppress hydrocarbon vapor from punctured tanker tank.", eta: "5 min", resources: "1 Foam Tender" },
      { id: "A2", type: "medical", title: "Ambulance Patient Transport", description: "Transport 3 injured passengers via clear shoulder lane.", eta: "5 min", resources: "2 Ambulances" },
      { id: "A3", type: "traffic", title: "Sector 11 Expressway Diversion", description: "Divert all southbound traffic away from collision site.", eta: "3 min", resources: "Highway Wardens" }
    ],
    reason: "Eliminate fuel vapor explosion hazard and restore emergency access.",
    escalationConditions: ["If fuel reaches municipal storm drain conduit"]
  },
  {
    id: "PLAN-103",
    incidentId: "INC-103",
    incidentTitle: "Urban Flooding — G-10",
    location: "Sector G-10",
    priority: "HIGH",
    status: "PROPOSED",
    recommended: ["Dewatering Pumps", "Rescue Boats", "Traffic Diversion"],
    actions: [
      { id: "A1", type: "flood", title: "High-Capacity Dewatering Pumps", description: "Deploy 2 suction pump rigs to clear primary runoff basin.", eta: "8 min", resources: "2 Pump Rigs, Municipal Crew" },
      { id: "A2", type: "traffic", title: "Kashmir Highway Ramp Diversion", description: "Reroute traffic toward G-11 expressway to prevent vehicle stalling.", eta: "4 min", resources: "Traffic Control" }
    ],
    reason: "Prevent electrical short-circuits and clear transit artery.",
    escalationConditions: ["If rainfall resumes above 20mm/hr"]
  }
];
