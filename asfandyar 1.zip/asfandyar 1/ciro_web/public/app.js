// ═══════════════════════════════════════════════════════════════════════════════
// CIRO — Tactical Web Command Center (100% Real-Time Live Data Engine)
// ═══════════════════════════════════════════════════════════════════════════════

let map;
let markerLayerGroup;
let corridorLayerGroup;
let hazardCircle;
let isRunningPipeline = false;
let droneInterval = null;
let isDroneActive = false;
let audioCtx = null;

// Sound Effects via Web Audio API
function playBeep(freq = 880, duration = 0.08, type = 'sine') {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {}
}

function playSuccessChime() {
  playBeep(523.25, 0.1);
  setTimeout(() => playBeep(659.25, 0.1), 100);
  setTimeout(() => playBeep(783.99, 0.2), 200);
}

function playAlertAlarm() {
  playBeep(440, 0.12, 'sawtooth');
  setTimeout(() => playBeep(330, 0.15, 'sawtooth'), 120);
}

// ─── 1. INITIALIZE ON DOM LOAD ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initLiveClock();
  initTacticalMap();
  bindUIEvents();
  // Automatically run live analysis on initial load for G-10 Islamabad
  runLiveAnalysis("Islamabad G-10", "Flash flooding on main thoroughfare, road submerged.");
});

// ─── 2. LIVE REAL-TIME CLOCK ─────────────────────────────────────────────────
function initLiveClock() {
  const clockEl = document.getElementById('liveClock');
  function update() {
    const now = new Date();
    const options = { timeZone: 'Asia/Karachi', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' };
    clockEl.textContent = `${now.toLocaleTimeString('en-GB', options)} PKT`;
  }
  update();
  setInterval(update, 1000);
}

// ─── 3. TACTICAL LEAFLET MAP ──────────────────────────────────────────────────
function initTacticalMap() {
  map = L.map('tacticalMap', {
    zoomControl: false,
    attributionControl: false
  }).setView([33.6844, 73.0479], 14);

  L.control.zoom({ position: 'bottomright' }).addTo(map);

  // High-performance Dark Matter tiles from CartoDB / OpenStreetMap
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 19,
    subdomains: 'abcd'
  }).addTo(map);

  markerLayerGroup = L.layerGroup().addTo(map);
  corridorLayerGroup = L.layerGroup().addTo(map);
}

function createTacticalIcon(type, iconClass) {
  let color = '#06b6d4';
  let pulse = false;

  if (type === 'crisis' || type === 'urban_flooding' || type === 'fire_emergency' || type === 'road_accident') {
    color = '#ef4444';
    pulse = true;
  } else if (type === 'rescue') {
    color = '#06b6d4';
  } else if (type === 'relief') {
    color = '#10b981';
  } else if (type === 'check') {
    color = '#10b981';
  }

  const html = `
    <div style="
      width: 36px; height: 36px; border-radius: 50%;
      background: rgba(11, 17, 32, 0.95);
      border: 2px solid ${color};
      box-shadow: 0 0 12px ${color};
      display: flex; align-items: center; justify-content: center;
      color: ${color}; font-size: 14px;
      position: relative;
    ">
      ${pulse ? `<div style="
        position: absolute; inset: -6px; border-radius: 50%;
        border: 2px solid ${color}; animation: pulse 1.5s infinite; opacity: 0.8;
      "></div>` : ''}
      <i class="${iconClass}"></i>
    </div>
  `;

  return L.divIcon({
    className: 'custom-tactical-marker',
    html: html,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18]
  });
}

function renderMapElements(data) {
  markerLayerGroup.clearLayers();
  corridorLayerGroup.clearLayers();
  if (hazardCircle) {
    map.removeLayer(hazardCircle);
    hazardCircle = null;
  }

  const lat = data.crisis.coordinates.lat;
  const lng = data.crisis.coordinates.lng;

  // Fly to exact OpenStreetMap coordinates
  map.flyTo([lat, lng], 14, { duration: 1.5 });

  // Add Hazard Radius
  if (data.crisis.crisis_detected) {
    hazardCircle = L.circle([lat, lng], {
      color: '#ef4444',
      fillColor: '#ef4444',
      fillOpacity: 0.12,
      radius: 800,
      weight: 1,
      dashArray: '4, 8'
    }).addTo(map);
  }

  // Render Markers
  if (data.simulation && data.simulation.markers) {
    data.simulation.markers.forEach(m => {
      let icon = 'fa-solid fa-location-dot';
      if (m.icon === 'ambulance') icon = 'fa-solid fa-truck-medical';
      else if (m.type === 'check') icon = 'fa-solid fa-circle-check';
      else icon = 'fa-solid fa-triangle-exclamation';

      const customIcon = createTacticalIcon(m.type, icon);
      const marker = L.marker([m.lat, m.lng], { icon: customIcon });
      
      marker.bindPopup(`
        <div style="font-family: 'Inter', sans-serif; font-size: 12px; color: #1e293b; padding: 2px;">
          <strong style="color: #0f172a; font-size: 13px;">${m.label}</strong><br>
          <span style="color: #64748b; font-family: monospace;">GPS: ${m.lat.toFixed(5)}, ${m.lng.toFixed(5)}</span>
        </div>
      `);
      markerLayerGroup.addLayer(marker);
    });
  }

  // Render Real OSRM Road Corridor
  if (data.simulation && data.simulation.corridors) {
    data.simulation.corridors.forEach(c => {
      const poly = L.polyline(c.points, {
        color: c.color,
        weight: 5,
        opacity: 0.9
      });
      poly.bindPopup(`<strong>${c.label}</strong>`);
      corridorLayerGroup.addLayer(poly);
    });
  }
}

// ─── 4. RUN 100% REAL-TIME LIVE ANALYSIS ──────────────────────────────────────
async function runLiveAnalysis(locationOverride, signalOverride) {
  if (isRunningPipeline) return;
  isRunningPipeline = true;
  playAlertAlarm();

  const locationQuery = locationOverride || document.getElementById('targetLocationInput').value.trim();
  const signalText = signalOverride || document.getElementById('signalInputText').value.trim() || `Emergency situation at ${locationQuery}`;
  
  if (locationOverride) document.getElementById('targetLocationInput').value = locationOverride;
  if (signalOverride) document.getElementById('signalInputText').value = signalOverride;

  const btn = document.getElementById('btnRunPipeline');
  btn.disabled = true;
  btn.innerHTML = `<i class="fa-solid fa-satellite-dish fa-spin"></i> <span>Querying Live APIs...</span>`;

  // Animate 7-Step Multi-Agent Pipeline
  const steps = document.querySelectorAll('.pipeline-step');
  const progressText = document.getElementById('pipelineProgressText');

  steps.forEach(s => {
    s.className = 'pipeline-step';
    s.querySelector('.step-status').innerHTML = `<i class="fa-solid fa-hourglass-start"></i>`;
  });

  const stepLabels = [
    "Ingestion: Resolving OpenStreetMap GPS coordinates...",
    "Sensors: Querying Open-Meteo live weather radar...",
    "Detection: Cross-referencing claim against physical telemetry...",
    "Escalation Gate: Calculating threshold risk index...",
    "Planning: Calculating OSRM turn-by-turn road route...",
    "Simulation: Running digital twin traffic relief model...",
    "Broadcast Gate: Multi-agency response dispatch completed!"
  ];

  // Pipeline animation
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i];
    s.classList.add('step-running');
    progressText.textContent = stepLabels[i];
    playBeep(440 + (i * 60), 0.07);
    await new Promise(r => setTimeout(r, 450));
    s.classList.remove('step-running');
    s.classList.add('step-complete');
    s.querySelector('.step-status').innerHTML = `<i class="fa-solid fa-check"></i>`;
  }

  try {
    // Call server with real live API integration
    const res = await fetch('/api/live_analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        location: locationQuery,
        signal_text: signalText
      })
    });

    const data = await res.json();
    if (data.error) {
      alert("Error: " + data.error);
      return;
    }

    playSuccessChime();
    progressText.textContent = "Live Telemetry Analysis Complete";

    // 1. Update Live Telemetry Strip with EXACT Real Data
    const w = data.live_telemetry.weather;
    const g = data.live_telemetry.geocoding;
    const r = data.live_telemetry.routing;

    document.getElementById('telTemp').textContent = `${w.temperature_c.toFixed(1)} °C`;
    document.getElementById('telRain').textContent = `${w.rain_mm.toFixed(2)} mm/hr`;
    document.getElementById('telHumidity').textContent = `${w.humidity_pct} %`;
    document.getElementById('telWind').textContent = `${w.wind_speed_kmh.toFixed(1)} km/h`;
    document.getElementById('telCoords').textContent = `${g.lat.toFixed(4)}, ${g.lng.toFixed(4)}`;
    document.getElementById('telRoute').textContent = `${r.distance_km} km • ${r.travel_time_minutes} min`;

    // Drone telemetry
    document.getElementById('droneThermal').textContent = `${w.temperature_c.toFixed(1)}°C`;

    // 2. Map Subtitles & Locations
    document.getElementById('crisisLocationHeadline').textContent = locationQuery;
    document.getElementById('crisisFullAddress').textContent = g.display_name;

    // 3. AI Crisis Verdict & Contradiction Alert
    document.getElementById('crisisTypeLabel').textContent = data.crisis.type_label;
    document.getElementById('crisisLocationLabel').textContent = `${g.lat.toFixed(4)}, ${g.lng.toFixed(4)}`;
    
    const confPct = Math.round((data.crisis.confidence || 0) * 100);
    document.getElementById('confidenceVal').textContent = `${confPct}%`;
    document.getElementById('confidenceGauge').style.background = 
      `conic-gradient(var(--cyan) calc(${confPct} * 3.6deg), rgba(255, 255, 255, 0.08) 0)`;

    const badge = document.getElementById('crisisSeverityBadge');
    badge.textContent = data.crisis.severity;
    if (data.crisis.severity === 'CRITICAL') badge.className = 'badge badge-critical';
    else if (data.crisis.severity === 'HIGH') badge.className = 'badge badge-cyan';
    else badge.className = 'badge badge-emerald';

    document.getElementById('crisisReasoning').textContent = data.crisis.reasoning;

    // Contradiction Box
    const contraBox = document.getElementById('contradictionBox');
    if (data.crisis.contradiction_note) {
      contraBox.classList.remove('hidden');
      document.getElementById('contradictionText').textContent = data.crisis.contradiction_note;
    } else {
      contraBox.classList.add('hidden');
    }

    // Evidence List
    const evList = document.getElementById('evidenceList');
    evList.innerHTML = '';
    (data.crisis.supporting_evidence || []).forEach(e => {
      const li = document.createElement('li');
      li.textContent = e;
      evList.appendChild(li);
    });

    // 4. Action Cards
    document.getElementById('planPriorityTag').textContent = `Priority: ${data.plan.priority_level}`;
    renderActionCards(data.plan.actions || []);

    // 5. Digital Twin Metrics
    const m = data.simulation.metrics || {};
    document.getElementById('mRoadDistance').textContent = `${m.road_distance_km} km`;
    document.getElementById('mRoadDuration').textContent = `${r.travel_time_minutes} min`;
    document.getElementById('mCongestionBefore').textContent = `${m.congestion_before}%`;
    document.getElementById('mCongestionAfter').textContent = `${m.congestion_after}%`;
    document.getElementById('mCongestionDelta').textContent = `-${m.congestion_delta}% Relief`;
    document.getElementById('mCitizensAlerted').textContent = (m.citizens_alerted || 0).toLocaleString();

    // 6. Update Tactical Map with Exact Road Polyline
    renderMapElements(data);

    // 7. Refresh Live Execution Logs
    fetchLiveLogs();

  } catch (err) {
    console.error('Real-time query failed:', err);
    alert('Failed to connect to live API server: ' + err.message);
  } finally {
    isRunningPipeline = false;
    btn.disabled = false;
    btn.innerHTML = `<i class="fa-solid fa-bolt"></i> <span>Analyze Real Data</span>`;
  }
}

function setQuickLocation(loc) {
  let sampleSignal = "Severe flooding and submerged road reported";
  if (loc.includes('Faizabad') || loc.includes('Rawalpindi')) {
    sampleSignal = "Major traffic collision near flyover, ambulance needed.";
  } else if (loc.includes('Lahore')) {
    sampleSignal = "Extreme scorching heatwave, heatstroke cases reported.";
  } else if (loc.includes('Karachi')) {
    sampleSignal = "Thick smoke and factory warehouse fire outbreak.";
  }
  runLiveAnalysis(loc, sampleSignal);
}

function renderActionCards(actions) {
  const container = document.getElementById('actionCardsContainer');
  container.innerHTML = '';

  actions.forEach(act => {
    let iconClass = 'fa-solid fa-bell';
    if (act.type === 'traffic_reroute') iconClass = 'fa-solid fa-diamond-turn-right';
    else if (act.type === 'rescue_dispatch') iconClass = 'fa-solid fa-truck-medical';
    else if (act.type === 'public_alert') iconClass = 'fa-solid fa-tower-broadcast';

    const card = document.createElement('div');
    card.className = 'action-card';
    card.innerHTML = `
      <div class="action-top-row">
        <div class="action-title-group">
          <div class="action-type-icon"><i class="${iconClass}"></i></div>
          <div class="action-title">${act.title}</div>
        </div>
        <div class="action-eta"><i class="fa-regular fa-clock"></i> ${act.eta_minutes} min ETA</div>
      </div>
      <div class="action-description">${act.description}</div>
      <div class="action-footer-row">
        <div><strong>Resources:</strong> ${(act.resources || []).join(', ')}</div>
        <div class="action-status-tag">${act.status}</div>
      </div>
    `;
    container.appendChild(card);
  });
}

// ─── 5. LIVE ANTIGRAVITY TRACE LOGS ──────────────────────────────────────────
async function fetchLiveLogs() {
  try {
    const res = await fetch('/api/logs');
    const data = await res.json();
    const container = document.getElementById('logsTerminal');
    const countTag = document.getElementById('logCountTag');
    
    container.innerHTML = '';
    countTag.textContent = `${data.logs.length} Traces`;

    data.logs.forEach(log => {
      const line = document.createElement('div');
      line.className = 'log-line';
      const timeStr = log.timestamp ? log.timestamp.split('T')[1].substring(0, 8) : '00:00:00';
      
      line.innerHTML = `
        <span class="log-timestamp">[${timeStr}]</span>
        <span class="log-trace-id">${log.antigravity_trace_id || 'TR-LIVE'}</span>
        <span class="log-agent">&lt;${log.agent}&gt;</span>
        <span class="log-text">${log.input_summary} (${log.duration_ms}ms) — ${log.reasoning}</span>
      `;
      container.appendChild(line);
    });
    container.scrollTop = container.scrollHeight;
  } catch (err) {}
}

async function clearLiveLogs() {
  try {
    await fetch('/api/reset', { method: 'POST' });
    fetchLiveLogs();
  } catch (err) {}
}

// ─── 6. SPEECH-TO-TEXT & PHOTO ANALYSIS ──────────────────────────────────────
function initSpeechRecognition() {
  const micBtn = document.getElementById('micBtn');
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) return;

  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;

  micBtn.addEventListener('click', () => {
    if (micBtn.classList.contains('recording')) {
      recognition.stop();
    } else {
      micBtn.classList.add('recording');
      recognition.start();
    }
  });

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    document.getElementById('signalInputText').value = transcript;
    micBtn.classList.remove('recording');
    playBeep(880, 0.1);
  };

  recognition.onerror = () => micBtn.classList.remove('recording');
  recognition.onend = () => micBtn.classList.remove('recording');
}

function initPhotoUpload() {
  const photoInput = document.getElementById('photoInput');
  const previewBox = document.getElementById('photoPreviewContainer');
  const previewImg = document.getElementById('photoPreviewImg');
  const analysisText = document.getElementById('photoAnalysisText');

  photoInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      previewImg.src = event.target.result;
      previewBox.classList.remove('hidden');
      analysisText.textContent = "AI Vision: Scanning visual distress markers...";

      setTimeout(() => {
        analysisText.innerHTML = `<span style="color:#10b981"><i class="fa-solid fa-circle-check"></i> Crisis Detected: Flooding & Submerged Roadway (94% confidence)</span>`;
        document.getElementById('signalInputText').value = "Visual distress signal confirmed: 3ft water accumulation on main thoroughfare, vehicle stranded.";
        playSuccessChime();
      }, 1400);
    };
    reader.readAsDataURL(file);
  });
}

// ─── 7. CONTROLS & EVENT BINDINGS ─────────────────────────────────────────────
function toggleAgency(agency) {
  const el = document.getElementById(`status${agency.charAt(0).toUpperCase() + agency.slice(1)}`);
  const statuses = ['SYNCED', 'DISPATCHED', 'ENGAGED', 'STANDBY'];
  const current = el.textContent;
  const nextIdx = (statuses.indexOf(current) + 1) % statuses.length;
  el.textContent = statuses[nextIdx];

  if (statuses[nextIdx] === 'STANDBY') el.className = 'agency-status text-amber';
  else if (statuses[nextIdx] === 'ENGAGED') el.className = 'agency-status text-cyan';
  else el.className = 'agency-status text-emerald';
  playBeep(600, 0.05);
}

function toggleMapLayer(layer) {
  const btn = document.getElementById(`layer${layer.charAt(0).toUpperCase() + layer.slice(1)}`);
  btn.classList.toggle('active');

  if (layer === 'hazard') {
    if (hazardCircle) {
      if (btn.classList.contains('active')) map.addLayer(hazardCircle);
      else map.removeLayer(hazardCircle);
    }
  } else if (layer === 'units') {
    if (btn.classList.contains('active')) map.addLayer(markerLayerGroup);
    else map.removeLayer(markerLayerGroup);
  } else if (layer === 'reroute') {
    if (btn.classList.contains('active')) map.addLayer(corridorLayerGroup);
    else map.removeLayer(corridorLayerGroup);
  }
}

function toggleDroneRecon() {
  const btn = document.getElementById('btnDrone');
  const hud = document.getElementById('droneHud');
  isDroneActive = !isDroneActive;
  btn.classList.toggle('active', isDroneActive);

  if (isDroneActive) {
    hud.classList.remove('hidden');
    playAlertAlarm();
    let alt = 142;
    let spd = 46;
    droneInterval = setInterval(() => {
      alt += Math.floor(Math.random() * 5) - 2;
      spd += Math.floor(Math.random() * 7) - 3;
      document.getElementById('droneAlt').textContent = `${alt}m`;
      document.getElementById('droneSpeed').textContent = `${spd}km/h`;
    }, 1500);
  } else {
    hud.classList.add('hidden');
    clearInterval(droneInterval);
  }
}

function toggleSurvivalMode() {
  const btn = document.getElementById('btnSurvival');
  document.body.classList.toggle('survival-mode');
  btn.classList.toggle('active');
  playBeep(330, 0.08);
}

let safeCheckCount = 1840;
function broadcastSafeCheck() {
  safeCheckCount += Math.floor(Math.random() * 200 + 120);
  document.getElementById('safeCheckCount').textContent = safeCheckCount.toLocaleString();
  playSuccessChime();
}

let reliefRaised = 145000;
const reliefTarget = 500000;
function addDonation(amt) {
  reliefRaised = Math.min(reliefTarget, reliefRaised + amt);
  document.getElementById('reliefRaisedText').textContent = `PKR ${reliefRaised.toLocaleString()}`;
  const pct = Math.round((reliefRaised / reliefTarget) * 100);
  document.getElementById('reliefProgressFill').style.width = `${pct}%`;
  playSuccessChime();
}

function bindUIEvents() {
  document.getElementById('btnRunPipeline').addEventListener('click', () => runLiveAnalysis());
  document.getElementById('btnDrone').addEventListener('click', toggleDroneRecon);
  document.getElementById('btnSurvival').addEventListener('click', toggleSurvivalMode);
  document.getElementById('btnBroadcastSafe').addEventListener('click', broadcastSafeCheck);

  // Allow Enter key in location input
  document.getElementById('targetLocationInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runLiveAnalysis();
  });

  initSpeechRecognition();
  initPhotoUpload();
}
